// src/renderer/mods/afterHours.tsx
import { useEffect, useId, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { charKeyOf as charKeyOf2, EMOTIONS, globalSlotOf as globalSlotOf2, threadStartedBy } from "@vx/modkit/shared";
import {
  character,
  conversation,
  fadeIn,
  gestures,
  interludeNow,
  modOptionOn,
  quietLift,
  quietPress,
  registerHooks,
  rosterIds,
  safePoint,
  saveField,
  showError,
  useGameFacts,
  useModOption,
  usePlayerProfilePicture
} from "@vx/modkit/renderer";

// src/shared/afterHours.ts
import { charKeyOf, globalSlotOf } from "@vx/modkit/shared";

// src/shared/afterHoursText.ts
var AFTER_HOURS_MOD = "after-hours";
var afterHoursText = {
  name: "After Hours",
  blurb: "A Busy status for the phone, and a night in your room after the evening to text before you sleep.",
  offNote: "Switching it off keeps your status; girls can ask you out again, and the evening goes straight to the morning.",
  option: "Busy status",
  online: "Online",
  busy: "Busy",
  hint: "Busy: no meeting up right now in chats you start.",
  busyTextsOption: "Text her when she's busy",
  busyTextsHint: "Text her during class or work; she replies when she's out, in the next half of the day.",
  nightOption: "The night",
  nightHint: "After the evening, stay up texting before you sleep. An evening in her room or yours can last the night.",
  nightLine: "It's late, and you're in your room for the night. The hall outside is quiet now.",
  sleepLine: "You put your phone away and turn in for the night. Before you know it, it's morning.",
  relaxLine: "You stay in and take it easy, doing nothing in particular. Before you know it, the evening's gone.",
  goToSleep: "Go to sleep",
  skipTomorrow: "Skip to tomorrow",
  relax: "Relax (Skip to bedtime)"
};
function busyPrompt(name) {
  return `In the background: the reader is staying in for now, so ${name} does not suggest meeting up right now. Making plans for another time is fine. It is not something she talks about.`;
}
function nightPrompt(name) {
  return `It is late at night, and students are expected to be in their own dorm rooms by now. ${name} and the reader are both in their rooms, and neither is going anywhere tonight, so she does not suggest meeting up now. Making plans for another time is fine. It is just the hour, not something to remark on.`;
}
var stayOverPrompt = "This is the evening. If the scene ends in her dorm room or the reader's, and both of them want it, they can spend the night there together. It is only an option, never a goal.";
var stayOverLedgerInstruction = "Set stayedOverWith to the key of the girl the reader is spending tonight with as the scene ends, and stayedOverIn to whose room it is in; set both to none if he is spending the night alone.";
function morningReturnPrompt(name, key, room) {
  const speech = `if she says something, her words as their own line or two: only her words, with "speaker" set to "${key}" and "emotion" to how she looks saying them`;
  return room === "herRoom" ? `Last night the reader stayed over with ${name} in her room (see the latest scene). This morning's opening is the one time dialogue and someone else on screen are allowed. Write it as short lines, one beat each: first, one line of him waking up there beside her; then, as he leaves, ${speech}; then one line of him getting back to his own room; then the morning as usual. Do not sum up or describe what happened between them last night. Every entry in "lines" has "speaker" and "emotion": "" for both on narration; her own words are never written into a narration line. For example: {"text": "Pull the door shut on your way out.", "speaker": "${key}", "emotion": "happy"}. Set "homeLine" to the index in "lines" of the line where he is back in his own room.` : `Last night ${name} stayed over in the reader's room (see the latest scene). This morning's opening is the one time dialogue and someone else on screen are allowed. Write it as short lines, one beat each: first, one line of them waking up there together; then, as she leaves, ${speech}; then one line of her heading off; then the morning as usual. Do not sum up or describe what happened between them last night. Every entry in "lines" has "speaker" and "emotion": "" for both on narration; her own words are never written into a narration line. For example: {"text": "I'll text you after class.", "speaker": "${key}", "emotion": "happy"}. Set "homeLine" to the index in "lines" of the first line after she has gone.`;
}
function busyTextPrompt(name, commitment) {
  const place = commitment.kind === "class" ? `in ${commitment.name}` : `at her shift at ${commitment.employer}`;
  const after = commitment.kind === "class" ? "class" : "work";
  return `${name} is ${place} right now and cannot text. She will read the reader's messages once it is over, in the next half of the day, and the reply you write is the one she sends then: as she would after ${after}, catching up on what he said. It is not something she needs to dwell on unless she wants to.`;
}

// src/shared/afterHours.ts
function normalize(stored) {
  const data = typeof stored === "object" && stored !== null ? stored : {};
  const stay = data.stayOver;
  const validStay = stay && typeof stay === "object" && typeof stay.charId === "string" && stay.charId.length > 0 && (stay.room === "herRoom" || stay.room === "hisRoom") && Number.isInteger(stay.morning);
  return {
    busy: data.busy === true,
    ...typeof data.nightDone === "number" && Number.isInteger(data.nightDone) ? { nightDone: data.nightDone } : {},
    ...validStay ? { stayOver: { charId: stay.charId, room: stay.room, morning: stay.morning } } : {}
  };
}
function stayOverOf(ledger, cast) {
  if (!ledger || typeof ledger !== "object") return null;
  const { stayedOverWith, stayedOverIn } = ledger;
  if (typeof stayedOverWith !== "string" || stayedOverWith === "none" || stayedOverIn !== "herRoom" && stayedOverIn !== "hisRoom") return null;
  const girl = cast.find((girl2) => charKeyOf(girl2.firstName, girl2.lastName) === stayedOverWith);
  return girl ? { girl, room: stayedOverIn } : null;
}
function nightOwed(to, data) {
  return to.time === 0 && to.date > 0 && data.nightDone !== globalSlotOf(to.date, to.time);
}
function busyPromptApplies(busy, startedBy) {
  return busy && startedBy === "reader";
}
function stagedUntil(reply, key) {
  const lines = Array.isArray(reply.lines) ? reply.lines : [];
  let last = -1;
  lines.forEach((line, index) => {
    if (line && typeof line === "object" && line.speaker === key) last = index;
  });
  const named = reply.homeLine;
  if (typeof named === "number" && Number.isInteger(named) && named > Math.max(last, 0) && named <= lines.length) return named;
  return Math.min(lines.length, last >= 0 ? last + 1 : 1);
}

// src/renderer/mods/afterHours.tsx
import { jsx, jsxs } from "react/jsx-runtime";
var status = saveField(AFTER_HOURS_MOD, { empty: { busy: false }, normalize });
function gameCharacters() {
  return rosterIds({ alumni: true }).flatMap((id) => {
    const girl = character(id);
    return girl ? [girl] : [];
  });
}
function nightHolds() {
  const hold = interludeNow();
  return hold?.owner === AFTER_HOURS_MOD && hold.clock === "late-night";
}
var hintIn = fadeIn(0);
function StatusChip({ theme }) {
  const enabled = useModOption(AFTER_HOURS_MOD, "busy-status");
  const { playthroughId, readerName } = useGameFacts();
  const picture = usePlayerProfilePicture();
  const value = status.use();
  const [writing, setWriting] = useState(false);
  const [hover, setHover] = useState(false);
  const hintId = useId();
  useEffect(() => setHover(false), [enabled, playthroughId]);
  if (!enabled || !playthroughId) return null;
  async function toggle() {
    const expect = status.read();
    const next = { ...expect, busy: !expect.busy };
    if (safePoint() !== "open") {
      status.set(next);
      return;
    }
    setWriting(true);
    try {
      const result = await status.write(next, { expect });
      if (!result.ok) showError(result.error);
    } finally {
      setWriting(false);
    }
  }
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "vu-after-hours-status",
      "data-theme": theme,
      onPointerEnter: () => setHover(true),
      onPointerLeave: () => setHover(false),
      children: [
        /* @__PURE__ */ jsxs(
          motion.button,
          {
            type: "button",
            className: "vu-after-hours-chip",
            "aria-pressed": value.busy,
            "aria-describedby": hover ? hintId : void 0,
            disabled: writing,
            onClick: () => void toggle(),
            ...gestures(writing, quietLift, quietPress),
            children: [
              /* @__PURE__ */ jsx("span", { className: "vu-arch vu-bb-face vu-bb-face--sm vu-after-hours-face", children: picture ? /* @__PURE__ */ jsx("span", { className: "vu-crop", children: /* @__PURE__ */ jsx("img", { className: "vu-crop-img", src: picture, alt: "" }) }) : /* @__PURE__ */ jsx("span", { className: "vu-after-hours-initial", "aria-hidden": "true", children: readerName.charAt(0) }) }),
              /* @__PURE__ */ jsxs("span", { className: "vu-after-hours-main", children: [
                /* @__PURE__ */ jsx("span", { className: "vu-bb-name", children: readerName }),
                /* @__PURE__ */ jsxs("span", { className: "vu-bb-where", children: [
                  /* @__PURE__ */ jsx("span", { className: `vu-bb-led${value.busy ? " vu-bb-led--busy" : ""}`, "aria-hidden": "true" }),
                  value.busy ? afterHoursText.busy : afterHoursText.online
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsx(AnimatePresence, { children: hover && /* @__PURE__ */ jsx(
          motion.span,
          {
            id: hintId,
            role: "tooltip",
            className: "vu-after-hours-hint",
            variants: hintIn,
            initial: "hidden",
            animate: "shown",
            exit: "gone",
            children: afterHoursText.hint
          }
        ) })
      ]
    }
  );
}
registerHooks(AFTER_HOURS_MOD, {
  chatsHeader: StatusChip,
  textWhileBusy: () => modOptionOn(AFTER_HOURS_MOD, "busy-texts"),
  interludePreview: ({ to, ledger }) => modOptionOn(AFTER_HOURS_MOD, "night") && nightOwed(to, status.read()) && !stayOverOf(ledger, gameCharacters()) ? { at: "from", clock: "late-night" } : null,
  slotInterlude: ({ to }) => {
    if (!modOptionOn(AFTER_HOURS_MOD, "night") || !nightOwed(to, status.read())) return null;
    return {
      lines: [afterHoursText.nightLine],
      rows: [{
        label: afterHoursText.goToSleep,
        card: true,
        line: afterHoursText.sleepLine,
        onPick: () => status.set({ ...status.read(), nightDone: globalSlotOf2(to.date, to.time) })
      }],
      clock: "late-night"
    };
  },
  relaxLine: ({ time }) => modOptionOn(AFTER_HOURS_MOD, "night") && time === 1 ? afterHoursText.relaxLine : void 0,
  // After a night at hers, the morning's narration plays in her room until he is home.
  // The morning after a night together opens on them there: her on stage for her parting words,
  // until the line where they have parted.
  openingLook: ({ date, time, reply }) => {
    const stay = status.read().stayOver;
    const girl = stay && stay.morning === globalSlotOf2(date, time) ? character(stay.charId) : null;
    if (!stay || !girl) return null;
    return {
      room: { kind: stay.room, charId: stay.charId },
      cast: [stay.charId],
      until: stagedUntil(reply, charKeyOf2(girl.firstName, girl.lastName))
    };
  },
  relaxRows: ({ date, time }) => modOptionOn(AFTER_HOURS_MOD, "night") && time === 1 ? [{
    label: afterHoursText.skipTomorrow,
    onPick: () => status.set({ ...status.read(), nightDone: globalSlotOf2(date, time) + 1 })
  }] : [],
  slotSettled: ({ before, ledger }) => {
    const slot = globalSlotOf2(before.date, before.time);
    const { stayOver: past, ...data } = status.read();
    const stay = before.time === 1 ? stayOverOf(ledger, gameCharacters()) : null;
    status.set(stay ? { ...data, nightDone: slot + 1, stayOver: { charId: stay.girl.charId, room: stay.room, morning: slot + 1 } } : { ...data, ...past && past.morning > slot ? { stayOver: past } : {} });
  },
  requests: {
    ledger: (request, { state, charKeys }) => {
      if (state.time !== 1 || !modOptionOn(AFTER_HOURS_MOD, "night")) return request;
      const schema = request.schema.schema;
      return { ...request, user: `${request.user}
${stayOverLedgerInstruction}`, schema: { ...request.schema, schema: {
        ...schema,
        properties: {
          ...schema.properties,
          stayedOverWith: { type: "string", enum: [...charKeys, "none"] },
          stayedOverIn: { type: "string", enum: ["herRoom", "hisRoom", "none"] }
        },
        required: [...schema.required ?? [], "stayedOverWith", "stayedOverIn"]
      } } };
    },
    "slot-intro": (request, { input, ledger }) => {
      if (input.time !== 0) return request;
      const stay = stayOverOf(ledger, gameCharacters());
      if (!stay) return request;
      const key = charKeyOf2(stay.girl.firstName, stay.girl.lastName);
      const schema = request.schema.schema;
      const lines = schema.properties.lines;
      return {
        ...request,
        user: `${request.user}
${morningReturnPrompt(stay.girl.firstName, key, stay.room)}`,
        schema: { ...request.schema, schema: {
          ...schema,
          properties: {
            ...schema.properties,
            // Required on every line, empty for narration, so each line is decided as hers or not.
            lines: { ...lines, items: {
              ...lines.items,
              properties: {
                ...lines.items.properties,
                speaker: { type: "string", enum: [key, ""] },
                emotion: { type: "string", enum: [...EMOTIONS, ""] }
              },
              required: [...lines.items.required ?? [], "speaker", "emotion"]
            } },
            homeLine: { type: "integer" }
          },
          required: [...schema.required ?? [], "homeLine"]
        } }
      };
    }
  },
  hangoutCheck: ({ startedBy }) => !busyPromptApplies(modOptionOn(AFTER_HOURS_MOD, "busy-status") && status.read().busy, startedBy),
  relaxLabel: ({ time }) => modOptionOn(AFTER_HOURS_MOD, "night") && time === 1 ? afterHoursText.relax : void 0,
  prompts: {
    scene: {
      lines: ({ state }) => state.time === 1 && modOptionOn(AFTER_HOURS_MOD, "night") ? [stayOverPrompt] : []
    },
    dm: {
      lines: ({ character: character2, state }) => {
        const thread = conversation(character2.charId);
        const busy = busyPromptApplies(
          modOptionOn(AFTER_HOURS_MOD, "busy-status") && status.read().busy,
          threadStartedBy(thread?.messages ?? [], state.date, state.time)
        );
        return [
          // A reply written after a class they share is told so by the game itself.
          ...state.heldUntil && state.commitment && !state.sharedClass ? [busyTextPrompt(character2.firstName, state.commitment)] : [],
          ...nightHolds() ? [nightPrompt(character2.firstName)] : [],
          ...busy ? [busyPrompt(character2.firstName)] : []
        ];
      }
    }
  }
});
