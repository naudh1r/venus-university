// src/renderer/mods/afterHours.tsx
import { useEffect, useId, useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  affectionFor,
  charKeyOf as charKeyOf2,
  EMOTIONS,
  emptyFlags,
  globalSlotOf as globalSlotOf2,
  LOCATIONS,
  NARRATIVE_LOCATIONS,
  relationshipTagOf,
  seededRand as seededRand2,
  threadStartedBy
} from "@vx/modkit/shared";
import {
  addMemory,
  character,
  characterInfo,
  conversation,
  fadeIn,
  gestures,
  interludeNow,
  isGraduationSlot,
  modOptionOn,
  noteInThread,
  quietLift,
  quietPress,
  registerHooks,
  rosterIds,
  safePoint,
  saveField,
  showError,
  useGameFacts,
  useModOption,
  usePlayerProfilePicture
} from "@vx/modkit/renderer";

// src/shared/afterHours.ts
import { charKeyOf, globalSlotOf, pronounsOf, readerWordsOf, seededRand } from "@vx/modkit/shared";

// src/shared/afterHoursText.ts
var AFTER_HOURS_MOD = "after-hours";
var afterHoursText = {
  name: "After Hours",
  blurb: "A Busy status for the phone, texting people while they're busy, and a night after the evening. While you're Busy, a chat you start won't turn into meeting up right now, though they can still ask you out themselves. Text someone during their class or work, and they reply once they're out. After the evening, a night in your room to text before you sleep, or, if you spent it with someone, a short goodbye the next morning.",
  offNote: "Switching it off keeps your status. People can ask you out again, and the evening goes straight to the morning.",
  option: "Busy status",
  online: "Available",
  busy: "Busy",
  hint: "Busy: no meeting up right now in chats you start.",
  busyTextsOption: "Replies can wait",
  busyTextsHint: "Text anyone anytime. People in class, at work, asleep or away reply later. Their light shows which.",
  nightOption: "The night",
  /** The reader's Yes to a contact's invitation. */
  acceptTheirs: [
    "sure, i'm coming now!",
    "sure, let's do it",
    "see you there",
    "omw!",
    "be there soon",
    "yes! give me a few minutes",
    "sounds good, heading over",
    "count me in"
  ],
  /** The reader's Yes once the contact agreed to the reader's own suggestion. */
  acceptMine: [
    "see you there",
    "omw!",
    "be there soon",
    "perfect, heading over now",
    "great, see you in a bit"
  ],
  chatLightsOption: "Status lights in Chats",
  chatLightsHint: "A light beside each name in Chats: green when free, orange in class or at work, yellow when idle.",
  nightHint: "After the evening, stay up texting before you sleep. An evening in their room or yours can last the night.",
  /** One is picked for each night's landing; each leaves the reader awake in their room with their phone. */
  nightLines: [
    "It's late, and you're in your room for the night. The hall outside is quiet now.",
    "It's late. The hall has gone quiet, and the only light left on is your desk lamp.",
    "You're back in your room for the night. Somewhere down the hall, someone still has music on, low.",
    "It's late, and the building has mostly settled down. Your bed's right there, but you're not quite tired yet.",
    "The day's done, and you're in your room for the night. Outside your window, campus is dark and still.",
    "It's late. A door clicks shut somewhere down the hall, and then everything's quiet."
  ],
  /** One is picked for each night; each ends at falling asleep, leaving the morning to the curtain. */
  sleepLines: [
    "You put your phone away and turn off the light. Before you know it, you're asleep.",
    "You plug in your phone and pull the covers up. Before you know it, you've drifted off.",
    "You set your alarm and roll over. The hall goes quiet, and so do you.",
    "You turn off the light and lie there a while, thinking about nothing much. Sleep comes easy.",
    "You put your phone face down on the nightstand and close your eyes. It doesn't take long.",
    "You turn in for the night. Somewhere down the hall a door clicks shut, and then you're out."
  ],
  relaxLine: "You stay in and take it easy, doing nothing in particular. Before you know it, the evening's gone.",
  goToSleep: "Go to sleep",
  skipTomorrow: "Skip to tomorrow",
  relax: "Relax (Skip to bedtime)"
};

// src/shared/afterHours.ts
function normalize(stored) {
  const data = typeof stored === "object" && stored !== null ? stored : {};
  const sleep = data.sleep;
  const validSleep = sleep && Number.isInteger(sleep.date) && Array.isArray(sleep.cast) && sleep.cast.every((id) => typeof id === "string");
  const asleep = validSleep && Array.isArray(sleep.asleep) && sleep.asleep.every((id) => typeof id === "string") ? sleep.asleep : void 0;
  const idle = data.weekendIdle;
  const validIdle = idle && Number.isInteger(idle.slot) && Array.isArray(idle.charIds) && idle.charIds.every((id) => typeof id === "string");
  const stay = data.stayOver;
  const validStay = stay && typeof stay === "object" && typeof stay.charId === "string" && stay.charId.length > 0 && (stay.room === "herRoom" || stay.room === "hisRoom") && Number.isInteger(stay.morning);
  return {
    busy: data.busy === true,
    ...typeof data.nightDone === "number" && Number.isInteger(data.nightDone) ? { nightDone: data.nightDone } : {},
    ...validIdle ? { weekendIdle: { slot: idle.slot, charIds: idle.charIds } } : {},
    ...validSleep ? { sleep: { date: sleep.date, cast: sleep.cast, ...asleep ? { asleep } : {} } } : {},
    ...validStay ? { stayOver: { charId: stay.charId, room: stay.room, morning: stay.morning } } : {}
  };
}
var AWAKE_AFTER_MEETING = 0.8;
var AWAKE_WHEN_CLOSE = 0.6;
var AWAKE_OTHERWISE = 0.5;
var WEEKEND_IDLE_CHANCE = 0.4;
function asleepTonight(charKey, date, { metThisEvening, close }) {
  const awake = metThisEvening ? AWAKE_AFTER_MEETING : close ? AWAKE_WHEN_CLOSE : AWAKE_OTHERWISE;
  return seededRand(`${AFTER_HOURS_MOD}:sleep:${date}:${charKey}`)() >= awake;
}
function idleAtHome(charKey, date, time) {
  return seededRand(`${AFTER_HOURS_MOD}:away:${date}:${time}:${charKey}`)() < WEEKEND_IDLE_CHANCE;
}
function stayOverOf(ledger, cast) {
  if (!ledger || typeof ledger !== "object") return null;
  const { stayedOverWith, stayedOverIn } = ledger;
  if (typeof stayedOverWith !== "string" || stayedOverWith === "none" || stayedOverIn !== "herRoom" && stayedOverIn !== "hisRoom") return null;
  const partner = cast.find((contact) => charKeyOf(contact.firstName, contact.lastName) === stayedOverWith);
  return partner ? { partner, room: stayedOverIn } : null;
}
function nightOwed(to, data) {
  return to.time === 0 && to.date > 0 && data.nightDone !== globalSlotOf(to.date, to.time);
}
function busyPromptApplies(busy, startedBy) {
  return busy && startedBy === "reader";
}
function stagedUntil(reply, key) {
  const lines = Array.isArray(reply.lines) ? reply.lines : [];
  let last = -1;
  lines.forEach((line, index) => {
    if (line && typeof line === "object" && line.speaker === key) last = index;
  });
  const named = reply.homeLine;
  if (typeof named === "number" && Number.isInteger(named) && named > Math.max(last, 0) && named <= lines.length) return named;
  return Math.min(lines.length, last >= 0 ? last + 1 : 1);
}
function contactWords(contact) {
  const p = pronounsOf(contact);
  return { subject: p.they, Subject: p.They, object: p.them, possessive: p.their };
}
function busyPrompt(contact) {
  const p = contactWords(contact);
  return `In the background: the reader is staying in for now, so ${contact.firstName} does not suggest meeting up right now. Making plans for another time is fine. It is not something ${p.subject} talks about.`;
}
function nightPrompt(contact) {
  const p = contactWords(contact);
  return `It is late at night, and students are expected to be in their own dorm rooms by now. ${contact.firstName} and the reader are both in their rooms, and neither is going anywhere tonight, so ${p.subject} does not suggest meeting up now. Making plans for another time is fine. It is just the hour, not something to remark on.`;
}
var stayOverPrompt = "This is the evening. If the scene ends in another character's dorm room or the reader's, and both of them want it, they can spend the night there together. It is only an option, never a goal.";
function stayOverLedgerInstruction(pronouns) {
  const reader = readerWordsOf(pronouns);
  return `Set stayedOverWith to the key of the character spending tonight with the reader as the scene ends. Set stayedOverIn to "herRoom" for that character's room or "hisRoom" for the reader's room, regardless of pronouns. Set both to "none" if ${reader.he} is spending the night alone.`;
}
function morningReturnPrompt(contact, key, room, pronouns) {
  const name = contact.firstName;
  const p = contactWords(contact);
  const reader = readerWordsOf(pronouns, contact.gender ?? "female");
  const speech = `three or four lines of ${name} talking to ${reader.him}, one after another: only ${p.possessive} words, each with "speaker" set to "${key}" and "emotion" to how ${p.subject} looks saying it`;
  const atTheirs = room === "herRoom";
  const place = atTheirs ? `${p.possessive} room` : "the reader's room";
  const beats = atTheirs ? `first, one line where ${reader.he} wakes up beside ${p.object}; then, as the reader leaves, ${speech}; then one line where ${reader.he} gets back to ${reader.his} room; then the morning as usual.` : `first, one line of them waking up there together; then, as ${name} leaves, ${speech}; then one line of ${name} heading off; then the morning as usual.`;
  const example = atTheirs ? "Pull the door shut on your way out." : "I'll text you after class.";
  const home = atTheirs ? "the line where the reader gets home" : `the first line after ${name} has gone`;
  return `Last night the reader stayed over with ${name} in ${place} (see the latest scene). This morning's opening is the one time dialogue and someone else on screen are allowed. Write it as short lines, one beat each: ${beats} Do not sum up or describe what happened between them last night. Every entry in "lines" has "speaker" and "emotion": "" for both on narration; ${p.possessive} own words are never written into a narration line. For example: {"text": "${example}", "speaker": "${key}", "emotion": "happy"}. Set "homeLine" to the index in "lines" of ${home}.`;
}
function sleepingTextPrompt(contact) {
  const p = pronounsOf(contact);
  return `${contact.firstName} fell asleep before reading the reader's messages. Write the reply ${p.they} sends in the morning after reading them. ${p.They} can mention falling asleep, but there's no need to make a topic of it.`;
}
function awayTextPrompt(contact, time) {
  const p = pronounsOf(contact);
  const possibilities = time === 0 ? "Sleeping in is as possible as being on a call or doing something around the room." : "A call or something around the room would fit. A nap is possible if it suits the contact and the evening.";
  return `${contact.firstName} was at home and away from the phone when the reader's messages came in. Decide what ${p.they} had been doing, to suit the character and the time. ${possibilities} Write the reply that comes later, when ${p.they} can catch up. ${p.They} can mention the delay without making a topic of it.`;
}
function busyTextPrompt(contact, commitment, pronouns) {
  const p = contactWords(contact);
  const reader = readerWordsOf(pronouns, contact.gender ?? "female");
  const place = commitment.kind === "class" ? `in ${commitment.name}` : `at ${p.possessive} shift at ${commitment.employer}`;
  const after = commitment.kind === "class" ? "class" : "work";
  return `${contact.firstName} is ${place} right now and cannot text. ${p.Subject} will read the reader's messages once it is over, in the next half of the day, and the reply you write is the one ${p.subject} sends then: as ${p.subject} would after ${after}, catching up on what ${reader.he} said. It is not something ${p.subject} needs to dwell on unless ${p.subject} wants to.`;
}

// src/renderer/mods/afterHours.tsx
import { jsx, jsxs } from "react/jsx-runtime";
var status = saveField(AFTER_HOURS_MOD, { empty: { busy: false }, normalize });
function gameCharacters() {
  return rosterIds({ alumni: true }).flatMap((id) => {
    const contact = character(id);
    return contact ? [contact] : [];
  });
}
function nightAfter(date, time) {
  return time === 1 && !isGraduationSlot(date + 1, 0);
}
function heldNight() {
  const hold = interludeNow();
  return hold?.owner === AFTER_HOURS_MOD && hold.clock === "late-night" ? hold : null;
}
var CLOSE_TAGS = /* @__PURE__ */ new Set(["Friend", "Best Friend", "BFF", "Lover"]);
var hintIn = fadeIn(0);
function recordSleepers(date) {
  const data = status.read();
  const sleep = data.sleep?.date === date ? data.sleep : { date, cast: [] };
  if (sleep.asleep) return;
  const asleep = gameCharacters().filter((contact) => {
    const info = characterInfo(contact.charId);
    const tag = relationshipTagOf(info?.flags ?? emptyFlags(), affectionFor(info, date, contact));
    return asleepTonight(charKeyOf2(contact.firstName, contact.lastName), date, {
      metThisEvening: sleep.cast.includes(contact.charId),
      close: CLOSE_TAGS.has(tag)
    });
  }).map((contact) => contact.charId);
  status.set({ ...data, sleep: { ...sleep, asleep } });
}
function recordWeekendIdle(date, time, homeContacts) {
  const data = status.read();
  const slot = globalSlotOf2(date, time);
  if (data.weekendIdle?.slot === slot) return;
  const overnightGuest = data.stayOver?.morning === slot ? data.stayOver.charId : null;
  const charIds = homeContacts.filter((id) => {
    if (id === overnightGuest) return false;
    const contact = character(id);
    return contact !== void 0 && idleAtHome(charKeyOf2(contact.firstName, contact.lastName), date, time);
  });
  status.set({ ...data, weekendIdle: { slot, charIds } });
}
function StatusChip({ theme }) {
  const enabled = useModOption(AFTER_HOURS_MOD, "busy-status");
  const { playthroughId, readerName } = useGameFacts();
  const picture = usePlayerProfilePicture();
  const value = status.use();
  const [writing, setWriting] = useState(false);
  const [hover, setHover] = useState(false);
  const hintId = useId();
  useEffect(() => setHover(false), [enabled, playthroughId]);
  if (!enabled || !playthroughId) return null;
  async function toggle() {
    const expect = status.read();
    const next = { ...expect, busy: !expect.busy };
    if (safePoint() !== "open") {
      status.set(next);
      return;
    }
    setWriting(true);
    try {
      const result = await status.write(next, { expect });
      if (!result.ok) showError(result.error);
    } finally {
      setWriting(false);
    }
  }
  return /* @__PURE__ */ jsxs(
    "div",
    {
      className: "vu-after-hours-status",
      "data-theme": theme,
      onPointerEnter: () => setHover(true),
      onPointerLeave: () => setHover(false),
      children: [
        /* @__PURE__ */ jsxs(
          motion.button,
          {
            type: "button",
            className: "vu-after-hours-chip",
            "aria-pressed": value.busy,
            "aria-describedby": hover ? hintId : void 0,
            disabled: writing,
            onClick: () => void toggle(),
            ...gestures(writing, quietLift, quietPress),
            children: [
              /* @__PURE__ */ jsx("span", { className: "vu-arch vu-bb-face vu-bb-face--sm vu-after-hours-face", children: picture ? /* @__PURE__ */ jsx("span", { className: "vu-crop", children: /* @__PURE__ */ jsx("img", { className: "vu-crop-img", src: picture, alt: "" }) }) : /* @__PURE__ */ jsx("span", { className: "vu-after-hours-initial", "aria-hidden": "true", children: readerName.charAt(0) }) }),
              /* @__PURE__ */ jsxs("span", { className: "vu-after-hours-main", children: [
                /* @__PURE__ */ jsx("span", { className: "vu-bb-name", children: readerName }),
                /* @__PURE__ */ jsxs("span", { className: "vu-bb-where", children: [
                  /* @__PURE__ */ jsx("span", { className: `vu-bb-led${value.busy ? " vu-bb-led--busy" : ""}`, "aria-hidden": "true" }),
                  value.busy ? afterHoursText.busy : afterHoursText.online
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsx(AnimatePresence, { children: hover && /* @__PURE__ */ jsx(
          motion.span,
          {
            id: hintId,
            role: "tooltip",
            className: "vu-after-hours-hint",
            variants: hintIn,
            initial: "hidden",
            animate: "shown",
            exit: "gone",
            children: afterHoursText.hint
          }
        ) })
      ]
    }
  );
}
function meetupNames(names) {
  return names.length > 1 ? `${names.slice(0, -1).join(", ")} and ${names.at(-1)}` : names[0];
}
function noteMeetup({ before, closingCast }) {
  const charId = before.sceneTextLedgerSkip;
  const cast = closingCast.length > 0 ? closingCast : before.cast.flatMap((id) => before.characters[id] ? [before.characters[id]] : []);
  const contact = cast.find((person) => person.charId === charId);
  if (!contact) return;
  const action = before.currentSceneTranscript[0]?.text.split("\n", 1)[0];
  const plan = before.events.find(
    (event) => event.date === before.date && event.time === before.time && event.charIds.includes(contact.charId) && (event.title === action || event.description === action)
  );
  const others = cast.filter(
    (person) => person.charId !== contact.charId && plan?.charIds.includes(person.charId)
  );
  const names = meetupNames([contact.firstName, ...others.map((person) => person.firstName)]);
  const place = [...LOCATIONS, ...NARRATIVE_LOCATIONS].find((location) => location.id === before.sceneLocation)?.label;
  noteInThread(
    contact.charId,
    `You met up with ${names}${place ? ` at ${place}` : ""}.`,
    { date: before.date, time: before.time }
  );
}
registerHooks(AFTER_HOURS_MOD, {
  chatsHeader: StatusChip,
  ownMeetupAsks: () => true,
  warnBeforeMeetup: () => true,
  readReceipts: () => true,
  statusWords: () => true,
  acceptLine: ({ charId, mine }) => {
    const pool = mine ? afterHoursText.acceptMine : afterHoursText.acceptTheirs;
    const thread = conversation(charId)?.messages.length ?? 0;
    return pool[Math.floor(seededRand2(`${AFTER_HOURS_MOD}:accept:${charId}:${thread}`)() * pool.length)];
  },
  chatListLights: () => modOptionOn(AFTER_HOURS_MOD, "chat-lights"),
  asleepNow: ({ charId, date, time, opening }) => {
    if (opening?.weekend) recordWeekendIdle(date, time, opening.homeContacts);
    if (!modOptionOn(AFTER_HOURS_MOD, "busy-texts")) return false;
    const data = status.read();
    const hold = interludeNow();
    if (hold) {
      return hold.owner === AFTER_HOURS_MOD && hold.clock === "late-night" && modOptionOn(AFTER_HOURS_MOD, "night") && data.sleep?.date === hold.from.date && data.sleep.asleep?.includes(charId) === true;
    }
    return data.weekendIdle?.slot === globalSlotOf2(date, time) && data.weekendIdle.charIds.includes(charId);
  },
  textWhileBusy: () => modOptionOn(AFTER_HOURS_MOD, "busy-texts"),
  interludePreview: ({ to, ledger }) => modOptionOn(AFTER_HOURS_MOD, "night") && nightOwed(to, status.read()) && !isGraduationSlot(to.date, to.time) && !stayOverOf(ledger, gameCharacters()) ? { at: "from", clock: "late-night" } : null,
  slotInterlude: ({ from, to }) => {
    if (!modOptionOn(AFTER_HOURS_MOD, "night") || !nightOwed(to, status.read()) || isGraduationSlot(to.date, to.time)) return null;
    recordSleepers(from.date);
    const night = globalSlotOf2(to.date, to.time);
    const pick = (pool, use) => pool[Math.floor(seededRand2(`${AFTER_HOURS_MOD}:${use}:${night}`)() * pool.length)];
    const sleepLine = pick(afterHoursText.sleepLines, "sleep");
    return {
      lines: [pick(afterHoursText.nightLines, "night")],
      rows: [{
        label: afterHoursText.goToSleep,
        card: true,
        line: sleepLine,
        onPick: () => status.set({ ...status.read(), nightDone: globalSlotOf2(to.date, to.time) })
      }],
      clock: "late-night"
    };
  },
  relaxLine: ({ date, time }) => modOptionOn(AFTER_HOURS_MOD, "night") && nightAfter(date, time) ? afterHoursText.relaxLine : void 0,
  // The morning opens with the stay-over partner on stage until the two part.
  openingLook: ({ date, time, reply }) => {
    const stay = status.read().stayOver;
    const contact = stay && stay.morning === globalSlotOf2(date, time) ? character(stay.charId) : null;
    if (!stay || !contact) return null;
    return {
      room: { kind: stay.room, charId: stay.charId },
      cast: [stay.charId],
      until: stagedUntil(reply, charKeyOf2(contact.firstName, contact.lastName))
    };
  },
  relaxRows: ({ date, time }) => modOptionOn(AFTER_HOURS_MOD, "night") && nightAfter(date, time) ? [{
    label: afterHoursText.skipTomorrow,
    onPick: () => status.set({ ...status.read(), nightDone: globalSlotOf2(date, time) + 1 })
  }] : [],
  slotSettled: ({ before, ledger, closingCast, ownMeetupsLapsed }) => {
    for (const { charId } of ownMeetupsLapsed ?? []) {
      addMemory(AFTER_HOURS_MOD, charId, {
        date: before.date,
        type: "disliked",
        desc: "you asked to meet up and then changed your mind"
      });
    }
    noteMeetup({ before, closingCast });
    const slot = globalSlotOf2(before.date, before.time);
    const { stayOver: past, sleep: _sleep, ...data } = status.read();
    const evening = modOptionOn(AFTER_HOURS_MOD, "night") && nightAfter(before.date, before.time);
    const stay = nightAfter(before.date, before.time) ? stayOverOf(ledger, gameCharacters()) : null;
    status.set(stay ? { ...data, nightDone: slot + 1, stayOver: { charId: stay.partner.charId, room: stay.room, morning: slot + 1 } } : {
      ...data,
      ...past && past.morning > slot ? { stayOver: past } : {},
      ...evening && data.nightDone !== slot + 1 ? {
        sleep: { date: before.date, cast: closingCast.length > 0 ? closingCast.map((contact) => contact.charId) : [...before.cast] }
      } : {}
    });
  },
  requests: {
    ledger: (request, { state, charKeys }) => {
      if (!nightAfter(state.date, state.time) || !modOptionOn(AFTER_HOURS_MOD, "night")) return request;
      const schema = request.schema.schema;
      return { ...request, user: `${request.user}
${stayOverLedgerInstruction(state.readerPronouns)}`, schema: { ...request.schema, schema: {
        ...schema,
        properties: {
          ...schema.properties,
          stayedOverWith: { type: "string", enum: [...charKeys, "none"] },
          stayedOverIn: { type: "string", enum: ["herRoom", "hisRoom", "none"] }
        },
        required: [...schema.required ?? [], "stayedOverWith", "stayedOverIn"]
      } } };
    },
    "slot-intro": (request, { input, ledger }) => {
      if (input.time !== 0) return request;
      const stay = stayOverOf(ledger, gameCharacters());
      if (!stay) return request;
      const key = charKeyOf2(stay.partner.firstName, stay.partner.lastName);
      const schema = request.schema.schema;
      const lines = schema.properties.lines;
      return {
        ...request,
        user: `${request.user}
${morningReturnPrompt(stay.partner, key, stay.room, input.readerPronouns)}`,
        schema: { ...request.schema, schema: {
          ...schema,
          properties: {
            ...schema.properties,
            // Every line names its speaker or uses the empty value for narration.
            lines: { ...lines, items: {
              ...lines.items,
              properties: {
                ...lines.items.properties,
                speaker: { type: "string", enum: [key, ""] },
                emotion: { type: "string", enum: [...EMOTIONS, ""] }
              },
              required: [...lines.items.required ?? [], "speaker", "emotion"]
            } },
            homeLine: { type: "integer" }
          },
          required: [...schema.required ?? [], "homeLine"]
        } }
      };
    }
  },
  hangoutCheck: ({ startedBy }) => !busyPromptApplies(modOptionOn(AFTER_HOURS_MOD, "busy-status") && status.read().busy, startedBy),
  relaxLabel: ({ date, time }) => modOptionOn(AFTER_HOURS_MOD, "night") && nightAfter(date, time) ? afterHoursText.relax : void 0,
  prompts: {
    scene: {
      lines: ({ state }) => nightAfter(state.date, state.time) && modOptionOn(AFTER_HOURS_MOD, "night") ? [stayOverPrompt] : []
    },
    dm: {
      lines: ({ character: character2, state }) => {
        const thread = conversation(character2.charId);
        const busy = busyPromptApplies(
          modOptionOn(AFTER_HOURS_MOD, "busy-status") && status.read().busy,
          threadStartedBy(thread?.messages ?? [], state.date, state.time)
        );
        return [
          ...state.asleep ? [sleepingTextPrompt(character2)] : [],
          ...state.away !== void 0 ? [awayTextPrompt(character2, state.away)] : [],
          // A reply written after a class they share is told so by the game itself.
          ...state.heldUntil && state.commitment && !state.sharedClass ? [busyTextPrompt(character2, state.commitment, state.readerPronouns)] : [],
          ...!state.asleep && state.away === void 0 && heldNight() ? [nightPrompt(character2)] : [],
          ...busy ? [busyPrompt(character2)] : []
        ];
      }
    }
  }
});
