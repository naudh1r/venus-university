var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/zustand/esm/vanilla.mjs
var createStoreImpl, createStore;
var init_vanilla = __esm({
  "node_modules/zustand/esm/vanilla.mjs"() {
    createStoreImpl = (createState) => {
      let state;
      const listeners = /* @__PURE__ */ new Set();
      const setState = (partial, replace) => {
        const nextState = typeof partial === "function" ? partial(state) : partial;
        if (!Object.is(nextState, state)) {
          const previousState = state;
          state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
          listeners.forEach((listener) => listener(state, previousState));
        }
      };
      const getState = () => state;
      const getInitialState = () => initialState;
      const subscribe = (listener) => {
        listeners.add(listener);
        return () => listeners.delete(listener);
      };
      const api = { setState, getState, getInitialState, subscribe };
      const initialState = state = createState(setState, getState, api);
      return api;
    };
    createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
  }
});

// node_modules/zustand/esm/react.mjs
import React from "react";
function useStore(api, selector = identity) {
  const slice = React.useSyncExternalStore(
    api.subscribe,
    React.useCallback(() => selector(api.getState()), [api, selector]),
    React.useCallback(() => selector(api.getInitialState()), [api, selector])
  );
  React.useDebugValue(slice);
  return slice;
}
var identity, createImpl, create;
var init_react = __esm({
  "node_modules/zustand/esm/react.mjs"() {
    init_vanilla();
    identity = (arg) => arg;
    createImpl = (createState) => {
      const api = createStore(createState);
      const useBoundStore = (selector) => useStore(api, selector);
      Object.assign(useBoundStore, api);
      return useBoundStore;
    };
    create = ((createState) => createState ? createImpl(createState) : createImpl);
  }
});

// node_modules/zustand/esm/index.mjs
var init_esm = __esm({
  "node_modules/zustand/esm/index.mjs"() {
    init_vanilla();
    init_react();
  }
});

// src/renderer/stores/emojiPrefs.ts
function kept() {
  try {
    const raw = localStorage.getItem(KEPT);
    const read = raw ? JSON.parse(raw) : {};
    const recent = Array.isArray(read.recent) ? read.recent.filter((one) => typeof one === "string").slice(0, RECENT_KEPT) : [];
    const tone = typeof read.tone === "number" && read.tone >= 0 && read.tone < SKIN_TONES.length ? read.tone : null;
    return { recent: recent.length > 0 ? recent : FIRST_RECENT, tone };
  } catch {
    return { recent: FIRST_RECENT, tone: null };
  }
}
function keep(state) {
  try {
    localStorage.setItem(KEPT, JSON.stringify({ recent: state.recent, tone: state.tone }));
  } catch {
  }
}
function tonedEmoji(emoji, tone) {
  if (tone === null) return emoji;
  const points = [...emoji].map((char) => char.codePointAt(0) ?? 0);
  const rest = points[1] === 65039 ? points.slice(2) : points.slice(1);
  return String.fromCodePoint(points[0], SKIN_TONES[tone], ...rest);
}
var KEPT, RECENT_KEPT, FIRST_RECENT, SKIN_TONES, useEmojiPrefs;
var init_emojiPrefs = __esm({
  "src/renderer/stores/emojiPrefs.ts"() {
    init_esm();
    KEPT = "vu-emoji:prefs";
    RECENT_KEPT = 24;
    FIRST_RECENT = ["\u{1F602}", "\u{1F62D}", "\u2764\uFE0F", "\u{1F44D}", "\u{1F346}", "\u{1F633}", "\u{1F525}", "\u{1F97A}"];
    SKIN_TONES = [127995, 127996, 127997, 127998, 127999];
    useEmojiPrefs = create((set, get) => ({
      ...kept(),
      used: (emoji) => {
        const recent = [emoji, ...get().recent.filter((one) => one !== emoji)].slice(0, RECENT_KEPT);
        set({ recent });
        keep(get());
      },
      setTone: (tone) => {
        set({ tone });
        keep(get());
      }
    }));
  }
});

// src/renderer/vu_styles/EmojiPicker.css
var init_EmojiPicker = __esm({
  "src/renderer/vu_styles/EmojiPicker.css"() {
  }
});

// src/renderer/components/emojiData.json
var require_emojiData = __commonJS({
  "src/renderer/components/emojiData.json"(exports, module) {
    module.exports = { smileys: [["\u{1F600}", "grinning face"], ["\u{1F603}", "grinning face with big eyes"], ["\u{1F604}", "grinning face with smiling eyes"], ["\u{1F601}", "beaming face with smiling eyes"], ["\u{1F606}", "grinning squinting face"], ["\u{1F605}", "grinning face with sweat"], ["\u{1F923}", "rolling on the floor laughing"], ["\u{1F602}", "face with tears of joy"], ["\u{1F642}", "slightly smiling face"], ["\u{1F643}", "upside-down face"], ["\u{1FAE0}", "melting face"], ["\u{1F609}", "winking face"], ["\u{1F60A}", "smiling face with smiling eyes"], ["\u{1F607}", "smiling face with halo"], ["\u{1F970}", "smiling face with hearts"], ["\u{1F60D}", "smiling face with heart-eyes"], ["\u{1F929}", "star-struck"], ["\u{1F618}", "face blowing a kiss"], ["\u{1F617}", "kissing face"], ["\u263A\uFE0F", "smiling face"], ["\u{1F61A}", "kissing face with closed eyes"], ["\u{1F619}", "kissing face with smiling eyes"], ["\u{1F972}", "smiling face with tear"], ["\u{1F60B}", "face savoring food"], ["\u{1F61B}", "face with tongue"], ["\u{1F61C}", "winking face with tongue"], ["\u{1F92A}", "zany face"], ["\u{1F61D}", "squinting face with tongue"], ["\u{1F911}", "money-mouth face"], ["\u{1F917}", "smiling face with open hands"], ["\u{1F92D}", "face with hand over mouth"], ["\u{1FAE2}", "face with open eyes and hand over mouth"], ["\u{1FAE3}", "face with peeking eye"], ["\u{1F92B}", "shushing face"], ["\u{1F914}", "thinking face"], ["\u{1FAE1}", "saluting face"], ["\u{1F910}", "zipper-mouth face"], ["\u{1F928}", "face with raised eyebrow"], ["\u{1F610}", "neutral face"], ["\u{1F611}", "expressionless face"], ["\u{1F636}", "face without mouth"], ["\u{1FAE5}", "dotted line face"], ["\u{1F636}\u200D\u{1F32B}\uFE0F", "face in clouds"], ["\u{1F60F}", "smirking face"], ["\u{1F612}", "unamused face"], ["\u{1F644}", "face with rolling eyes"], ["\u{1F62C}", "grimacing face"], ["\u{1F62E}\u200D\u{1F4A8}", "face exhaling"], ["\u{1F925}", "lying face"], ["\u{1FAE8}", "shaking face"], ["\u{1F60C}", "relieved face"], ["\u{1F614}", "pensive face"], ["\u{1F62A}", "sleepy face"], ["\u{1F924}", "drooling face"], ["\u{1F634}", "sleeping face"], ["\u{1F637}", "face with medical mask"], ["\u{1F912}", "face with thermometer"], ["\u{1F915}", "face with head-bandage"], ["\u{1F922}", "nauseated face"], ["\u{1F92E}", "face vomiting"], ["\u{1F927}", "sneezing face"], ["\u{1F975}", "hot face"], ["\u{1F976}", "cold face"], ["\u{1F974}", "woozy face"], ["\u{1F635}", "face with crossed-out eyes"], ["\u{1F635}\u200D\u{1F4AB}", "face with spiral eyes"], ["\u{1F92F}", "exploding head"], ["\u{1F920}", "cowboy hat face"], ["\u{1F973}", "partying face"], ["\u{1F978}", "disguised face"], ["\u{1F60E}", "smiling face with sunglasses"], ["\u{1F913}", "nerd face"], ["\u{1F9D0}", "face with monocle"], ["\u{1F615}", "confused face"], ["\u{1FAE4}", "face with diagonal mouth"], ["\u{1F61F}", "worried face"], ["\u{1F641}", "slightly frowning face"], ["\u2639\uFE0F", "frowning face"], ["\u{1F62E}", "face with open mouth"], ["\u{1F62F}", "hushed face"], ["\u{1F632}", "astonished face"], ["\u{1F633}", "flushed face"], ["\u{1F97A}", "pleading face"], ["\u{1F979}", "face holding back tears"], ["\u{1F626}", "frowning face with open mouth"], ["\u{1F627}", "anguished face"], ["\u{1F628}", "fearful face"], ["\u{1F630}", "anxious face with sweat"], ["\u{1F625}", "sad but relieved face"], ["\u{1F622}", "crying face"], ["\u{1F62D}", "loudly crying face"], ["\u{1F631}", "face screaming in fear"], ["\u{1F616}", "confounded face"], ["\u{1F623}", "persevering face"], ["\u{1F61E}", "disappointed face"], ["\u{1F613}", "downcast face with sweat"], ["\u{1F629}", "weary face"], ["\u{1F62B}", "tired face"], ["\u{1F971}", "yawning face"], ["\u{1F624}", "face with steam from nose"], ["\u{1F621}", "enraged face"], ["\u{1F620}", "angry face"], ["\u{1F92C}", "face with symbols on mouth"], ["\u{1F608}", "smiling face with horns"], ["\u{1F47F}", "angry face with horns"], ["\u{1F480}", "skull"], ["\u2620\uFE0F", "skull and crossbones"], ["\u{1F4A9}", "pile of poo"], ["\u{1F921}", "clown face"], ["\u{1F479}", "ogre"], ["\u{1F47A}", "goblin"], ["\u{1F47B}", "ghost"], ["\u{1F47D}", "alien"], ["\u{1F47E}", "alien monster"], ["\u{1F916}", "robot"], ["\u{1F63A}", "grinning cat"], ["\u{1F638}", "grinning cat with smiling eyes"], ["\u{1F639}", "cat with tears of joy"], ["\u{1F63B}", "smiling cat with heart-eyes"], ["\u{1F63C}", "cat with wry smile"], ["\u{1F63D}", "kissing cat"], ["\u{1F640}", "weary cat"], ["\u{1F63F}", "crying cat"], ["\u{1F63E}", "pouting cat"], ["\u{1F648}", "see-no-evil monkey"], ["\u{1F649}", "hear-no-evil monkey"], ["\u{1F64A}", "speak-no-evil monkey"], ["\u{1F48C}", "love letter"], ["\u{1F498}", "heart with arrow"], ["\u{1F49D}", "heart with ribbon"], ["\u{1F496}", "sparkling heart"], ["\u{1F497}", "growing heart"], ["\u{1F493}", "beating heart"], ["\u{1F49E}", "revolving hearts"], ["\u{1F495}", "two hearts"], ["\u{1F49F}", "heart decoration"], ["\u2763\uFE0F", "heart exclamation"], ["\u{1F494}", "broken heart"], ["\u2764\uFE0F\u200D\u{1F525}", "heart on fire"], ["\u2764\uFE0F\u200D\u{1FA79}", "mending heart"], ["\u2764\uFE0F", "red heart"], ["\u{1FA77}", "pink heart"], ["\u{1F9E1}", "orange heart"], ["\u{1F49B}", "yellow heart"], ["\u{1F49A}", "green heart"], ["\u{1F499}", "blue heart"], ["\u{1FA75}", "light blue heart"], ["\u{1F49C}", "purple heart"], ["\u{1F90E}", "brown heart"], ["\u{1F5A4}", "black heart"], ["\u{1FA76}", "grey heart"], ["\u{1F90D}", "white heart"], ["\u{1F48B}", "kiss mark"], ["\u{1F4AF}", "hundred points"], ["\u{1F4A2}", "anger symbol"], ["\u{1F4A5}", "collision"], ["\u{1F4AB}", "dizzy"], ["\u{1F4A6}", "sweat droplets"], ["\u{1F4A8}", "dashing away"], ["\u{1F573}\uFE0F", "hole"], ["\u{1F4AC}", "speech balloon"], ["\u{1F441}\uFE0F\u200D\u{1F5E8}\uFE0F", "eye in speech bubble"], ["\u{1F5E8}\uFE0F", "left speech bubble"], ["\u{1F5EF}\uFE0F", "right anger bubble"], ["\u{1F4AD}", "thought balloon"], ["\u{1F4A4}", "ZZZ"]], people: [["\u{1F44B}", "waving hand", 1], ["\u{1F91A}", "raised back of hand", 1], ["\u{1F590}\uFE0F", "hand with fingers splayed", 1], ["\u270B", "raised hand", 1], ["\u{1F596}", "vulcan salute", 1], ["\u{1FAF1}", "rightwards hand", 1], ["\u{1FAF2}", "leftwards hand", 1], ["\u{1FAF3}", "palm down hand", 1], ["\u{1FAF4}", "palm up hand", 1], ["\u{1FAF7}", "leftwards pushing hand", 1], ["\u{1FAF8}", "rightwards pushing hand", 1], ["\u{1F44C}", "OK hand", 1], ["\u{1F90C}", "pinched fingers", 1], ["\u{1F90F}", "pinching hand", 1], ["\u270C\uFE0F", "victory hand", 1], ["\u{1F91E}", "crossed fingers", 1], ["\u{1FAF0}", "hand with index finger and thumb crossed", 1], ["\u{1F91F}", "love-you gesture", 1], ["\u{1F918}", "sign of the horns", 1], ["\u{1F919}", "call me hand", 1], ["\u{1F448}", "backhand index pointing left", 1], ["\u{1F449}", "backhand index pointing right", 1], ["\u{1F446}", "backhand index pointing up", 1], ["\u{1F595}", "middle finger", 1], ["\u{1F447}", "backhand index pointing down", 1], ["\u261D\uFE0F", "index pointing up", 1], ["\u{1FAF5}", "index pointing at the viewer", 1], ["\u{1F44D}", "thumbs up", 1], ["\u{1F44E}", "thumbs down", 1], ["\u270A", "raised fist", 1], ["\u{1F44A}", "oncoming fist", 1], ["\u{1F91B}", "left-facing fist", 1], ["\u{1F91C}", "right-facing fist", 1], ["\u{1F44F}", "clapping hands", 1], ["\u{1F64C}", "raising hands", 1], ["\u{1FAF6}", "heart hands", 1], ["\u{1F450}", "open hands", 1], ["\u{1F932}", "palms up together", 1], ["\u{1F91D}", "handshake", 1], ["\u{1F64F}", "folded hands", 1], ["\u270D\uFE0F", "writing hand", 1], ["\u{1F485}", "nail polish", 1], ["\u{1F933}", "selfie", 1], ["\u{1F4AA}", "flexed biceps", 1], ["\u{1F9BE}", "mechanical arm"], ["\u{1F9BF}", "mechanical leg"], ["\u{1F9B5}", "leg", 1], ["\u{1F9B6}", "foot", 1], ["\u{1F442}", "ear", 1], ["\u{1F9BB}", "ear with hearing aid", 1], ["\u{1F443}", "nose", 1], ["\u{1F9E0}", "brain"], ["\u{1FAC0}", "anatomical heart"], ["\u{1FAC1}", "lungs"], ["\u{1F9B7}", "tooth"], ["\u{1F9B4}", "bone"], ["\u{1F440}", "eyes"], ["\u{1F441}\uFE0F", "eye"], ["\u{1F445}", "tongue"], ["\u{1F444}", "mouth"], ["\u{1FAE6}", "biting lip"], ["\u{1F476}", "baby", 1], ["\u{1F9D2}", "child", 1], ["\u{1F466}", "boy", 1], ["\u{1F467}", "girl", 1], ["\u{1F9D1}", "person", 1], ["\u{1F471}", "person: blond hair", 1], ["\u{1F468}", "man", 1], ["\u{1F9D4}", "person: beard", 1], ["\u{1F9D4}\u200D\u2642\uFE0F", "man: beard", 1], ["\u{1F9D4}\u200D\u2640\uFE0F", "woman: beard", 1], ["\u{1F468}\u200D\u{1F9B0}", "man: red hair", 1], ["\u{1F468}\u200D\u{1F9B1}", "man: curly hair", 1], ["\u{1F468}\u200D\u{1F9B3}", "man: white hair", 1], ["\u{1F468}\u200D\u{1F9B2}", "man: bald", 1], ["\u{1F469}", "woman", 1], ["\u{1F469}\u200D\u{1F9B0}", "woman: red hair", 1], ["\u{1F9D1}\u200D\u{1F9B0}", "person: red hair", 1], ["\u{1F469}\u200D\u{1F9B1}", "woman: curly hair", 1], ["\u{1F9D1}\u200D\u{1F9B1}", "person: curly hair", 1], ["\u{1F469}\u200D\u{1F9B3}", "woman: white hair", 1], ["\u{1F9D1}\u200D\u{1F9B3}", "person: white hair", 1], ["\u{1F469}\u200D\u{1F9B2}", "woman: bald", 1], ["\u{1F9D1}\u200D\u{1F9B2}", "person: bald", 1], ["\u{1F471}\u200D\u2640\uFE0F", "woman: blond hair", 1], ["\u{1F471}\u200D\u2642\uFE0F", "man: blond hair", 1], ["\u{1F9D3}", "older person", 1], ["\u{1F474}", "old man", 1], ["\u{1F475}", "old woman", 1], ["\u{1F64D}", "person frowning", 1], ["\u{1F64D}\u200D\u2642\uFE0F", "man frowning", 1], ["\u{1F64D}\u200D\u2640\uFE0F", "woman frowning", 1], ["\u{1F64E}", "person pouting", 1], ["\u{1F64E}\u200D\u2642\uFE0F", "man pouting", 1], ["\u{1F64E}\u200D\u2640\uFE0F", "woman pouting", 1], ["\u{1F645}", "person gesturing NO", 1], ["\u{1F645}\u200D\u2642\uFE0F", "man gesturing NO", 1], ["\u{1F645}\u200D\u2640\uFE0F", "woman gesturing NO", 1], ["\u{1F646}", "person gesturing OK", 1], ["\u{1F646}\u200D\u2642\uFE0F", "man gesturing OK", 1], ["\u{1F646}\u200D\u2640\uFE0F", "woman gesturing OK", 1], ["\u{1F481}", "person tipping hand", 1], ["\u{1F481}\u200D\u2642\uFE0F", "man tipping hand", 1], ["\u{1F481}\u200D\u2640\uFE0F", "woman tipping hand", 1], ["\u{1F64B}", "person raising hand", 1], ["\u{1F64B}\u200D\u2642\uFE0F", "man raising hand", 1], ["\u{1F64B}\u200D\u2640\uFE0F", "woman raising hand", 1], ["\u{1F9CF}", "deaf person", 1], ["\u{1F9CF}\u200D\u2642\uFE0F", "deaf man", 1], ["\u{1F9CF}\u200D\u2640\uFE0F", "deaf woman", 1], ["\u{1F647}", "person bowing", 1], ["\u{1F647}\u200D\u2642\uFE0F", "man bowing", 1], ["\u{1F647}\u200D\u2640\uFE0F", "woman bowing", 1], ["\u{1F926}", "person facepalming", 1], ["\u{1F926}\u200D\u2642\uFE0F", "man facepalming", 1], ["\u{1F926}\u200D\u2640\uFE0F", "woman facepalming", 1], ["\u{1F937}", "person shrugging", 1], ["\u{1F937}\u200D\u2642\uFE0F", "man shrugging", 1], ["\u{1F937}\u200D\u2640\uFE0F", "woman shrugging", 1], ["\u{1F9D1}\u200D\u2695\uFE0F", "health worker", 1], ["\u{1F468}\u200D\u2695\uFE0F", "man health worker", 1], ["\u{1F469}\u200D\u2695\uFE0F", "woman health worker", 1], ["\u{1F9D1}\u200D\u{1F393}", "student", 1], ["\u{1F468}\u200D\u{1F393}", "man student", 1], ["\u{1F469}\u200D\u{1F393}", "woman student", 1], ["\u{1F9D1}\u200D\u{1F3EB}", "teacher", 1], ["\u{1F468}\u200D\u{1F3EB}", "man teacher", 1], ["\u{1F469}\u200D\u{1F3EB}", "woman teacher", 1], ["\u{1F9D1}\u200D\u2696\uFE0F", "judge", 1], ["\u{1F468}\u200D\u2696\uFE0F", "man judge", 1], ["\u{1F469}\u200D\u2696\uFE0F", "woman judge", 1], ["\u{1F9D1}\u200D\u{1F33E}", "farmer", 1], ["\u{1F468}\u200D\u{1F33E}", "man farmer", 1], ["\u{1F469}\u200D\u{1F33E}", "woman farmer", 1], ["\u{1F9D1}\u200D\u{1F373}", "cook", 1], ["\u{1F468}\u200D\u{1F373}", "man cook", 1], ["\u{1F469}\u200D\u{1F373}", "woman cook", 1], ["\u{1F9D1}\u200D\u{1F527}", "mechanic", 1], ["\u{1F468}\u200D\u{1F527}", "man mechanic", 1], ["\u{1F469}\u200D\u{1F527}", "woman mechanic", 1], ["\u{1F9D1}\u200D\u{1F3ED}", "factory worker", 1], ["\u{1F468}\u200D\u{1F3ED}", "man factory worker", 1], ["\u{1F469}\u200D\u{1F3ED}", "woman factory worker", 1], ["\u{1F9D1}\u200D\u{1F4BC}", "office worker", 1], ["\u{1F468}\u200D\u{1F4BC}", "man office worker", 1], ["\u{1F469}\u200D\u{1F4BC}", "woman office worker", 1], ["\u{1F9D1}\u200D\u{1F52C}", "scientist", 1], ["\u{1F468}\u200D\u{1F52C}", "man scientist", 1], ["\u{1F469}\u200D\u{1F52C}", "woman scientist", 1], ["\u{1F9D1}\u200D\u{1F4BB}", "technologist", 1], ["\u{1F468}\u200D\u{1F4BB}", "man technologist", 1], ["\u{1F469}\u200D\u{1F4BB}", "woman technologist", 1], ["\u{1F9D1}\u200D\u{1F3A4}", "singer", 1], ["\u{1F468}\u200D\u{1F3A4}", "man singer", 1], ["\u{1F469}\u200D\u{1F3A4}", "woman singer", 1], ["\u{1F9D1}\u200D\u{1F3A8}", "artist", 1], ["\u{1F468}\u200D\u{1F3A8}", "man artist", 1], ["\u{1F469}\u200D\u{1F3A8}", "woman artist", 1], ["\u{1F9D1}\u200D\u2708\uFE0F", "pilot", 1], ["\u{1F468}\u200D\u2708\uFE0F", "man pilot", 1], ["\u{1F469}\u200D\u2708\uFE0F", "woman pilot", 1], ["\u{1F9D1}\u200D\u{1F680}", "astronaut", 1], ["\u{1F468}\u200D\u{1F680}", "man astronaut", 1], ["\u{1F469}\u200D\u{1F680}", "woman astronaut", 1], ["\u{1F9D1}\u200D\u{1F692}", "firefighter", 1], ["\u{1F468}\u200D\u{1F692}", "man firefighter", 1], ["\u{1F469}\u200D\u{1F692}", "woman firefighter", 1], ["\u{1F46E}", "police officer", 1], ["\u{1F46E}\u200D\u2642\uFE0F", "man police officer", 1], ["\u{1F46E}\u200D\u2640\uFE0F", "woman police officer", 1], ["\u{1F575}\uFE0F", "detective", 1], ["\u{1F575}\uFE0F\u200D\u2642\uFE0F", "man detective", 1], ["\u{1F575}\uFE0F\u200D\u2640\uFE0F", "woman detective", 1], ["\u{1F482}", "guard", 1], ["\u{1F482}\u200D\u2642\uFE0F", "man guard", 1], ["\u{1F482}\u200D\u2640\uFE0F", "woman guard", 1], ["\u{1F977}", "ninja", 1], ["\u{1F477}", "construction worker", 1], ["\u{1F477}\u200D\u2642\uFE0F", "man construction worker", 1], ["\u{1F477}\u200D\u2640\uFE0F", "woman construction worker", 1], ["\u{1FAC5}", "person with crown", 1], ["\u{1F934}", "prince", 1], ["\u{1F478}", "princess", 1], ["\u{1F473}", "person wearing turban", 1], ["\u{1F473}\u200D\u2642\uFE0F", "man wearing turban", 1], ["\u{1F473}\u200D\u2640\uFE0F", "woman wearing turban", 1], ["\u{1F472}", "person with skullcap", 1], ["\u{1F9D5}", "woman with headscarf", 1], ["\u{1F935}", "person in tuxedo", 1], ["\u{1F935}\u200D\u2642\uFE0F", "man in tuxedo", 1], ["\u{1F935}\u200D\u2640\uFE0F", "woman in tuxedo", 1], ["\u{1F470}", "person with veil", 1], ["\u{1F470}\u200D\u2642\uFE0F", "man with veil", 1], ["\u{1F470}\u200D\u2640\uFE0F", "woman with veil", 1], ["\u{1F930}", "pregnant woman", 1], ["\u{1FAC3}", "pregnant man", 1], ["\u{1FAC4}", "pregnant person", 1], ["\u{1F931}", "breast-feeding", 1], ["\u{1F469}\u200D\u{1F37C}", "woman feeding baby", 1], ["\u{1F468}\u200D\u{1F37C}", "man feeding baby", 1], ["\u{1F9D1}\u200D\u{1F37C}", "person feeding baby", 1], ["\u{1F47C}", "baby angel", 1], ["\u{1F385}", "Santa Claus", 1], ["\u{1F936}", "Mrs. Claus", 1], ["\u{1F9D1}\u200D\u{1F384}", "mx claus", 1], ["\u{1F9B8}", "superhero", 1], ["\u{1F9B8}\u200D\u2642\uFE0F", "man superhero", 1], ["\u{1F9B8}\u200D\u2640\uFE0F", "woman superhero", 1], ["\u{1F9B9}", "supervillain", 1], ["\u{1F9B9}\u200D\u2642\uFE0F", "man supervillain", 1], ["\u{1F9B9}\u200D\u2640\uFE0F", "woman supervillain", 1], ["\u{1F9D9}", "mage", 1], ["\u{1F9D9}\u200D\u2642\uFE0F", "man mage", 1], ["\u{1F9D9}\u200D\u2640\uFE0F", "woman mage", 1], ["\u{1F9DA}", "fairy", 1], ["\u{1F9DA}\u200D\u2642\uFE0F", "man fairy", 1], ["\u{1F9DA}\u200D\u2640\uFE0F", "woman fairy", 1], ["\u{1F9DB}", "vampire", 1], ["\u{1F9DB}\u200D\u2642\uFE0F", "man vampire", 1], ["\u{1F9DB}\u200D\u2640\uFE0F", "woman vampire", 1], ["\u{1F9DC}", "merperson", 1], ["\u{1F9DC}\u200D\u2642\uFE0F", "merman", 1], ["\u{1F9DC}\u200D\u2640\uFE0F", "mermaid", 1], ["\u{1F9DD}", "elf", 1], ["\u{1F9DD}\u200D\u2642\uFE0F", "man elf", 1], ["\u{1F9DD}\u200D\u2640\uFE0F", "woman elf", 1], ["\u{1F9DE}", "genie"], ["\u{1F9DE}\u200D\u2642\uFE0F", "man genie"], ["\u{1F9DE}\u200D\u2640\uFE0F", "woman genie"], ["\u{1F9DF}", "zombie"], ["\u{1F9DF}\u200D\u2642\uFE0F", "man zombie"], ["\u{1F9DF}\u200D\u2640\uFE0F", "woman zombie"], ["\u{1F9CC}", "troll"], ["\u{1F486}", "person getting massage", 1], ["\u{1F486}\u200D\u2642\uFE0F", "man getting massage", 1], ["\u{1F486}\u200D\u2640\uFE0F", "woman getting massage", 1], ["\u{1F487}", "person getting haircut", 1], ["\u{1F487}\u200D\u2642\uFE0F", "man getting haircut", 1], ["\u{1F487}\u200D\u2640\uFE0F", "woman getting haircut", 1], ["\u{1F6B6}", "person walking", 1], ["\u{1F6B6}\u200D\u2642\uFE0F", "man walking", 1], ["\u{1F6B6}\u200D\u2640\uFE0F", "woman walking", 1], ["\u{1F9CD}", "person standing", 1], ["\u{1F9CD}\u200D\u2642\uFE0F", "man standing", 1], ["\u{1F9CD}\u200D\u2640\uFE0F", "woman standing", 1], ["\u{1F9CE}", "person kneeling", 1], ["\u{1F9CE}\u200D\u2642\uFE0F", "man kneeling", 1], ["\u{1F9CE}\u200D\u2640\uFE0F", "woman kneeling", 1], ["\u{1F9D1}\u200D\u{1F9AF}", "person with white cane", 1], ["\u{1F468}\u200D\u{1F9AF}", "man with white cane", 1], ["\u{1F469}\u200D\u{1F9AF}", "woman with white cane", 1], ["\u{1F9D1}\u200D\u{1F9BC}", "person in motorized wheelchair", 1], ["\u{1F468}\u200D\u{1F9BC}", "man in motorized wheelchair", 1], ["\u{1F469}\u200D\u{1F9BC}", "woman in motorized wheelchair", 1], ["\u{1F9D1}\u200D\u{1F9BD}", "person in manual wheelchair", 1], ["\u{1F468}\u200D\u{1F9BD}", "man in manual wheelchair", 1], ["\u{1F469}\u200D\u{1F9BD}", "woman in manual wheelchair", 1], ["\u{1F3C3}", "person running", 1], ["\u{1F3C3}\u200D\u2642\uFE0F", "man running", 1], ["\u{1F3C3}\u200D\u2640\uFE0F", "woman running", 1], ["\u{1F483}", "woman dancing", 1], ["\u{1F57A}", "man dancing", 1], ["\u{1F574}\uFE0F", "person in suit levitating", 1], ["\u{1F46F}", "people with bunny ears"], ["\u{1F46F}\u200D\u2642\uFE0F", "men with bunny ears"], ["\u{1F46F}\u200D\u2640\uFE0F", "women with bunny ears"], ["\u{1F9D6}", "person in steamy room", 1], ["\u{1F9D6}\u200D\u2642\uFE0F", "man in steamy room", 1], ["\u{1F9D6}\u200D\u2640\uFE0F", "woman in steamy room", 1], ["\u{1F9D7}", "person climbing", 1], ["\u{1F9D7}\u200D\u2642\uFE0F", "man climbing", 1], ["\u{1F9D7}\u200D\u2640\uFE0F", "woman climbing", 1], ["\u{1F93A}", "person fencing"], ["\u{1F3C7}", "horse racing", 1], ["\u26F7\uFE0F", "skier"], ["\u{1F3C2}", "snowboarder", 1], ["\u{1F3CC}\uFE0F", "person golfing", 1], ["\u{1F3CC}\uFE0F\u200D\u2642\uFE0F", "man golfing", 1], ["\u{1F3CC}\uFE0F\u200D\u2640\uFE0F", "woman golfing", 1], ["\u{1F3C4}", "person surfing", 1], ["\u{1F3C4}\u200D\u2642\uFE0F", "man surfing", 1], ["\u{1F3C4}\u200D\u2640\uFE0F", "woman surfing", 1], ["\u{1F6A3}", "person rowing boat", 1], ["\u{1F6A3}\u200D\u2642\uFE0F", "man rowing boat", 1], ["\u{1F6A3}\u200D\u2640\uFE0F", "woman rowing boat", 1], ["\u{1F3CA}", "person swimming", 1], ["\u{1F3CA}\u200D\u2642\uFE0F", "man swimming", 1], ["\u{1F3CA}\u200D\u2640\uFE0F", "woman swimming", 1], ["\u26F9\uFE0F", "person bouncing ball", 1], ["\u26F9\uFE0F\u200D\u2642\uFE0F", "man bouncing ball", 1], ["\u26F9\uFE0F\u200D\u2640\uFE0F", "woman bouncing ball", 1], ["\u{1F3CB}\uFE0F", "person lifting weights", 1], ["\u{1F3CB}\uFE0F\u200D\u2642\uFE0F", "man lifting weights", 1], ["\u{1F3CB}\uFE0F\u200D\u2640\uFE0F", "woman lifting weights", 1], ["\u{1F6B4}", "person biking", 1], ["\u{1F6B4}\u200D\u2642\uFE0F", "man biking", 1], ["\u{1F6B4}\u200D\u2640\uFE0F", "woman biking", 1], ["\u{1F6B5}", "person mountain biking", 1], ["\u{1F6B5}\u200D\u2642\uFE0F", "man mountain biking", 1], ["\u{1F6B5}\u200D\u2640\uFE0F", "woman mountain biking", 1], ["\u{1F938}", "person cartwheeling", 1], ["\u{1F938}\u200D\u2642\uFE0F", "man cartwheeling", 1], ["\u{1F938}\u200D\u2640\uFE0F", "woman cartwheeling", 1], ["\u{1F93C}", "people wrestling"], ["\u{1F93C}\u200D\u2642\uFE0F", "men wrestling"], ["\u{1F93C}\u200D\u2640\uFE0F", "women wrestling"], ["\u{1F93D}", "person playing water polo", 1], ["\u{1F93D}\u200D\u2642\uFE0F", "man playing water polo", 1], ["\u{1F93D}\u200D\u2640\uFE0F", "woman playing water polo", 1], ["\u{1F93E}", "person playing handball", 1], ["\u{1F93E}\u200D\u2642\uFE0F", "man playing handball", 1], ["\u{1F93E}\u200D\u2640\uFE0F", "woman playing handball", 1], ["\u{1F939}", "person juggling", 1], ["\u{1F939}\u200D\u2642\uFE0F", "man juggling", 1], ["\u{1F939}\u200D\u2640\uFE0F", "woman juggling", 1], ["\u{1F9D8}", "person in lotus position", 1], ["\u{1F9D8}\u200D\u2642\uFE0F", "man in lotus position", 1], ["\u{1F9D8}\u200D\u2640\uFE0F", "woman in lotus position", 1], ["\u{1F6C0}", "person taking bath", 1], ["\u{1F6CC}", "person in bed", 1], ["\u{1F9D1}\u200D\u{1F91D}\u200D\u{1F9D1}", "people holding hands"], ["\u{1F46D}", "women holding hands", 1], ["\u{1F46B}", "woman and man holding hands", 1], ["\u{1F46C}", "men holding hands", 1], ["\u{1F48F}", "kiss", 1], ["\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F468}", "kiss: woman, man"], ["\u{1F468}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F468}", "kiss: man, man"], ["\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F48B}\u200D\u{1F469}", "kiss: woman, woman"], ["\u{1F491}", "couple with heart", 1], ["\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F468}", "couple with heart: woman, man"], ["\u{1F468}\u200D\u2764\uFE0F\u200D\u{1F468}", "couple with heart: man, man"], ["\u{1F469}\u200D\u2764\uFE0F\u200D\u{1F469}", "couple with heart: woman, woman"], ["\u{1F46A}", "family"], ["\u{1F468}\u200D\u{1F469}\u200D\u{1F466}", "family: man, woman, boy"], ["\u{1F468}\u200D\u{1F469}\u200D\u{1F467}", "family: man, woman, girl"], ["\u{1F468}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "family: man, woman, girl, boy"], ["\u{1F468}\u200D\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "family: man, woman, boy, boy"], ["\u{1F468}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "family: man, woman, girl, girl"], ["\u{1F468}\u200D\u{1F468}\u200D\u{1F466}", "family: man, man, boy"], ["\u{1F468}\u200D\u{1F468}\u200D\u{1F467}", "family: man, man, girl"], ["\u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F466}", "family: man, man, girl, boy"], ["\u{1F468}\u200D\u{1F468}\u200D\u{1F466}\u200D\u{1F466}", "family: man, man, boy, boy"], ["\u{1F468}\u200D\u{1F468}\u200D\u{1F467}\u200D\u{1F467}", "family: man, man, girl, girl"], ["\u{1F469}\u200D\u{1F469}\u200D\u{1F466}", "family: woman, woman, boy"], ["\u{1F469}\u200D\u{1F469}\u200D\u{1F467}", "family: woman, woman, girl"], ["\u{1F469}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "family: woman, woman, girl, boy"], ["\u{1F469}\u200D\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "family: woman, woman, boy, boy"], ["\u{1F469}\u200D\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "family: woman, woman, girl, girl"], ["\u{1F468}\u200D\u{1F466}", "family: man, boy"], ["\u{1F468}\u200D\u{1F466}\u200D\u{1F466}", "family: man, boy, boy"], ["\u{1F468}\u200D\u{1F467}", "family: man, girl"], ["\u{1F468}\u200D\u{1F467}\u200D\u{1F466}", "family: man, girl, boy"], ["\u{1F468}\u200D\u{1F467}\u200D\u{1F467}", "family: man, girl, girl"], ["\u{1F469}\u200D\u{1F466}", "family: woman, boy"], ["\u{1F469}\u200D\u{1F466}\u200D\u{1F466}", "family: woman, boy, boy"], ["\u{1F469}\u200D\u{1F467}", "family: woman, girl"], ["\u{1F469}\u200D\u{1F467}\u200D\u{1F466}", "family: woman, girl, boy"], ["\u{1F469}\u200D\u{1F467}\u200D\u{1F467}", "family: woman, girl, girl"], ["\u{1F5E3}\uFE0F", "speaking head"], ["\u{1F464}", "bust in silhouette"], ["\u{1F465}", "busts in silhouette"], ["\u{1FAC2}", "people hugging"], ["\u{1F463}", "footprints"]], nature: [["\u{1F435}", "monkey face"], ["\u{1F412}", "monkey"], ["\u{1F98D}", "gorilla"], ["\u{1F9A7}", "orangutan"], ["\u{1F436}", "dog face"], ["\u{1F415}", "dog"], ["\u{1F9AE}", "guide dog"], ["\u{1F415}\u200D\u{1F9BA}", "service dog"], ["\u{1F429}", "poodle"], ["\u{1F43A}", "wolf"], ["\u{1F98A}", "fox"], ["\u{1F99D}", "raccoon"], ["\u{1F431}", "cat face"], ["\u{1F408}", "cat"], ["\u{1F408}\u200D\u2B1B", "black cat"], ["\u{1F981}", "lion"], ["\u{1F42F}", "tiger face"], ["\u{1F405}", "tiger"], ["\u{1F406}", "leopard"], ["\u{1F434}", "horse face"], ["\u{1FACE}", "moose"], ["\u{1FACF}", "donkey"], ["\u{1F40E}", "horse"], ["\u{1F984}", "unicorn"], ["\u{1F993}", "zebra"], ["\u{1F98C}", "deer"], ["\u{1F9AC}", "bison"], ["\u{1F42E}", "cow face"], ["\u{1F402}", "ox"], ["\u{1F403}", "water buffalo"], ["\u{1F404}", "cow"], ["\u{1F437}", "pig face"], ["\u{1F416}", "pig"], ["\u{1F417}", "boar"], ["\u{1F43D}", "pig nose"], ["\u{1F40F}", "ram"], ["\u{1F411}", "ewe"], ["\u{1F410}", "goat"], ["\u{1F42A}", "camel"], ["\u{1F42B}", "two-hump camel"], ["\u{1F999}", "llama"], ["\u{1F992}", "giraffe"], ["\u{1F418}", "elephant"], ["\u{1F9A3}", "mammoth"], ["\u{1F98F}", "rhinoceros"], ["\u{1F99B}", "hippopotamus"], ["\u{1F42D}", "mouse face"], ["\u{1F401}", "mouse"], ["\u{1F400}", "rat"], ["\u{1F439}", "hamster"], ["\u{1F430}", "rabbit face"], ["\u{1F407}", "rabbit"], ["\u{1F43F}\uFE0F", "chipmunk"], ["\u{1F9AB}", "beaver"], ["\u{1F994}", "hedgehog"], ["\u{1F987}", "bat"], ["\u{1F43B}", "bear"], ["\u{1F43B}\u200D\u2744\uFE0F", "polar bear"], ["\u{1F428}", "koala"], ["\u{1F43C}", "panda"], ["\u{1F9A5}", "sloth"], ["\u{1F9A6}", "otter"], ["\u{1F9A8}", "skunk"], ["\u{1F998}", "kangaroo"], ["\u{1F9A1}", "badger"], ["\u{1F43E}", "paw prints"], ["\u{1F983}", "turkey"], ["\u{1F414}", "chicken"], ["\u{1F413}", "rooster"], ["\u{1F423}", "hatching chick"], ["\u{1F424}", "baby chick"], ["\u{1F425}", "front-facing baby chick"], ["\u{1F426}", "bird"], ["\u{1F427}", "penguin"], ["\u{1F54A}\uFE0F", "dove"], ["\u{1F985}", "eagle"], ["\u{1F986}", "duck"], ["\u{1F9A2}", "swan"], ["\u{1F989}", "owl"], ["\u{1F9A4}", "dodo"], ["\u{1FAB6}", "feather"], ["\u{1F9A9}", "flamingo"], ["\u{1F99A}", "peacock"], ["\u{1F99C}", "parrot"], ["\u{1FABD}", "wing"], ["\u{1F426}\u200D\u2B1B", "black bird"], ["\u{1FABF}", "goose"], ["\u{1F438}", "frog"], ["\u{1F40A}", "crocodile"], ["\u{1F422}", "turtle"], ["\u{1F98E}", "lizard"], ["\u{1F40D}", "snake"], ["\u{1F432}", "dragon face"], ["\u{1F409}", "dragon"], ["\u{1F995}", "sauropod"], ["\u{1F996}", "T-Rex"], ["\u{1F433}", "spouting whale"], ["\u{1F40B}", "whale"], ["\u{1F42C}", "dolphin"], ["\u{1F9AD}", "seal"], ["\u{1F41F}", "fish"], ["\u{1F420}", "tropical fish"], ["\u{1F421}", "blowfish"], ["\u{1F988}", "shark"], ["\u{1F419}", "octopus"], ["\u{1F41A}", "spiral shell"], ["\u{1FAB8}", "coral"], ["\u{1FABC}", "jellyfish"], ["\u{1F40C}", "snail"], ["\u{1F98B}", "butterfly"], ["\u{1F41B}", "bug"], ["\u{1F41C}", "ant"], ["\u{1F41D}", "honeybee"], ["\u{1FAB2}", "beetle"], ["\u{1F41E}", "lady beetle"], ["\u{1F997}", "cricket"], ["\u{1FAB3}", "cockroach"], ["\u{1F577}\uFE0F", "spider"], ["\u{1F578}\uFE0F", "spider web"], ["\u{1F982}", "scorpion"], ["\u{1F99F}", "mosquito"], ["\u{1FAB0}", "fly"], ["\u{1FAB1}", "worm"], ["\u{1F9A0}", "microbe"], ["\u{1F490}", "bouquet"], ["\u{1F338}", "cherry blossom"], ["\u{1F4AE}", "white flower"], ["\u{1FAB7}", "lotus"], ["\u{1F3F5}\uFE0F", "rosette"], ["\u{1F339}", "rose"], ["\u{1F940}", "wilted flower"], ["\u{1F33A}", "hibiscus"], ["\u{1F33B}", "sunflower"], ["\u{1F33C}", "blossom"], ["\u{1F337}", "tulip"], ["\u{1FABB}", "hyacinth"], ["\u{1F331}", "seedling"], ["\u{1FAB4}", "potted plant"], ["\u{1F332}", "evergreen tree"], ["\u{1F333}", "deciduous tree"], ["\u{1F334}", "palm tree"], ["\u{1F335}", "cactus"], ["\u{1F33E}", "sheaf of rice"], ["\u{1F33F}", "herb"], ["\u2618\uFE0F", "shamrock"], ["\u{1F340}", "four leaf clover"], ["\u{1F341}", "maple leaf"], ["\u{1F342}", "fallen leaf"], ["\u{1F343}", "leaf fluttering in wind"], ["\u{1FAB9}", "empty nest"], ["\u{1FABA}", "nest with eggs"], ["\u{1F344}", "mushroom"]], food: [["\u{1F347}", "grapes"], ["\u{1F348}", "melon"], ["\u{1F349}", "watermelon"], ["\u{1F34A}", "tangerine"], ["\u{1F34B}", "lemon"], ["\u{1F34C}", "banana"], ["\u{1F34D}", "pineapple"], ["\u{1F96D}", "mango"], ["\u{1F34E}", "red apple"], ["\u{1F34F}", "green apple"], ["\u{1F350}", "pear"], ["\u{1F351}", "peach"], ["\u{1F352}", "cherries"], ["\u{1F353}", "strawberry"], ["\u{1FAD0}", "blueberries"], ["\u{1F95D}", "kiwi fruit"], ["\u{1F345}", "tomato"], ["\u{1FAD2}", "olive"], ["\u{1F965}", "coconut"], ["\u{1F951}", "avocado"], ["\u{1F346}", "eggplant"], ["\u{1F954}", "potato"], ["\u{1F955}", "carrot"], ["\u{1F33D}", "ear of corn"], ["\u{1F336}\uFE0F", "hot pepper"], ["\u{1FAD1}", "bell pepper"], ["\u{1F952}", "cucumber"], ["\u{1F96C}", "leafy green"], ["\u{1F966}", "broccoli"], ["\u{1F9C4}", "garlic"], ["\u{1F9C5}", "onion"], ["\u{1F95C}", "peanuts"], ["\u{1FAD8}", "beans"], ["\u{1F330}", "chestnut"], ["\u{1FADA}", "ginger root"], ["\u{1FADB}", "pea pod"], ["\u{1F35E}", "bread"], ["\u{1F950}", "croissant"], ["\u{1F956}", "baguette bread"], ["\u{1FAD3}", "flatbread"], ["\u{1F968}", "pretzel"], ["\u{1F96F}", "bagel"], ["\u{1F95E}", "pancakes"], ["\u{1F9C7}", "waffle"], ["\u{1F9C0}", "cheese wedge"], ["\u{1F356}", "meat on bone"], ["\u{1F357}", "poultry leg"], ["\u{1F969}", "cut of meat"], ["\u{1F953}", "bacon"], ["\u{1F354}", "hamburger"], ["\u{1F35F}", "french fries"], ["\u{1F355}", "pizza"], ["\u{1F32D}", "hot dog"], ["\u{1F96A}", "sandwich"], ["\u{1F32E}", "taco"], ["\u{1F32F}", "burrito"], ["\u{1FAD4}", "tamale"], ["\u{1F959}", "stuffed flatbread"], ["\u{1F9C6}", "falafel"], ["\u{1F95A}", "egg"], ["\u{1F373}", "cooking"], ["\u{1F958}", "shallow pan of food"], ["\u{1F372}", "pot of food"], ["\u{1FAD5}", "fondue"], ["\u{1F963}", "bowl with spoon"], ["\u{1F957}", "green salad"], ["\u{1F37F}", "popcorn"], ["\u{1F9C8}", "butter"], ["\u{1F9C2}", "salt"], ["\u{1F96B}", "canned food"], ["\u{1F371}", "bento box"], ["\u{1F358}", "rice cracker"], ["\u{1F359}", "rice ball"], ["\u{1F35A}", "cooked rice"], ["\u{1F35B}", "curry rice"], ["\u{1F35C}", "steaming bowl"], ["\u{1F35D}", "spaghetti"], ["\u{1F360}", "roasted sweet potato"], ["\u{1F362}", "oden"], ["\u{1F363}", "sushi"], ["\u{1F364}", "fried shrimp"], ["\u{1F365}", "fish cake with swirl"], ["\u{1F96E}", "moon cake"], ["\u{1F361}", "dango"], ["\u{1F95F}", "dumpling"], ["\u{1F960}", "fortune cookie"], ["\u{1F961}", "takeout box"], ["\u{1F980}", "crab"], ["\u{1F99E}", "lobster"], ["\u{1F990}", "shrimp"], ["\u{1F991}", "squid"], ["\u{1F9AA}", "oyster"], ["\u{1F366}", "soft ice cream"], ["\u{1F367}", "shaved ice"], ["\u{1F368}", "ice cream"], ["\u{1F369}", "doughnut"], ["\u{1F36A}", "cookie"], ["\u{1F382}", "birthday cake"], ["\u{1F370}", "shortcake"], ["\u{1F9C1}", "cupcake"], ["\u{1F967}", "pie"], ["\u{1F36B}", "chocolate bar"], ["\u{1F36C}", "candy"], ["\u{1F36D}", "lollipop"], ["\u{1F36E}", "custard"], ["\u{1F36F}", "honey pot"], ["\u{1F37C}", "baby bottle"], ["\u{1F95B}", "glass of milk"], ["\u2615", "hot beverage"], ["\u{1FAD6}", "teapot"], ["\u{1F375}", "teacup without handle"], ["\u{1F376}", "sake"], ["\u{1F37E}", "bottle with popping cork"], ["\u{1F377}", "wine glass"], ["\u{1F378}", "cocktail glass"], ["\u{1F379}", "tropical drink"], ["\u{1F37A}", "beer mug"], ["\u{1F37B}", "clinking beer mugs"], ["\u{1F942}", "clinking glasses"], ["\u{1F943}", "tumbler glass"], ["\u{1FAD7}", "pouring liquid"], ["\u{1F964}", "cup with straw"], ["\u{1F9CB}", "bubble tea"], ["\u{1F9C3}", "beverage box"], ["\u{1F9C9}", "mate"], ["\u{1F9CA}", "ice"], ["\u{1F962}", "chopsticks"], ["\u{1F37D}\uFE0F", "fork and knife with plate"], ["\u{1F374}", "fork and knife"], ["\u{1F944}", "spoon"], ["\u{1F52A}", "kitchen knife"], ["\u{1FAD9}", "jar"], ["\u{1F3FA}", "amphora"]], activities: [["\u{1F383}", "jack-o-lantern"], ["\u{1F384}", "Christmas tree"], ["\u{1F386}", "fireworks"], ["\u{1F387}", "sparkler"], ["\u{1F9E8}", "firecracker"], ["\u2728", "sparkles"], ["\u{1F388}", "balloon"], ["\u{1F389}", "party popper"], ["\u{1F38A}", "confetti ball"], ["\u{1F38B}", "tanabata tree"], ["\u{1F38D}", "pine decoration"], ["\u{1F38E}", "Japanese dolls"], ["\u{1F38F}", "carp streamer"], ["\u{1F390}", "wind chime"], ["\u{1F391}", "moon viewing ceremony"], ["\u{1F9E7}", "red envelope"], ["\u{1F380}", "ribbon"], ["\u{1F381}", "wrapped gift"], ["\u{1F397}\uFE0F", "reminder ribbon"], ["\u{1F39F}\uFE0F", "admission tickets"], ["\u{1F3AB}", "ticket"], ["\u{1F396}\uFE0F", "military medal"], ["\u{1F3C6}", "trophy"], ["\u{1F3C5}", "sports medal"], ["\u{1F947}", "1st place medal"], ["\u{1F948}", "2nd place medal"], ["\u{1F949}", "3rd place medal"], ["\u26BD", "soccer ball"], ["\u26BE", "baseball"], ["\u{1F94E}", "softball"], ["\u{1F3C0}", "basketball"], ["\u{1F3D0}", "volleyball"], ["\u{1F3C8}", "american football"], ["\u{1F3C9}", "rugby football"], ["\u{1F3BE}", "tennis"], ["\u{1F94F}", "flying disc"], ["\u{1F3B3}", "bowling"], ["\u{1F3CF}", "cricket game"], ["\u{1F3D1}", "field hockey"], ["\u{1F3D2}", "ice hockey"], ["\u{1F94D}", "lacrosse"], ["\u{1F3D3}", "ping pong"], ["\u{1F3F8}", "badminton"], ["\u{1F94A}", "boxing glove"], ["\u{1F94B}", "martial arts uniform"], ["\u{1F945}", "goal net"], ["\u26F3", "flag in hole"], ["\u26F8\uFE0F", "ice skate"], ["\u{1F3A3}", "fishing pole"], ["\u{1F93F}", "diving mask"], ["\u{1F3BD}", "running shirt"], ["\u{1F3BF}", "skis"], ["\u{1F6F7}", "sled"], ["\u{1F94C}", "curling stone"], ["\u{1F3AF}", "bullseye"], ["\u{1FA80}", "yo-yo"], ["\u{1FA81}", "kite"], ["\u{1F52B}", "water pistol"], ["\u{1F3B1}", "pool 8 ball"], ["\u{1F52E}", "crystal ball"], ["\u{1FA84}", "magic wand"], ["\u{1F3AE}", "video game"], ["\u{1F579}\uFE0F", "joystick"], ["\u{1F3B0}", "slot machine"], ["\u{1F3B2}", "game die"], ["\u{1F9E9}", "puzzle piece"], ["\u{1F9F8}", "teddy bear"], ["\u{1FA85}", "pi\xF1ata"], ["\u{1FAA9}", "mirror ball"], ["\u{1FA86}", "nesting dolls"], ["\u2660\uFE0F", "spade suit"], ["\u2665\uFE0F", "heart suit"], ["\u2666\uFE0F", "diamond suit"], ["\u2663\uFE0F", "club suit"], ["\u265F\uFE0F", "chess pawn"], ["\u{1F0CF}", "joker"], ["\u{1F004}", "mahjong red dragon"], ["\u{1F3B4}", "flower playing cards"], ["\u{1F3AD}", "performing arts"], ["\u{1F5BC}\uFE0F", "framed picture"], ["\u{1F3A8}", "artist palette"], ["\u{1F9F5}", "thread"], ["\u{1FAA1}", "sewing needle"], ["\u{1F9F6}", "yarn"], ["\u{1FAA2}", "knot"]], travel: [["\u{1F30D}", "globe showing Europe-Africa"], ["\u{1F30E}", "globe showing Americas"], ["\u{1F30F}", "globe showing Asia-Australia"], ["\u{1F310}", "globe with meridians"], ["\u{1F5FA}\uFE0F", "world map"], ["\u{1F5FE}", "map of Japan"], ["\u{1F9ED}", "compass"], ["\u{1F3D4}\uFE0F", "snow-capped mountain"], ["\u26F0\uFE0F", "mountain"], ["\u{1F30B}", "volcano"], ["\u{1F5FB}", "mount fuji"], ["\u{1F3D5}\uFE0F", "camping"], ["\u{1F3D6}\uFE0F", "beach with umbrella"], ["\u{1F3DC}\uFE0F", "desert"], ["\u{1F3DD}\uFE0F", "desert island"], ["\u{1F3DE}\uFE0F", "national park"], ["\u{1F3DF}\uFE0F", "stadium"], ["\u{1F3DB}\uFE0F", "classical building"], ["\u{1F3D7}\uFE0F", "building construction"], ["\u{1F9F1}", "brick"], ["\u{1FAA8}", "rock"], ["\u{1FAB5}", "wood"], ["\u{1F6D6}", "hut"], ["\u{1F3D8}\uFE0F", "houses"], ["\u{1F3DA}\uFE0F", "derelict house"], ["\u{1F3E0}", "house"], ["\u{1F3E1}", "house with garden"], ["\u{1F3E2}", "office building"], ["\u{1F3E3}", "Japanese post office"], ["\u{1F3E4}", "post office"], ["\u{1F3E5}", "hospital"], ["\u{1F3E6}", "bank"], ["\u{1F3E8}", "hotel"], ["\u{1F3E9}", "love hotel"], ["\u{1F3EA}", "convenience store"], ["\u{1F3EB}", "school"], ["\u{1F3EC}", "department store"], ["\u{1F3ED}", "factory"], ["\u{1F3EF}", "Japanese castle"], ["\u{1F3F0}", "castle"], ["\u{1F492}", "wedding"], ["\u{1F5FC}", "Tokyo tower"], ["\u{1F5FD}", "Statue of Liberty"], ["\u26EA", "church"], ["\u{1F54C}", "mosque"], ["\u{1F6D5}", "hindu temple"], ["\u{1F54D}", "synagogue"], ["\u26E9\uFE0F", "shinto shrine"], ["\u{1F54B}", "kaaba"], ["\u26F2", "fountain"], ["\u26FA", "tent"], ["\u{1F301}", "foggy"], ["\u{1F303}", "night with stars"], ["\u{1F3D9}\uFE0F", "cityscape"], ["\u{1F304}", "sunrise over mountains"], ["\u{1F305}", "sunrise"], ["\u{1F306}", "cityscape at dusk"], ["\u{1F307}", "sunset"], ["\u{1F309}", "bridge at night"], ["\u2668\uFE0F", "hot springs"], ["\u{1F3A0}", "carousel horse"], ["\u{1F6DD}", "playground slide"], ["\u{1F3A1}", "ferris wheel"], ["\u{1F3A2}", "roller coaster"], ["\u{1F488}", "barber pole"], ["\u{1F3AA}", "circus tent"], ["\u{1F682}", "locomotive"], ["\u{1F683}", "railway car"], ["\u{1F684}", "high-speed train"], ["\u{1F685}", "bullet train"], ["\u{1F686}", "train"], ["\u{1F687}", "metro"], ["\u{1F688}", "light rail"], ["\u{1F689}", "station"], ["\u{1F68A}", "tram"], ["\u{1F69D}", "monorail"], ["\u{1F69E}", "mountain railway"], ["\u{1F68B}", "tram car"], ["\u{1F68C}", "bus"], ["\u{1F68D}", "oncoming bus"], ["\u{1F68E}", "trolleybus"], ["\u{1F690}", "minibus"], ["\u{1F691}", "ambulance"], ["\u{1F692}", "fire engine"], ["\u{1F693}", "police car"], ["\u{1F694}", "oncoming police car"], ["\u{1F695}", "taxi"], ["\u{1F696}", "oncoming taxi"], ["\u{1F697}", "automobile"], ["\u{1F698}", "oncoming automobile"], ["\u{1F699}", "sport utility vehicle"], ["\u{1F6FB}", "pickup truck"], ["\u{1F69A}", "delivery truck"], ["\u{1F69B}", "articulated lorry"], ["\u{1F69C}", "tractor"], ["\u{1F3CE}\uFE0F", "racing car"], ["\u{1F3CD}\uFE0F", "motorcycle"], ["\u{1F6F5}", "motor scooter"], ["\u{1F9BD}", "manual wheelchair"], ["\u{1F9BC}", "motorized wheelchair"], ["\u{1F6FA}", "auto rickshaw"], ["\u{1F6B2}", "bicycle"], ["\u{1F6F4}", "kick scooter"], ["\u{1F6F9}", "skateboard"], ["\u{1F6FC}", "roller skate"], ["\u{1F68F}", "bus stop"], ["\u{1F6E3}\uFE0F", "motorway"], ["\u{1F6E4}\uFE0F", "railway track"], ["\u{1F6E2}\uFE0F", "oil drum"], ["\u26FD", "fuel pump"], ["\u{1F6DE}", "wheel"], ["\u{1F6A8}", "police car light"], ["\u{1F6A5}", "horizontal traffic light"], ["\u{1F6A6}", "vertical traffic light"], ["\u{1F6D1}", "stop sign"], ["\u{1F6A7}", "construction"], ["\u2693", "anchor"], ["\u{1F6DF}", "ring buoy"], ["\u26F5", "sailboat"], ["\u{1F6F6}", "canoe"], ["\u{1F6A4}", "speedboat"], ["\u{1F6F3}\uFE0F", "passenger ship"], ["\u26F4\uFE0F", "ferry"], ["\u{1F6E5}\uFE0F", "motor boat"], ["\u{1F6A2}", "ship"], ["\u2708\uFE0F", "airplane"], ["\u{1F6E9}\uFE0F", "small airplane"], ["\u{1F6EB}", "airplane departure"], ["\u{1F6EC}", "airplane arrival"], ["\u{1FA82}", "parachute"], ["\u{1F4BA}", "seat"], ["\u{1F681}", "helicopter"], ["\u{1F69F}", "suspension railway"], ["\u{1F6A0}", "mountain cableway"], ["\u{1F6A1}", "aerial tramway"], ["\u{1F6F0}\uFE0F", "satellite"], ["\u{1F680}", "rocket"], ["\u{1F6F8}", "flying saucer"], ["\u{1F6CE}\uFE0F", "bellhop bell"], ["\u{1F9F3}", "luggage"], ["\u231B", "hourglass done"], ["\u23F3", "hourglass not done"], ["\u231A", "watch"], ["\u23F0", "alarm clock"], ["\u23F1\uFE0F", "stopwatch"], ["\u23F2\uFE0F", "timer clock"], ["\u{1F570}\uFE0F", "mantelpiece clock"], ["\u{1F55B}", "twelve o\u2019clock"], ["\u{1F567}", "twelve-thirty"], ["\u{1F550}", "one o\u2019clock"], ["\u{1F55C}", "one-thirty"], ["\u{1F551}", "two o\u2019clock"], ["\u{1F55D}", "two-thirty"], ["\u{1F552}", "three o\u2019clock"], ["\u{1F55E}", "three-thirty"], ["\u{1F553}", "four o\u2019clock"], ["\u{1F55F}", "four-thirty"], ["\u{1F554}", "five o\u2019clock"], ["\u{1F560}", "five-thirty"], ["\u{1F555}", "six o\u2019clock"], ["\u{1F561}", "six-thirty"], ["\u{1F556}", "seven o\u2019clock"], ["\u{1F562}", "seven-thirty"], ["\u{1F557}", "eight o\u2019clock"], ["\u{1F563}", "eight-thirty"], ["\u{1F558}", "nine o\u2019clock"], ["\u{1F564}", "nine-thirty"], ["\u{1F559}", "ten o\u2019clock"], ["\u{1F565}", "ten-thirty"], ["\u{1F55A}", "eleven o\u2019clock"], ["\u{1F566}", "eleven-thirty"], ["\u{1F311}", "new moon"], ["\u{1F312}", "waxing crescent moon"], ["\u{1F313}", "first quarter moon"], ["\u{1F314}", "waxing gibbous moon"], ["\u{1F315}", "full moon"], ["\u{1F316}", "waning gibbous moon"], ["\u{1F317}", "last quarter moon"], ["\u{1F318}", "waning crescent moon"], ["\u{1F319}", "crescent moon"], ["\u{1F31A}", "new moon face"], ["\u{1F31B}", "first quarter moon face"], ["\u{1F31C}", "last quarter moon face"], ["\u{1F321}\uFE0F", "thermometer"], ["\u2600\uFE0F", "sun"], ["\u{1F31D}", "full moon face"], ["\u{1F31E}", "sun with face"], ["\u{1FA90}", "ringed planet"], ["\u2B50", "star"], ["\u{1F31F}", "glowing star"], ["\u{1F320}", "shooting star"], ["\u{1F30C}", "milky way"], ["\u2601\uFE0F", "cloud"], ["\u26C5", "sun behind cloud"], ["\u26C8\uFE0F", "cloud with lightning and rain"], ["\u{1F324}\uFE0F", "sun behind small cloud"], ["\u{1F325}\uFE0F", "sun behind large cloud"], ["\u{1F326}\uFE0F", "sun behind rain cloud"], ["\u{1F327}\uFE0F", "cloud with rain"], ["\u{1F328}\uFE0F", "cloud with snow"], ["\u{1F329}\uFE0F", "cloud with lightning"], ["\u{1F32A}\uFE0F", "tornado"], ["\u{1F32B}\uFE0F", "fog"], ["\u{1F32C}\uFE0F", "wind face"], ["\u{1F300}", "cyclone"], ["\u{1F308}", "rainbow"], ["\u{1F302}", "closed umbrella"], ["\u2602\uFE0F", "umbrella"], ["\u2614", "umbrella with rain drops"], ["\u26F1\uFE0F", "umbrella on ground"], ["\u26A1", "high voltage"], ["\u2744\uFE0F", "snowflake"], ["\u2603\uFE0F", "snowman"], ["\u26C4", "snowman without snow"], ["\u2604\uFE0F", "comet"], ["\u{1F525}", "fire"], ["\u{1F4A7}", "droplet"], ["\u{1F30A}", "water wave"]], objects: [["\u{1F453}", "glasses"], ["\u{1F576}\uFE0F", "sunglasses"], ["\u{1F97D}", "goggles"], ["\u{1F97C}", "lab coat"], ["\u{1F9BA}", "safety vest"], ["\u{1F454}", "necktie"], ["\u{1F455}", "t-shirt"], ["\u{1F456}", "jeans"], ["\u{1F9E3}", "scarf"], ["\u{1F9E4}", "gloves"], ["\u{1F9E5}", "coat"], ["\u{1F9E6}", "socks"], ["\u{1F457}", "dress"], ["\u{1F458}", "kimono"], ["\u{1F97B}", "sari"], ["\u{1FA71}", "one-piece swimsuit"], ["\u{1FA72}", "briefs"], ["\u{1FA73}", "shorts"], ["\u{1F459}", "bikini"], ["\u{1F45A}", "woman\u2019s clothes"], ["\u{1FAAD}", "folding hand fan"], ["\u{1F45B}", "purse"], ["\u{1F45C}", "handbag"], ["\u{1F45D}", "clutch bag"], ["\u{1F6CD}\uFE0F", "shopping bags"], ["\u{1F392}", "backpack"], ["\u{1FA74}", "thong sandal"], ["\u{1F45E}", "man\u2019s shoe"], ["\u{1F45F}", "running shoe"], ["\u{1F97E}", "hiking boot"], ["\u{1F97F}", "flat shoe"], ["\u{1F460}", "high-heeled shoe"], ["\u{1F461}", "woman\u2019s sandal"], ["\u{1FA70}", "ballet shoes"], ["\u{1F462}", "woman\u2019s boot"], ["\u{1FAAE}", "hair pick"], ["\u{1F451}", "crown"], ["\u{1F452}", "woman\u2019s hat"], ["\u{1F3A9}", "top hat"], ["\u{1F393}", "graduation cap"], ["\u{1F9E2}", "billed cap"], ["\u{1FA96}", "military helmet"], ["\u26D1\uFE0F", "rescue worker\u2019s helmet"], ["\u{1F4FF}", "prayer beads"], ["\u{1F484}", "lipstick"], ["\u{1F48D}", "ring"], ["\u{1F48E}", "gem stone"], ["\u{1F507}", "muted speaker"], ["\u{1F508}", "speaker low volume"], ["\u{1F509}", "speaker medium volume"], ["\u{1F50A}", "speaker high volume"], ["\u{1F4E2}", "loudspeaker"], ["\u{1F4E3}", "megaphone"], ["\u{1F4EF}", "postal horn"], ["\u{1F514}", "bell"], ["\u{1F515}", "bell with slash"], ["\u{1F3BC}", "musical score"], ["\u{1F3B5}", "musical note"], ["\u{1F3B6}", "musical notes"], ["\u{1F399}\uFE0F", "studio microphone"], ["\u{1F39A}\uFE0F", "level slider"], ["\u{1F39B}\uFE0F", "control knobs"], ["\u{1F3A4}", "microphone"], ["\u{1F3A7}", "headphone"], ["\u{1F4FB}", "radio"], ["\u{1F3B7}", "saxophone"], ["\u{1FA97}", "accordion"], ["\u{1F3B8}", "guitar"], ["\u{1F3B9}", "musical keyboard"], ["\u{1F3BA}", "trumpet"], ["\u{1F3BB}", "violin"], ["\u{1FA95}", "banjo"], ["\u{1F941}", "drum"], ["\u{1FA98}", "long drum"], ["\u{1FA87}", "maracas"], ["\u{1FA88}", "flute"], ["\u{1F4F1}", "mobile phone"], ["\u{1F4F2}", "mobile phone with arrow"], ["\u260E\uFE0F", "telephone"], ["\u{1F4DE}", "telephone receiver"], ["\u{1F4DF}", "pager"], ["\u{1F4E0}", "fax machine"], ["\u{1F50B}", "battery"], ["\u{1FAAB}", "low battery"], ["\u{1F50C}", "electric plug"], ["\u{1F4BB}", "laptop"], ["\u{1F5A5}\uFE0F", "desktop computer"], ["\u{1F5A8}\uFE0F", "printer"], ["\u2328\uFE0F", "keyboard"], ["\u{1F5B1}\uFE0F", "computer mouse"], ["\u{1F5B2}\uFE0F", "trackball"], ["\u{1F4BD}", "computer disk"], ["\u{1F4BE}", "floppy disk"], ["\u{1F4BF}", "optical disk"], ["\u{1F4C0}", "dvd"], ["\u{1F9EE}", "abacus"], ["\u{1F3A5}", "movie camera"], ["\u{1F39E}\uFE0F", "film frames"], ["\u{1F4FD}\uFE0F", "film projector"], ["\u{1F3AC}", "clapper board"], ["\u{1F4FA}", "television"], ["\u{1F4F7}", "camera"], ["\u{1F4F8}", "camera with flash"], ["\u{1F4F9}", "video camera"], ["\u{1F4FC}", "videocassette"], ["\u{1F50D}", "magnifying glass tilted left"], ["\u{1F50E}", "magnifying glass tilted right"], ["\u{1F56F}\uFE0F", "candle"], ["\u{1F4A1}", "light bulb"], ["\u{1F526}", "flashlight"], ["\u{1F3EE}", "red paper lantern"], ["\u{1FA94}", "diya lamp"], ["\u{1F4D4}", "notebook with decorative cover"], ["\u{1F4D5}", "closed book"], ["\u{1F4D6}", "open book"], ["\u{1F4D7}", "green book"], ["\u{1F4D8}", "blue book"], ["\u{1F4D9}", "orange book"], ["\u{1F4DA}", "books"], ["\u{1F4D3}", "notebook"], ["\u{1F4D2}", "ledger"], ["\u{1F4C3}", "page with curl"], ["\u{1F4DC}", "scroll"], ["\u{1F4C4}", "page facing up"], ["\u{1F4F0}", "newspaper"], ["\u{1F5DE}\uFE0F", "rolled-up newspaper"], ["\u{1F4D1}", "bookmark tabs"], ["\u{1F516}", "bookmark"], ["\u{1F3F7}\uFE0F", "label"], ["\u{1F4B0}", "money bag"], ["\u{1FA99}", "coin"], ["\u{1F4B4}", "yen banknote"], ["\u{1F4B5}", "dollar banknote"], ["\u{1F4B6}", "euro banknote"], ["\u{1F4B7}", "pound banknote"], ["\u{1F4B8}", "money with wings"], ["\u{1F4B3}", "credit card"], ["\u{1F9FE}", "receipt"], ["\u{1F4B9}", "chart increasing with yen"], ["\u2709\uFE0F", "envelope"], ["\u{1F4E7}", "e-mail"], ["\u{1F4E8}", "incoming envelope"], ["\u{1F4E9}", "envelope with arrow"], ["\u{1F4E4}", "outbox tray"], ["\u{1F4E5}", "inbox tray"], ["\u{1F4E6}", "package"], ["\u{1F4EB}", "closed mailbox with raised flag"], ["\u{1F4EA}", "closed mailbox with lowered flag"], ["\u{1F4EC}", "open mailbox with raised flag"], ["\u{1F4ED}", "open mailbox with lowered flag"], ["\u{1F4EE}", "postbox"], ["\u{1F5F3}\uFE0F", "ballot box with ballot"], ["\u270F\uFE0F", "pencil"], ["\u2712\uFE0F", "black nib"], ["\u{1F58B}\uFE0F", "fountain pen"], ["\u{1F58A}\uFE0F", "pen"], ["\u{1F58C}\uFE0F", "paintbrush"], ["\u{1F58D}\uFE0F", "crayon"], ["\u{1F4DD}", "memo"], ["\u{1F4BC}", "briefcase"], ["\u{1F4C1}", "file folder"], ["\u{1F4C2}", "open file folder"], ["\u{1F5C2}\uFE0F", "card index dividers"], ["\u{1F4C5}", "calendar"], ["\u{1F4C6}", "tear-off calendar"], ["\u{1F5D2}\uFE0F", "spiral notepad"], ["\u{1F5D3}\uFE0F", "spiral calendar"], ["\u{1F4C7}", "card index"], ["\u{1F4C8}", "chart increasing"], ["\u{1F4C9}", "chart decreasing"], ["\u{1F4CA}", "bar chart"], ["\u{1F4CB}", "clipboard"], ["\u{1F4CC}", "pushpin"], ["\u{1F4CD}", "round pushpin"], ["\u{1F4CE}", "paperclip"], ["\u{1F587}\uFE0F", "linked paperclips"], ["\u{1F4CF}", "straight ruler"], ["\u{1F4D0}", "triangular ruler"], ["\u2702\uFE0F", "scissors"], ["\u{1F5C3}\uFE0F", "card file box"], ["\u{1F5C4}\uFE0F", "file cabinet"], ["\u{1F5D1}\uFE0F", "wastebasket"], ["\u{1F512}", "locked"], ["\u{1F513}", "unlocked"], ["\u{1F50F}", "locked with pen"], ["\u{1F510}", "locked with key"], ["\u{1F511}", "key"], ["\u{1F5DD}\uFE0F", "old key"], ["\u{1F528}", "hammer"], ["\u{1FA93}", "axe"], ["\u26CF\uFE0F", "pick"], ["\u2692\uFE0F", "hammer and pick"], ["\u{1F6E0}\uFE0F", "hammer and wrench"], ["\u{1F5E1}\uFE0F", "dagger"], ["\u2694\uFE0F", "crossed swords"], ["\u{1F4A3}", "bomb"], ["\u{1FA83}", "boomerang"], ["\u{1F3F9}", "bow and arrow"], ["\u{1F6E1}\uFE0F", "shield"], ["\u{1FA9A}", "carpentry saw"], ["\u{1F527}", "wrench"], ["\u{1FA9B}", "screwdriver"], ["\u{1F529}", "nut and bolt"], ["\u2699\uFE0F", "gear"], ["\u{1F5DC}\uFE0F", "clamp"], ["\u2696\uFE0F", "balance scale"], ["\u{1F9AF}", "white cane"], ["\u{1F517}", "link"], ["\u26D3\uFE0F", "chains"], ["\u{1FA9D}", "hook"], ["\u{1F9F0}", "toolbox"], ["\u{1F9F2}", "magnet"], ["\u{1FA9C}", "ladder"], ["\u2697\uFE0F", "alembic"], ["\u{1F9EA}", "test tube"], ["\u{1F9EB}", "petri dish"], ["\u{1F9EC}", "dna"], ["\u{1F52C}", "microscope"], ["\u{1F52D}", "telescope"], ["\u{1F4E1}", "satellite antenna"], ["\u{1F489}", "syringe"], ["\u{1FA78}", "drop of blood"], ["\u{1F48A}", "pill"], ["\u{1FA79}", "adhesive bandage"], ["\u{1FA7C}", "crutch"], ["\u{1FA7A}", "stethoscope"], ["\u{1FA7B}", "x-ray"], ["\u{1F6AA}", "door"], ["\u{1F6D7}", "elevator"], ["\u{1FA9E}", "mirror"], ["\u{1FA9F}", "window"], ["\u{1F6CF}\uFE0F", "bed"], ["\u{1F6CB}\uFE0F", "couch and lamp"], ["\u{1FA91}", "chair"], ["\u{1F6BD}", "toilet"], ["\u{1FAA0}", "plunger"], ["\u{1F6BF}", "shower"], ["\u{1F6C1}", "bathtub"], ["\u{1FAA4}", "mouse trap"], ["\u{1FA92}", "razor"], ["\u{1F9F4}", "lotion bottle"], ["\u{1F9F7}", "safety pin"], ["\u{1F9F9}", "broom"], ["\u{1F9FA}", "basket"], ["\u{1F9FB}", "roll of paper"], ["\u{1FAA3}", "bucket"], ["\u{1F9FC}", "soap"], ["\u{1FAE7}", "bubbles"], ["\u{1FAA5}", "toothbrush"], ["\u{1F9FD}", "sponge"], ["\u{1F9EF}", "fire extinguisher"], ["\u{1F6D2}", "shopping cart"], ["\u{1F6AC}", "cigarette"], ["\u26B0\uFE0F", "coffin"], ["\u{1FAA6}", "headstone"], ["\u26B1\uFE0F", "funeral urn"], ["\u{1F9FF}", "nazar amulet"], ["\u{1FAAC}", "hamsa"], ["\u{1F5FF}", "moai"], ["\u{1FAA7}", "placard"], ["\u{1FAAA}", "identification card"]], symbols: [["\u{1F3E7}", "ATM sign"], ["\u{1F6AE}", "litter in bin sign"], ["\u{1F6B0}", "potable water"], ["\u267F", "wheelchair symbol"], ["\u{1F6B9}", "men\u2019s room"], ["\u{1F6BA}", "women\u2019s room"], ["\u{1F6BB}", "restroom"], ["\u{1F6BC}", "baby symbol"], ["\u{1F6BE}", "water closet"], ["\u{1F6C2}", "passport control"], ["\u{1F6C3}", "customs"], ["\u{1F6C4}", "baggage claim"], ["\u{1F6C5}", "left luggage"], ["\u26A0\uFE0F", "warning"], ["\u{1F6B8}", "children crossing"], ["\u26D4", "no entry"], ["\u{1F6AB}", "prohibited"], ["\u{1F6B3}", "no bicycles"], ["\u{1F6AD}", "no smoking"], ["\u{1F6AF}", "no littering"], ["\u{1F6B1}", "non-potable water"], ["\u{1F6B7}", "no pedestrians"], ["\u{1F4F5}", "no mobile phones"], ["\u{1F51E}", "no one under eighteen"], ["\u2622\uFE0F", "radioactive"], ["\u2623\uFE0F", "biohazard"], ["\u2B06\uFE0F", "up arrow"], ["\u2197\uFE0F", "up-right arrow"], ["\u27A1\uFE0F", "right arrow"], ["\u2198\uFE0F", "down-right arrow"], ["\u2B07\uFE0F", "down arrow"], ["\u2199\uFE0F", "down-left arrow"], ["\u2B05\uFE0F", "left arrow"], ["\u2196\uFE0F", "up-left arrow"], ["\u2195\uFE0F", "up-down arrow"], ["\u2194\uFE0F", "left-right arrow"], ["\u21A9\uFE0F", "right arrow curving left"], ["\u21AA\uFE0F", "left arrow curving right"], ["\u2934\uFE0F", "right arrow curving up"], ["\u2935\uFE0F", "right arrow curving down"], ["\u{1F503}", "clockwise vertical arrows"], ["\u{1F504}", "counterclockwise arrows button"], ["\u{1F519}", "BACK arrow"], ["\u{1F51A}", "END arrow"], ["\u{1F51B}", "ON! arrow"], ["\u{1F51C}", "SOON arrow"], ["\u{1F51D}", "TOP arrow"], ["\u{1F6D0}", "place of worship"], ["\u269B\uFE0F", "atom symbol"], ["\u{1F549}\uFE0F", "om"], ["\u2721\uFE0F", "star of David"], ["\u2638\uFE0F", "wheel of dharma"], ["\u262F\uFE0F", "yin yang"], ["\u271D\uFE0F", "latin cross"], ["\u2626\uFE0F", "orthodox cross"], ["\u262A\uFE0F", "star and crescent"], ["\u262E\uFE0F", "peace symbol"], ["\u{1F54E}", "menorah"], ["\u{1F52F}", "dotted six-pointed star"], ["\u{1FAAF}", "khanda"], ["\u2648", "Aries"], ["\u2649", "Taurus"], ["\u264A", "Gemini"], ["\u264B", "Cancer"], ["\u264C", "Leo"], ["\u264D", "Virgo"], ["\u264E", "Libra"], ["\u264F", "Scorpio"], ["\u2650", "Sagittarius"], ["\u2651", "Capricorn"], ["\u2652", "Aquarius"], ["\u2653", "Pisces"], ["\u26CE", "Ophiuchus"], ["\u{1F500}", "shuffle tracks button"], ["\u{1F501}", "repeat button"], ["\u{1F502}", "repeat single button"], ["\u25B6\uFE0F", "play button"], ["\u23E9", "fast-forward button"], ["\u23ED\uFE0F", "next track button"], ["\u23EF\uFE0F", "play or pause button"], ["\u25C0\uFE0F", "reverse button"], ["\u23EA", "fast reverse button"], ["\u23EE\uFE0F", "last track button"], ["\u{1F53C}", "upwards button"], ["\u23EB", "fast up button"], ["\u{1F53D}", "downwards button"], ["\u23EC", "fast down button"], ["\u23F8\uFE0F", "pause button"], ["\u23F9\uFE0F", "stop button"], ["\u23FA\uFE0F", "record button"], ["\u23CF\uFE0F", "eject button"], ["\u{1F3A6}", "cinema"], ["\u{1F505}", "dim button"], ["\u{1F506}", "bright button"], ["\u{1F4F6}", "antenna bars"], ["\u{1F6DC}", "wireless"], ["\u{1F4F3}", "vibration mode"], ["\u{1F4F4}", "mobile phone off"], ["\u2640\uFE0F", "female sign"], ["\u2642\uFE0F", "male sign"], ["\u26A7\uFE0F", "transgender symbol"], ["\u2716\uFE0F", "multiply"], ["\u2795", "plus"], ["\u2796", "minus"], ["\u2797", "divide"], ["\u{1F7F0}", "heavy equals sign"], ["\u267E\uFE0F", "infinity"], ["\u203C\uFE0F", "double exclamation mark"], ["\u2049\uFE0F", "exclamation question mark"], ["\u2753", "red question mark"], ["\u2754", "white question mark"], ["\u2755", "white exclamation mark"], ["\u2757", "red exclamation mark"], ["\u3030\uFE0F", "wavy dash"], ["\u{1F4B1}", "currency exchange"], ["\u{1F4B2}", "heavy dollar sign"], ["\u2695\uFE0F", "medical symbol"], ["\u267B\uFE0F", "recycling symbol"], ["\u269C\uFE0F", "fleur-de-lis"], ["\u{1F531}", "trident emblem"], ["\u{1F4DB}", "name badge"], ["\u{1F530}", "Japanese symbol for beginner"], ["\u2B55", "hollow red circle"], ["\u2705", "check mark button"], ["\u2611\uFE0F", "check box with check"], ["\u2714\uFE0F", "check mark"], ["\u274C", "cross mark"], ["\u274E", "cross mark button"], ["\u27B0", "curly loop"], ["\u27BF", "double curly loop"], ["\u303D\uFE0F", "part alternation mark"], ["\u2733\uFE0F", "eight-spoked asterisk"], ["\u2734\uFE0F", "eight-pointed star"], ["\u2747\uFE0F", "sparkle"], ["\xA9\uFE0F", "copyright"], ["\xAE\uFE0F", "registered"], ["\u2122\uFE0F", "trade mark"], ["#\uFE0F\u20E3", "keycap: #"], ["*\uFE0F\u20E3", "keycap: *"], ["0\uFE0F\u20E3", "keycap: 0"], ["1\uFE0F\u20E3", "keycap: 1"], ["2\uFE0F\u20E3", "keycap: 2"], ["3\uFE0F\u20E3", "keycap: 3"], ["4\uFE0F\u20E3", "keycap: 4"], ["5\uFE0F\u20E3", "keycap: 5"], ["6\uFE0F\u20E3", "keycap: 6"], ["7\uFE0F\u20E3", "keycap: 7"], ["8\uFE0F\u20E3", "keycap: 8"], ["9\uFE0F\u20E3", "keycap: 9"], ["\u{1F51F}", "keycap: 10"], ["\u{1F520}", "input latin uppercase"], ["\u{1F521}", "input latin lowercase"], ["\u{1F522}", "input numbers"], ["\u{1F523}", "input symbols"], ["\u{1F524}", "input latin letters"], ["\u{1F170}\uFE0F", "A button (blood type)"], ["\u{1F18E}", "AB button (blood type)"], ["\u{1F171}\uFE0F", "B button (blood type)"], ["\u{1F191}", "CL button"], ["\u{1F192}", "COOL button"], ["\u{1F193}", "FREE button"], ["\u2139\uFE0F", "information"], ["\u{1F194}", "ID button"], ["\u24C2\uFE0F", "circled M"], ["\u{1F195}", "NEW button"], ["\u{1F196}", "NG button"], ["\u{1F17E}\uFE0F", "O button (blood type)"], ["\u{1F197}", "OK button"], ["\u{1F17F}\uFE0F", "P button"], ["\u{1F198}", "SOS button"], ["\u{1F199}", "UP! button"], ["\u{1F19A}", "VS button"], ["\u{1F201}", "Japanese \u201Chere\u201D button"], ["\u{1F202}\uFE0F", "Japanese \u201Cservice charge\u201D button"], ["\u{1F237}\uFE0F", "Japanese \u201Cmonthly amount\u201D button"], ["\u{1F236}", "Japanese \u201Cnot free of charge\u201D button"], ["\u{1F22F}", "Japanese \u201Creserved\u201D button"], ["\u{1F250}", "Japanese \u201Cbargain\u201D button"], ["\u{1F239}", "Japanese \u201Cdiscount\u201D button"], ["\u{1F21A}", "Japanese \u201Cfree of charge\u201D button"], ["\u{1F232}", "Japanese \u201Cprohibited\u201D button"], ["\u{1F251}", "Japanese \u201Cacceptable\u201D button"], ["\u{1F238}", "Japanese \u201Capplication\u201D button"], ["\u{1F234}", "Japanese \u201Cpassing grade\u201D button"], ["\u{1F233}", "Japanese \u201Cvacancy\u201D button"], ["\u3297\uFE0F", "Japanese \u201Ccongratulations\u201D button"], ["\u3299\uFE0F", "Japanese \u201Csecret\u201D button"], ["\u{1F23A}", "Japanese \u201Copen for business\u201D button"], ["\u{1F235}", "Japanese \u201Cno vacancy\u201D button"], ["\u{1F534}", "red circle"], ["\u{1F7E0}", "orange circle"], ["\u{1F7E1}", "yellow circle"], ["\u{1F7E2}", "green circle"], ["\u{1F535}", "blue circle"], ["\u{1F7E3}", "purple circle"], ["\u{1F7E4}", "brown circle"], ["\u26AB", "black circle"], ["\u26AA", "white circle"], ["\u{1F7E5}", "red square"], ["\u{1F7E7}", "orange square"], ["\u{1F7E8}", "yellow square"], ["\u{1F7E9}", "green square"], ["\u{1F7E6}", "blue square"], ["\u{1F7EA}", "purple square"], ["\u{1F7EB}", "brown square"], ["\u2B1B", "black large square"], ["\u2B1C", "white large square"], ["\u25FC\uFE0F", "black medium square"], ["\u25FB\uFE0F", "white medium square"], ["\u25FE", "black medium-small square"], ["\u25FD", "white medium-small square"], ["\u25AA\uFE0F", "black small square"], ["\u25AB\uFE0F", "white small square"], ["\u{1F536}", "large orange diamond"], ["\u{1F537}", "large blue diamond"], ["\u{1F538}", "small orange diamond"], ["\u{1F539}", "small blue diamond"], ["\u{1F53A}", "red triangle pointed up"], ["\u{1F53B}", "red triangle pointed down"], ["\u{1F4A0}", "diamond with a dot"], ["\u{1F518}", "radio button"], ["\u{1F533}", "white square button"], ["\u{1F532}", "black square button"], ["\u{1F3C1}", "chequered flag"], ["\u{1F6A9}", "triangular flag"], ["\u{1F38C}", "crossed flags"], ["\u{1F3F4}", "black flag"], ["\u{1F3F3}\uFE0F", "white flag"], ["\u{1F3F3}\uFE0F\u200D\u{1F308}", "rainbow flag"], ["\u{1F3F3}\uFE0F\u200D\u26A7\uFE0F", "transgender flag"], ["\u{1F3F4}\u200D\u2620\uFE0F", "pirate flag"]] };
  }
});

// src/renderer/components/EmojiPicker.tsx
var EmojiPicker_exports = {};
__export(EmojiPicker_exports, {
  EmojiButton: () => EmojiButton
});
import {
  memo,
  useCallback,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState
} from "react";
import { createPortal } from "react-dom";
import { motion } from "motion/react";
import { gestures, quietLift, quietPress, useDismissLayer } from "@vx/modkit/renderer";
import { Fragment as Fragment3, jsx as jsx2, jsxs } from "react/jsx-runtime";
function drawPicture(glyph, done) {
  canvas ??= document.createElement("canvas");
  canvas.width = PICTURE_SIDE;
  canvas.height = PICTURE_SIDE;
  const ink = canvas.getContext("2d");
  if (!ink) return;
  ink.clearRect(0, 0, PICTURE_SIDE, PICTURE_SIDE);
  ink.font = `${PICTURE_SIDE * 0.8}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
  ink.textAlign = "center";
  ink.textBaseline = "alphabetic";
  const size = ink.measureText(glyph);
  const top = size.actualBoundingBoxAscent;
  const bottom = size.actualBoundingBoxDescent;
  ink.fillText(glyph, PICTURE_SIDE / 2, PICTURE_SIDE / 2 + (top - bottom) / 2);
  canvas.toBlob((blob) => {
    if (blob) done(URL.createObjectURL(blob));
  });
}
function loadCatalogue() {
  catalogue ??= Promise.resolve().then(() => __toESM(require_emojiData())).then((module) => module.default);
  return catalogue;
}
function Icon({ children }) {
  return /* @__PURE__ */ jsx2(
    "svg",
    {
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "currentColor",
      strokeWidth: "2.5",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      "aria-hidden": true,
      children
    }
  );
}
function EmojiButton({
  dead = false,
  onPick
}) {
  const [open, setOpen] = useState(false);
  const root = useRef(null);
  const layer = useRef(null);
  const shut = !open || dead;
  useDismissLayer(() => setOpen(false), !shut);
  useEffect(() => {
    if (shut) return;
    const away = (event) => {
      const target = event.target;
      if (event.button !== 0 || root.current?.contains(target) || layer.current?.contains(target)) {
        return;
      }
      setOpen(false);
    };
    window.addEventListener("mousedown", away, true);
    return () => window.removeEventListener("mousedown", away, true);
  }, [shut]);
  const stage = document.getElementById("root");
  useLayoutEffect(() => {
    if (shut || !stage) return;
    const place = () => {
      const button = root.current?.getBoundingClientRect();
      const panel = layer.current;
      if (!button || !panel) return;
      const box = stage.getBoundingClientRect();
      const scale = box.width / stage.offsetWidth || 1;
      panel.style.setProperty("right", `${(box.right - button.right) / scale}px`);
      panel.style.setProperty("bottom", `${(box.bottom - button.top) / scale + 10}px`);
    };
    place();
    window.addEventListener("scroll", place, true);
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("scroll", place, true);
      window.removeEventListener("resize", place);
    };
  }, [shut, stage]);
  const theme = root.current?.closest("[data-theme]")?.getAttribute("data-theme") ?? void 0;
  return /* @__PURE__ */ jsxs("div", { className: "vu-emoji", ref: root, children: [
    /* @__PURE__ */ jsx2(
      motion.button,
      {
        type: "button",
        className: `vu-square vu-emoji-open${open && !dead ? " vu-emoji-open--on" : ""}`,
        "aria-label": "Emoji",
        "aria-expanded": !shut,
        disabled: dead,
        ...gestures(dead, quietLift, quietPress),
        onMouseDown: (e) => e.preventDefault(),
        onClick: () => setOpen((was) => !was),
        children: /* @__PURE__ */ jsx2(Icon, { children: TABS[1].icon })
      }
    ),
    !shut && stage && createPortal(
      /* @__PURE__ */ jsx2("div", { className: "vu-emoji-layer", ref: layer, "data-theme": theme, children: /* @__PURE__ */ jsx2(EmojiPanel, { onPick }) }),
      stage
    )
  ] });
}
function EmojiPanel({ onPick }) {
  const [all, setAll] = useState(null);
  const recent = useEmojiPrefs((s) => s.recent);
  const tone = useEmojiPrefs((s) => s.tone);
  const [tab, setTab] = useState("recent");
  const [query, setQuery] = useState("");
  const [toning, setToning] = useState(false);
  const grid = useRef(null);
  const [topRow, setTopRow] = useState(0);
  useEffect(() => {
    let live = true;
    void loadCatalogue().then((loaded) => live && setAll(loaded));
    return () => {
      live = false;
    };
  }, []);
  const byGlyph = useMemo(
    () => new Map(Object.values(all ?? {}).flat().map((entry) => [entry[0], entry])),
    [all]
  );
  const words = query.trim().toLowerCase();
  const shown = useMemo(() => {
    if (!all) return [];
    if (words) {
      return [...byGlyph.values()].filter(
        ([, name]) => name.split(" ").some((word) => word.startsWith(words)) || name.startsWith(words)
      );
    }
    if (tab === "recent") return recent.map((glyph) => byGlyph.get(glyph) ?? [glyph, glyph]);
    return all[tab] ?? [];
  }, [all, byGlyph, words, tab, recent]);
  const rows = Math.ceil(shown.length / COLUMNS);
  const firstRow = Math.max(0, topRow - ROWS_SPARE);
  const lastRow = Math.min(rows, topRow + ROWS_SHOWN + ROWS_SPARE);
  const onPage = useMemo(
    () => shown.slice(firstRow * COLUMNS, lastRow * COLUMNS),
    [shown, firstRow, lastRow]
  );
  const [, setDrawn] = useState(0);
  useEffect(() => {
    const owed = [
      ...new Set(onPage.map(([glyph, , toneable]) => toneable ? tonedEmoji(glyph, tone) : glyph))
    ].filter((glyph) => !pictures.has(glyph) && !drawing.has(glyph));
    if (owed.length === 0) return;
    let live = true;
    let frame = 0;
    let showing = 0;
    const arrived = () => {
      if (!live || showing) return;
      showing = requestAnimationFrame(() => {
        showing = 0;
        setDrawn((n) => n + 1);
      });
    };
    const step = () => {
      const until = performance.now() + DRAWING_A_FRAME;
      while (owed.length > 0 && performance.now() < until) {
        const glyph = owed.shift();
        drawing.add(glyph);
        drawPicture(glyph, (picture) => {
          pictures.set(glyph, picture);
          drawing.delete(glyph);
          arrived();
        });
      }
      if (owed.length > 0) frame = requestAnimationFrame(step);
    };
    frame = requestAnimationFrame(step);
    return () => {
      live = false;
      cancelAnimationFrame(frame);
      cancelAnimationFrame(showing);
    };
  }, [onPage, tone]);
  useEffect(() => {
    grid.current?.scrollTo({ top: 0 });
    setTopRow(0);
  }, [tab, words]);
  const picked = useRef(onPick);
  picked.current = onPick;
  const pick = useCallback(([glyph, , toneable]) => {
    useEmojiPrefs.getState().used(glyph);
    picked.current(toneable ? tonedEmoji(glyph, useEmojiPrefs.getState().tone) : glyph);
  }, []);
  return /* @__PURE__ */ jsxs("div", { className: "vu-pop vu-emoji-pop", role: "dialog", "aria-label": "Emoji", children: [
    /* @__PURE__ */ jsxs("div", { className: "vu-emoji-head", children: [
      /* @__PURE__ */ jsx2(
        "input",
        {
          className: "vu-input vu-emoji-search",
          value: query,
          placeholder: "Search emoji",
          "aria-label": "Search emoji",
          autoComplete: "off",
          onChange: (e) => setQuery(e.target.value),
          onKeyDown: (e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              e.stopPropagation();
              if (shown[0]) pick(shown[0]);
            }
          }
        }
      ),
      /* @__PURE__ */ jsx2(
        motion.button,
        {
          type: "button",
          className: `vu-emoji-tone${toning ? " vu-emoji-tone--on" : ""}`,
          "aria-label": "Skin tone",
          "aria-expanded": toning,
          ...gestures(false, quietLift, quietPress),
          onMouseDown: (e) => e.preventDefault(),
          onClick: () => setToning((was) => !was),
          children: tonedEmoji(TONE_HAND, tone)
        }
      )
    ] }),
    toning ? /* @__PURE__ */ jsx2("div", { className: "vu-emoji-tones", role: "radiogroup", "aria-label": "Skin tone", children: [null, 0, 1, 2, 3, 4].map((one) => /* @__PURE__ */ jsx2(
      motion.button,
      {
        type: "button",
        role: "radio",
        "aria-checked": tone === one,
        className: `vu-emoji-cell${tone === one ? " vu-emoji-cell--on" : ""}`,
        ...gestures(false, quietLift, quietPress),
        onMouseDown: (e) => e.preventDefault(),
        onClick: () => {
          useEmojiPrefs.getState().setTone(one);
          setToning(false);
        },
        children: tonedEmoji(TONE_HAND, one)
      },
      String(one)
    )) }) : /* @__PURE__ */ jsx2("div", { className: "vu-emoji-tabs", role: "tablist", children: TABS.map((one) => /* @__PURE__ */ jsx2(
      motion.button,
      {
        type: "button",
        role: "tab",
        "aria-label": one.label,
        "aria-selected": !words && tab === one.id,
        className: `vu-emoji-tab${!words && tab === one.id ? " vu-emoji-tab--on" : ""}`,
        ...gestures(false, quietLift, quietPress),
        onMouseDown: (e) => e.preventDefault(),
        onClick: () => {
          setTab(one.id);
          setQuery("");
        },
        children: /* @__PURE__ */ jsx2(Icon, { children: one.icon })
      },
      one.id
    )) }),
    /* @__PURE__ */ jsxs("div", { className: "vu-emoji-scroll", children: [
      /* @__PURE__ */ jsxs(
        "div",
        {
          className: "vu-emoji-grid",
          ref: grid,
          onScroll: (e) => setTopRow(Math.floor(e.currentTarget.scrollTop / ROW)),
          children: [
            firstRow > 0 && /* @__PURE__ */ jsx2("div", { className: "vu-emoji-gap", style: { height: firstRow * ROW } }),
            onPage.map((entry) => /* @__PURE__ */ jsx2(
              EmojiCell,
              {
                entry,
                tone: entry[2] ? tone : null,
                picture: pictures.get(entry[2] ? tonedEmoji(entry[0], tone) : entry[0]),
                onPick: pick
              },
              entry[0]
            )),
            lastRow < rows && /* @__PURE__ */ jsx2("div", { className: "vu-emoji-gap", style: { height: (rows - lastRow) * ROW } }),
            all && shown.length === 0 && /* @__PURE__ */ jsx2("p", { className: "vu-empty vu-empty--flush", children: "No emoji found" })
          ]
        }
      ),
      /* @__PURE__ */ jsx2("div", { className: "vu-scroll-fade" })
    ] })
  ] });
}
var TABS, TONE_HAND, pictures, PICTURE_SIDE, canvas, DRAWING_A_FRAME, COLUMNS, ROW, ROWS_SHOWN, ROWS_SPARE, drawing, catalogue, EmojiCell;
var init_EmojiPicker2 = __esm({
  "src/renderer/components/EmojiPicker.tsx"() {
    init_emojiPrefs();
    init_EmojiPicker();
    TABS = [
      {
        id: "recent",
        label: "Recent",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("circle", { cx: "12", cy: "12", r: "10" }),
          /* @__PURE__ */ jsx2("polyline", { points: "12 6 12 12 16 14" })
        ] })
      },
      {
        id: "smileys",
        label: "Smileys",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("circle", { cx: "12", cy: "12", r: "10" }),
          /* @__PURE__ */ jsx2("path", { d: "M8 14s1.5 2 4 2 4-2 4-2" }),
          /* @__PURE__ */ jsx2("line", { x1: "9", y1: "9", x2: "9.01", y2: "9" }),
          /* @__PURE__ */ jsx2("line", { x1: "15", y1: "9", x2: "15.01", y2: "9" })
        ] })
      },
      {
        id: "people",
        label: "People",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("path", { d: "M18 11V6a2 2 0 0 0-4 0" }),
          /* @__PURE__ */ jsx2("path", { d: "M14 10V4a2 2 0 0 0-4 0v2" }),
          /* @__PURE__ */ jsx2("path", { d: "M10 10.5V6a2 2 0 0 0-4 0v8" }),
          /* @__PURE__ */ jsx2("path", { d: "M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-6-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15" })
        ] })
      },
      {
        id: "nature",
        label: "Animals and nature",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("circle", { cx: "11", cy: "4", r: "2" }),
          /* @__PURE__ */ jsx2("circle", { cx: "18", cy: "8", r: "2" }),
          /* @__PURE__ */ jsx2("circle", { cx: "20", cy: "16", r: "2" }),
          /* @__PURE__ */ jsx2("path", { d: "M9 10a5 5 0 0 1 5 5v3.5a3.5 3.5 0 0 1-6.84 1.05Q6.52 17.48 4.46 16.84A3.5 3.5 0 0 1 5.5 10Z" })
        ] })
      },
      {
        id: "food",
        label: "Food and drink",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("path", { d: "M12 20.94c1.5 0 2.75 1.06 4 1.06 3 0 6-8 6-12.22A4.91 4.91 0 0 0 17 5c-2.22 0-4 1.44-5 2-1-.56-2.78-2-5-2a4.9 4.9 0 0 0-5 4.78C2 14 5 22 8 22c1.25 0 2.5-1.06 4-1.06Z" }),
          /* @__PURE__ */ jsx2("path", { d: "M10 2c1 .5 2 2 2 5" })
        ] })
      },
      {
        id: "activities",
        label: "Activities",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("path", { d: "M6 9H4.5a2.5 2.5 0 0 1 0-5H6" }),
          /* @__PURE__ */ jsx2("path", { d: "M18 9h1.5a2.5 2.5 0 0 0 0-5H18" }),
          /* @__PURE__ */ jsx2("path", { d: "M4 22h16" }),
          /* @__PURE__ */ jsx2("path", { d: "M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22" }),
          /* @__PURE__ */ jsx2("path", { d: "M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22" }),
          /* @__PURE__ */ jsx2("path", { d: "M18 2H6v7a6 6 0 0 0 12 0V2Z" })
        ] })
      },
      {
        id: "travel",
        label: "Travel and places",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("path", { d: "M19 17h2c.6 0 1-.4 1-1v-3c0-.9-.7-1.7-1.5-1.9C18.7 10.6 16 10 16 10s-1.3-1.4-2.2-2.3c-.5-.4-1.1-.7-1.8-.7H5c-.6 0-1.1.4-1.4.9l-1.4 2.9A3.7 3.7 0 0 0 2 12v4c0 .6.4 1 1 1h2" }),
          /* @__PURE__ */ jsx2("circle", { cx: "7", cy: "17", r: "2" }),
          /* @__PURE__ */ jsx2("path", { d: "M9 17h6" }),
          /* @__PURE__ */ jsx2("circle", { cx: "17", cy: "17", r: "2" })
        ] })
      },
      {
        id: "objects",
        label: "Objects",
        icon: /* @__PURE__ */ jsxs(Fragment3, { children: [
          /* @__PURE__ */ jsx2("path", { d: "M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5" }),
          /* @__PURE__ */ jsx2("path", { d: "M9 18h6" }),
          /* @__PURE__ */ jsx2("path", { d: "M10 22h4" })
        ] })
      },
      {
        id: "symbols",
        label: "Symbols",
        icon: /* @__PURE__ */ jsx2("path", { d: "M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" })
      }
    ];
    TONE_HAND = "\u270B";
    pictures = /* @__PURE__ */ new Map();
    PICTURE_SIDE = 64;
    canvas = null;
    DRAWING_A_FRAME = 4;
    COLUMNS = 8;
    ROW = 42;
    ROWS_SHOWN = 7;
    ROWS_SPARE = 3;
    drawing = /* @__PURE__ */ new Set();
    catalogue = null;
    EmojiCell = memo(function EmojiCell2({
      entry,
      tone,
      picture,
      onPick
    }) {
      return /* @__PURE__ */ jsx2(
        "button",
        {
          type: "button",
          className: "vu-emoji-cell",
          "aria-label": entry[1],
          onMouseDown: (e) => e.preventDefault(),
          onClick: () => onPick(entry),
          children: picture ? /* @__PURE__ */ jsx2("img", { className: "vu-emoji-pic", src: picture, alt: "", draggable: false }) : tonedEmoji(entry[0], tone)
        }
      );
    });
  }
});

// src/renderer/modEntries/emoji-extended.ts
import { createElement, lazy, Suspense } from "react";
import { registerHooks } from "@vx/modkit/renderer";

// src/renderer/components/EmojiText.tsx
import { Fragment } from "react";
import { Fragment as Fragment2, jsx } from "react/jsx-runtime";
var BIG_AT_MOST = 3;
function isEmoji(grapheme) {
  return /\p{Emoji_Presentation}|\p{Regional_Indicator}|[\ufe0f\u20e3\u200d]/u.test(grapheme);
}
var graphemes = new Intl.Segmenter(void 0, { granularity: "grapheme" });
function runsOf(text) {
  const runs = [];
  for (const { segment } of graphemes.segment(text)) {
    const emoji = isEmoji(segment);
    const last = runs[runs.length - 1];
    if (last && last.emoji === emoji) last.text += segment;
    else runs.push({ emoji, text: segment });
  }
  return runs;
}
function emojiOnly(text) {
  const kept2 = [...graphemes.segment(text.trim())].map(({ segment }) => segment);
  const emoji = kept2.filter((one) => one.trim() !== "");
  return emoji.length > 0 && emoji.length <= BIG_AT_MOST && emoji.every(isEmoji);
}
function EmojiText({ text, big = true }) {
  if (big && emojiOnly(text)) return /* @__PURE__ */ jsx("span", { className: "vu-emoji-big", children: text.trim() });
  return /* @__PURE__ */ jsx(Fragment2, { children: runsOf(text).map(
    (run, i) => run.emoji ? /* @__PURE__ */ jsx("span", { className: "vu-emoji-inline", children: run.text }, i) : /* @__PURE__ */ jsx(Fragment, { children: run.text }, i)
  ) });
}

// src/renderer/modEntries/emoji-extended.ts
var LazyButton = lazy(
  () => Promise.resolve().then(() => (init_EmojiPicker2(), EmojiPicker_exports)).then((module) => ({ default: module.EmojiButton }))
);
function EmojiToolView(props) {
  return createElement(Suspense, { fallback: null }, createElement(LazyButton, props));
}
registerHooks("emoji-extended", {
  // Every emoji, beside the phone's field and any mod's own box, in place of the row of eight.
  emojiTool: EmojiToolView,
  // Emoji a size up among words, and a message of one to three drawn big with no bubble.
  sentText: { Text: EmojiText, bare: emojiOnly }
});
