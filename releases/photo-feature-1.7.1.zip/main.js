var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/main/modEntries/photo-feature.ts
var photo_feature_exports = {};
__export(photo_feature_exports, {
  photoMainEntry: () => photoMainEntry
});
var import_main4 = require("@vx/modkit/main");

// src/shared/photoLoader.ts
var PHOTO_LOADERS = [
  { value: "bunny", label: "Bunny hop" },
  { value: "shimmer", label: "Dot shimmer" },
  { value: "dots", label: "Typing dots" }
];

// src/shared/photoDefinition.ts
var PHOTO_FEATURE_ID = "photo-feature";
var PHOTO_FEATURE_MOD = {
  id: PHOTO_FEATURE_ID,
  name: "Photo Feature",
  author: "naudh1r",
  scope: "anytime",
  defaultOn: false,
  blurb: "The girls send photos in their DMs and post them on their feeds, with comments from the rest of campus. Adds a gallery to each contact and optional body details for characters. Separate from the game's own Photos tab, where you make pictures yourself. Needs ComfyUI to draw the pictures, the game's own or yours.",
  offNote: "Off, nobody takes a new photo, posts get no new comments and body details are not used. Photos, galleries and comments already made are hidden. Nothing is deleted: everything comes back when it is on again.",
  options: [
    {
      id: "photos",
      label: "Photo generation",
      hint: "Off, no new photos are made, and characters don't know they can send one. Photos already sent stay visible.",
      default: true
    },
    {
      id: "explicit",
      label: "Explicit photos",
      hint: "Off, nobody sends an undressed photo, and ones already sent stay covered. Settings \u2192 No NSFW images turns them off too.",
      default: true
    },
    {
      id: "body",
      label: "Body details",
      hint: "Gives characters a build and body shape for their pictures. Set them from the main menu, in Manage Characters, under a character's Generation settings.",
      default: false
    },
    {
      id: "duo",
      label: "2 girls 1 photo (experimental)",
      hint: "A girl's feed post can be a photo of her and a friend, and a scene you are in with other girls can bring a photo of two of them, posted on one's feed. Always two girls, never more. Still being tuned: now and then a face, an outfit or a colour comes out wrong.",
      default: false
    },
    {
      id: "webp",
      label: "Save photos as WebP",
      hint: "New photos are saved as WebP, with no visible quality loss while taking much less space than PNG. Off, they are saved as PNG. Photos already saved stay as they are.",
      default: true
    },
    // One of these is on at a time: the store turns the others off.
    ...PHOTO_LOADERS.map((loader) => ({
      id: `loader-${loader.value}`,
      label: loader.label,
      hint: "",
      default: loader.value === "bunny",
      group: "loader"
    }))
  ],
  optionGroups: [
    {
      id: "loader",
      label: "Loading animation",
      hint: "The animation shown while a photo is being made."
    }
  ]
};

// src/shared/photoSwitches.ts
var import_shared = require("@vx/modkit/shared");
var DEFAULT_PHOTO_SWITCHES = {
  on: true,
  photos: true,
  explicit: true,
  loader: "bunny",
  webp: true,
  body: false,
  duo: false
};
var readOption = null;
var snapshot = DEFAULT_PHOTO_SWITCHES;
function bindPhotoOptionReader(reader) {
  readOption = reader;
}
function photoSwitches() {
  const option = readOption;
  if (!option) return DEFAULT_PHOTO_SWITCHES;
  const next = {
    on: (0, import_shared.sharedModOn)(PHOTO_FEATURE_ID),
    photos: option("photos"),
    explicit: option("explicit"),
    webp: option("webp"),
    body: option("body"),
    duo: option("duo"),
    loader: PHOTO_LOADERS.find((loader) => option(loaderOptionId(loader.value)))?.value ?? "bunny"
  };
  if (Object.keys(next).some((key) => next[key] !== snapshot[key])) snapshot = next;
  return snapshot;
}
function photoFeatureOn() {
  return readOption ? (0, import_shared.sharedModOn)(PHOTO_FEATURE_ID) : DEFAULT_PHOTO_SWITCHES.on;
}
function loaderOptionId(loader) {
  return `loader-${loader}`;
}

// src/main/localPhotoBackup.ts
var import_os = require("os");
var import_promises2 = require("fs/promises");
var import_path2 = require("path");
var import_main2 = require("@vx/modkit/main");
var import_shared4 = require("@vx/modkit/shared");

// src/shared/photoFiles.ts
var PHOTO_KINDS = ["bunnyboard", "chat"];
function isPhotoKind(value) {
  return PHOTO_KINDS.includes(value);
}
var PHOTO_FILE = /^[a-z0-9]+_(?:bunnyboard|chat)_\d{3,6}\.(?:png|webp)$/;
var LEGACY_PHOTO_FILE = /^photo_\d{1,20}_[a-f0-9]{8}\.png$/;
function isPhotoFile(file) {
  return PHOTO_FILE.test(file) || LEGACY_PHOTO_FILE.test(file);
}
function photoSidecarOf(file) {
  return file.replace(/\.(?:png|webp)$/, ".json");
}
function isPhotoSidecar(name) {
  return name.endsWith(".json") && isPhotoFile(name.slice(0, -5) + ".png");
}
var INDEX_DIGITS = 3;
function photoSlug(firstName, charId) {
  const slug = firstName.toLowerCase().replace(/[^a-z0-9]/g, "");
  return slug.length > 0 ? slug : charId.toLowerCase().replace(/[^a-z0-9]/g, "").slice(0, 8);
}
function photoFileName(slug, kind, index, format = "png") {
  return `${slug}_${kind}_${String(index).padStart(INDEX_DIGITS, "0")}.${format}`;
}
function isWebpPhoto(file) {
  return isPhotoFile(file) && file.endsWith(".webp");
}
function pngPhotoOf(file) {
  return file.replace(/\.webp$/, ".png");
}
function photoIndexOf(file, slug, kind) {
  const match = new RegExp(`^${slug}_${kind}_(\\d{${INDEX_DIGITS},6})\\.(?:png|webp)$`).exec(file);
  return match ? Number(match[1]) : null;
}
function nextPhotoIndex(taken, slug, kind) {
  let highest = 0;
  for (const file of taken) {
    const index = photoIndexOf(file, slug, kind);
    if (index !== null && index > highest) highest = index;
  }
  return highest + 1;
}

// src/main/photoFiles.ts
var import_fs = require("fs");
var import_promises = require("fs/promises");
var import_path = require("path");
var import_main = require("@vx/modkit/main");
var import_shared3 = require("@vx/modkit/shared");

// src/shared/photoWords.ts
var WORD_CHAR = "[a-z0-9]";
var compiled = /* @__PURE__ */ new Map();
function patternOf(cue) {
  const cached = compiled.get(cue);
  if (cached) return cached;
  const stem = cue.endsWith("*");
  const body = (stem ? cue.slice(0, -1) : cue).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const tail = stem ? `${WORD_CHAR}*` : "(?:s|es)?";
  const pattern = new RegExp(`(?<!${WORD_CHAR})${body}${tail}(?!${WORD_CHAR})`);
  compiled.set(cue, pattern);
  return pattern;
}
function says(text, cue) {
  return patternOf(cue).test(text);
}
function saysAny(text, cues) {
  return cues.some((cue) => says(text, cue));
}

// src/shared/photoGate.ts
var import_shared2 = require("@vx/modkit/shared");
var PHOTO_TIERS = ["none", "everyday", "suggestive", "explicit"];
function isPhotoTier(value) {
  return PHOTO_TIERS.includes(value);
}

// src/main/photoFiles.ts
function getPhotosRoot(pid) {
  return (0, import_main.modDataPath)(PHOTO_FEATURE_ID, pid);
}
function photoPlaythroughPath(pid) {
  (0, import_shared3.assertSafePlaythroughId)(pid);
  try {
    return (0, import_path.join)((0, import_main.modDataPath)(PHOTO_FEATURE_ID, pid), "..", "..");
  } catch {
    return (0, import_path.join)((0, import_main.modDataPath)(PHOTO_FEATURE_ID), "..", "..", "saves", pid);
  }
}
function legacyPhotosRoot(pid) {
  return (0, import_path.join)(photoPlaythroughPath(pid), "photos");
}
function getPhotosPath(pid, charId) {
  (0, import_shared3.assertSafeCharId)(charId);
  return (0, import_path.join)(getPhotosRoot(pid), charId);
}
function getPhotoPath(pid, charId, file) {
  return (0, import_path.join)(getPhotosPath(pid, charId), file);
}
function isPhotoImage(file) {
  return isPhotoFile(file) || file.endsWith(".webp") && isPhotoFile(file.replace(/\.webp$/, ".png"));
}
async function regularFile(path) {
  try {
    return (await (0, import_promises.lstat)(path)).isFile();
  } catch (error) {
    if (error.code === "ENOENT") return false;
    throw error;
  }
}
async function photoCharacters(root) {
  try {
    return (await (0, import_promises.readdir)(root, { withFileTypes: true })).filter((entry) => entry.isDirectory() && import_shared3.SAFE_CHAR_ID.test(entry.name)).map((entry) => entry.name);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}
async function photoNames(folder) {
  try {
    return (await (0, import_promises.readdir)(folder, { withFileTypes: true })).filter((entry) => entry.isFile() && (isPhotoImage(entry.name) || isPhotoSidecar(entry.name))).map((entry) => entry.name);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}
async function readPhotoSidecar(path) {
  try {
    if (!await regularFile(path) || (await (0, import_promises.lstat)(path)).size >= 256 * 1024) return void 0;
    const info = JSON.parse(await (0, import_promises.readFile)(path, "utf8"));
    if (!info || info.schemaVersion !== 1 || !Number.isSafeInteger(info.seed) || info.seed < 0 || !isPhotoTier(info.tier) || typeof info.positive !== "string" || typeof info.negative !== "string" || info.left !== void 0 && typeof info.left !== "string" || info.right !== void 0 && typeof info.right !== "string" || info.left === void 0 !== (info.right === void 0) || info.lora !== void 0 && (!info.lora || typeof info.lora.name !== "string" || typeof info.lora.weight !== "number" || !Number.isFinite(info.lora.weight))) return void 0;
    return info;
  } catch {
    return void 0;
  }
}
async function validPhotoFile(path) {
  if (!await regularFile(path)) return false;
  return isPhotoSidecar(path.split(/[\\/]/).at(-1)) ? await readPhotoSidecar(path) !== void 0 : await (0, import_main.sniffImageFile)(path) !== null;
}
async function copyPhotoFile(source, dest, keepExisting = false) {
  if (!await validPhotoFile(source)) {
    throw (0, import_shared3.appError)("PHOTO_FILE_INVALID", "The photo file is unreadable.", (0, import_path.basename)(source));
  }
  await (0, import_promises.mkdir)((0, import_path.dirname)(dest), { recursive: true });
  if (await regularFile(dest)) {
    if (keepExisting) return;
    if (!await validPhotoFile(dest)) {
      await (0, import_main.writeAtomicBytes)(dest, await (0, import_promises.readFile)(source), {
        code: "PHOTO_COPY_FAILED",
        message: "Could not copy the photo."
      });
    }
  } else {
    await (0, import_promises.copyFile)(source, dest, import_fs.constants.COPYFILE_EXCL);
  }
  const before = await (0, import_promises.lstat)(source), after = await (0, import_promises.lstat)(dest);
  if (before.size !== after.size || !await validPhotoFile(dest) || !(await (0, import_promises.readFile)(source)).equals(await (0, import_promises.readFile)(dest))) {
    throw (0, import_shared3.appError)("PHOTO_COPY_FAILED", "The photo copy could not be verified.");
  }
}
async function photoReferences(pid) {
  const root = photoPlaythroughPath(pid);
  const saved = /* @__PURE__ */ new Set(), all = /* @__PURE__ */ new Set();
  const collect = (value, target) => {
    if (!value || typeof value !== "object") return;
    if ("file" in value && typeof value.file === "string" && isPhotoFile(value.file)) {
      target.add(pngPhotoOf(value.file));
    }
    for (const child of Object.values(value)) collect(child, target);
  };
  for (const name of await (0, import_promises.readdir)(root)) {
    if (name.endsWith(".json")) collect(JSON.parse(await (0, import_promises.readFile)((0, import_path.join)(root, name), "utf8")), saved);
  }
  for (const name of saved) all.add(name);
  let replays = [];
  try {
    replays = await (0, import_promises.readdir)((0, import_path.join)(root, "replays"));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }
  for (const name of replays) {
    if (name.endsWith(".json")) {
      collect(JSON.parse(await (0, import_promises.readFile)((0, import_path.join)(root, "replays", name), "utf8")), all);
    }
  }
  return { saved, all };
}
var moves = /* @__PURE__ */ new Map();
var idleMoves = /* @__PURE__ */ new Set();
function forgetPhotoMoves() {
  idleMoves.clear();
}
async function photoMoveSettled(pid) {
  await moves.get(legacyPhotosRoot(pid))?.catch(() => {
  });
}
var settledMoves = /* @__PURE__ */ new Set();
async function afterOneMove(pid, known, work) {
  await movePhotoFiles(pid, known);
  if (settledMoves.has(pid)) return work();
  settledMoves.add(pid);
  try {
    return await work();
  } finally {
    settledMoves.delete(pid);
  }
}
async function movePhotoFiles(pid, known) {
  (0, import_shared3.assertSafePlaythroughId)(pid);
  if (settledMoves.has(pid) || idleMoves.has(pid)) return;
  const oldRoot = legacyPhotosRoot(pid);
  const running = moves.get(oldRoot);
  if (running) return running;
  const moving = (async () => {
    const who = await photoCharacters(oldRoot);
    const waiting = /* @__PURE__ */ new Map();
    for (const charId of who) {
      const names = await photoNames((0, import_path.join)(oldRoot, charId));
      if (names.length > 0) waiting.set(charId, names);
    }
    if (waiting.size === 0) {
      idleMoves.add(pid);
      return;
    }
    const refs = known ?? await photoReferences(pid).catch(() => null);
    let moved = 0;
    for (const [charId, names] of waiting) {
      const folder = (0, import_path.join)(oldRoot, charId);
      names.sort((a, b) => Number(refs?.all.has(pngPhotoOf(b))) - Number(refs?.all.has(pngPhotoOf(a))));
      for (const file of names) {
        try {
          await copyPhotoFile((0, import_path.join)(folder, file), getPhotoPath(pid, charId, file));
          if (refs) {
            await (0, import_promises.rm)((0, import_path.join)(folder, file));
            moved += 1;
          }
        } catch (error) {
          console.warn("[photo] kept an unmoved legacy file:", file, error);
        }
      }
      await (0, import_promises.rmdir)(folder).catch(() => {
      });
    }
    if (moved === 0) idleMoves.add(pid);
  })();
  moves.set(oldRoot, moving);
  try {
    await moving;
  } finally {
    if (moves.get(oldRoot) === moving) moves.delete(oldRoot);
  }
}
function photoReadRoots(pid) {
  const legacy = legacyPhotosRoot(pid);
  try {
    return [getPhotosRoot(pid), legacy];
  } catch {
    return [legacy];
  }
}
async function findPhotoImage(pid, charId, file) {
  (0, import_shared3.assertSafeCharId)(charId);
  await movePhotoFiles(pid).catch((error) => console.warn("[photo] legacy move will retry:", error));
  for (const root of photoReadRoots(pid)) {
    for (const name of [file.replace(/\.(png|webp)$/, ".webp"), pngPhotoOf(file)]) {
      const path = (0, import_path.join)(root, charId, name);
      if (await regularFile(path)) return path;
    }
  }
  return null;
}
async function readPhotoImage(pid, charId, file) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const path = await findPhotoImage(pid, charId, file);
    if (!path) break;
    try {
      return new Uint8Array(await (0, import_promises.readFile)(path));
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  throw (0, import_shared3.appError)("PHOTO_MISSING", "That picture is not on disk.", file);
}
async function findPhotoSidecar(pid, charId, file) {
  await movePhotoFiles(pid).catch((error) => console.warn("[photo] legacy move will retry:", error));
  for (const root of photoReadRoots(pid)) {
    const info = await readPhotoSidecar((0, import_path.join)(root, charId, file));
    if (info) return info;
  }
  return void 0;
}
async function dropPhotoTwins(path) {
  const twin = path.endsWith(".webp") ? path.replace(/\.webp$/, ".png") : path.replace(/\.png$/, ".webp");
  if (twin !== path) await (0, import_promises.rm)(twin, { force: true });
}
var rendering = /* @__PURE__ */ new Map();
function beginPhotoFile(pid, charId, file) {
  const key = `${pid}/${charId}/${pngPhotoOf(file)}`;
  rendering.set(key, (rendering.get(key) ?? 0) + 1);
  return () => {
    const count = (rendering.get(key) ?? 1) - 1;
    if (count) rendering.set(key, count);
    else rendering.delete(key);
  };
}
function photoFileRendering(pid, charId, file) {
  return rendering.has(`${pid}/${charId}/${pngPhotoOf(file.replace(/\.json$/, ".png"))}`);
}

// src/main/localPhotoBackup.ts
function localPhotosBackupPath(backup) {
  return backup.replace(/(\.zip)?$/i, ".photos.zip");
}
function entryOf(rel) {
  const [pid, charId, file, ...rest] = rel.replaceAll("\\", "/").split("/");
  if (rest.length || !import_shared4.SAFE_NUMERIC_ID.test(pid ?? "") || !import_shared4.SAFE_CHAR_ID.test(charId ?? "") || !(isPhotoImage(file ?? "") || isPhotoSidecar(file ?? ""))) return null;
  return { pid, charId, file };
}
async function filesUnder(root, prefix = "") {
  const files = [];
  for (const entry of await (0, import_promises2.readdir)((0, import_path2.join)(root, prefix), { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    if (entry.isDirectory()) files.push(...await filesUnder(root, rel));
    else if (entry.isFile()) files.push(rel);
    else throw (0, import_shared4.appError)("PHOTO_BACKUP_INVALID", "The photo backup contains a link or special file.");
  }
  return files;
}
async function legacyFiles(legacy, stage) {
  const archive = localPhotosBackupPath(legacy.archive);
  try {
    await (0, import_promises2.access)(archive);
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
  const extracted = (0, import_path2.join)(stage, ".legacy");
  await (0, import_promises2.mkdir)(extracted);
  await (0, import_main2.extractZip)(archive, extracted, import_shared4.BACKUP_ZIP_LIMITS);
  const files = await filesUnder(extracted);
  for (const rel of files) {
    const entry = entryOf(rel);
    if (!entry) continue;
    if (isPhotoSidecar(entry.file) && !await readPhotoSidecar((0, import_path2.join)(extracted, rel))) continue;
    await copyPhotoFile((0, import_path2.join)(extracted, rel), (0, import_path2.join)(stage, rel));
  }
  await (0, import_promises2.rm)(extracted, { recursive: true, force: true });
  return filesUnder(stage);
}
var photoBackupPart = {
  export: async ({ scratch, playthroughIds }) => {
    const files = [];
    for (const pid of playthroughIds) {
      await movePhotoFiles(pid);
      const copied = /* @__PURE__ */ new Set();
      for (const root of [getPhotosRoot(pid), legacyPhotosRoot(pid)]) {
        for (const charId of await photoCharacters(root)) {
          for (const file of await photoNames((0, import_path2.join)(root, charId))) {
            const rel = `${pid}/${charId}/${file}`;
            if (photoFileRendering(pid, charId, file)) continue;
            const source = (0, import_path2.join)(root, charId, file);
            if (copied.has(rel)) continue;
            if (isPhotoSidecar(file) && !await readPhotoSidecar(source)) continue;
            await copyPhotoFile(source, (0, import_path2.join)(scratch, pid, charId, file));
            copied.add(rel);
            files.push(rel);
          }
        }
      }
    }
    return { json: { schemaVersion: 1 }, files };
  },
  prepare: async (json, files, legacy) => {
    const stage = await (0, import_promises2.mkdtemp)((0, import_path2.join)((0, import_os.tmpdir)(), "vx-photo-restore-"));
    try {
      let names;
      if (json === void 0 && files.list.length === 0) {
        names = await legacyFiles(legacy, stage);
      } else {
        if (!json || typeof json !== "object" || !("schemaVersion" in json) || json.schemaVersion !== 1) {
          throw (0, import_shared4.appError)("PHOTO_BACKUP_INVALID", "The photo backup format is not supported.");
        }
        names = [];
        for (const rel of files.list) {
          const entry = entryOf(rel);
          if (!entry) throw (0, import_shared4.appError)("PHOTO_BACKUP_INVALID", "The photo backup has an invalid filename.");
          const source = (0, import_path2.join)(files.dir, rel);
          if (isPhotoSidecar(entry.file) && !await readPhotoSidecar(source)) continue;
          await copyPhotoFile(source, (0, import_path2.join)(stage, entry.pid, entry.charId, entry.file));
          names.push(rel);
        }
      }
      return {
        commit: async () => {
          try {
            for (const rel of names) {
              const entry = entryOf(rel);
              let dest;
              try {
                dest = getPhotoPath(entry.pid, entry.charId, entry.file);
              } catch (error) {
                if (error.code === "MOD_DATA_NO_PLAYTHROUGH") continue;
                throw error;
              }
              await copyPhotoFile((0, import_path2.join)(stage, rel), dest);
            }
          } finally {
            await (0, import_promises2.rm)(stage, { recursive: true, force: true });
            forgetPhotoMoves();
          }
        },
        discard: () => (0, import_promises2.rm)(stage, { recursive: true, force: true })
      };
    } catch (error) {
      await (0, import_promises2.rm)(stage, { recursive: true, force: true });
      throw error;
    }
  }
};
var registered = false;
function registerPhotoBackup() {
  if (registered) return;
  (0, import_main2.requiredBackupPart)(PHOTO_FEATURE_ID, photoBackupPart);
  registered = true;
}

// src/main/photoIpc.ts
var import_shared8 = require("@vx/modkit/shared");

// src/shared/characterBody.ts
function bodyOf(character) {
  const stored = character.ex?.[PHOTO_FEATURE_ID]?.data;
  return stored === void 0 ? character.body : stored;
}
var BODY_FIELDS = ["build", "breasts", "hipsThighs", "buttocks", "pubicHair"];
var BUILD_TAGS = ["petite", "curvy", "toned", "muscular_female", "tall_female"];
var BUILD_WEIGHTS = {
  petite: 1.4,
  curvy: 1.1
};
function weightedBuild(build, scope) {
  const weight = build && (scope === "sprite" || scope === "nude") ? BUILD_WEIGHTS[build] : void 0;
  return weight ? `(${build}:${weight})` : build;
}
var BREAST_TAGS = ["flat_chest", "small_breasts", "medium_breasts", "large_breasts"];
var HIPS_TAGS = ["wide_hips", "thick_thighs", "narrow_waist", "long_legs", "thigh_gap"];
var SMALL_ASS = "(flat_ass:0.6)";
var FULL_ASS = "(huge_ass:0.6)";
var BUTTOCKS_TAGS = ["flat_ass", "(flat_ass:0.6)", "(huge_ass:0.6)", "huge_ass"];
var PUBIC_TAGS = ["female_pubic_hair", "sparse_pubic_hair", "excessive_pubic_hair"];
var BODY_POOLS = {
  build: BUILD_TAGS,
  breasts: BREAST_TAGS,
  hipsThighs: HIPS_TAGS,
  buttocks: BUTTOCKS_TAGS,
  pubicHair: PUBIC_TAGS
};
var CONFLICTS = [
  {
    field: "build",
    tag: "petite",
    rules: {
      hipsThighs: ["wide_hips", "thick_thighs", "long_legs"],
      buttocks: [FULL_ASS, "huge_ass"]
    }
  },
  {
    field: "build",
    tag: "curvy",
    // `curvy` is a full chest as much as full hips: anything under medium contradicts it.
    rules: { breasts: ["flat_chest", "small_breasts"], buttocks: ["flat_ass", SMALL_ASS] }
  },
  { field: "hipsThighs", tag: "wide_hips", rules: { buttocks: ["flat_ass", SMALL_ASS] } },
  { field: "hipsThighs", tag: "thick_thighs", rules: { buttocks: ["flat_ass", SMALL_ASS] } }
];
function allowedBeside(body, field, tag) {
  if (!BODY_POOLS[field].includes(tag)) return false;
  return !CONFLICTS.some(
    (conflict) => conflict.field !== field && body[conflict.field] === conflict.tag && (conflict.rules[field] ?? []).includes(tag)
  );
}
function pooled(field, written) {
  const tags = Array.isArray(written) ? written : typeof written === "string" ? written.split(",") : [];
  return tags.map((tag) => typeof tag === "string" ? tag.trim() : "").find((tag) => BODY_POOLS[field].includes(tag));
}
var LEGACY_FIELD = {
  build: "bodyType",
  breasts: "bust",
  hipsThighs: "hipsThighs",
  buttocks: "buttocks",
  pubicHair: "pubicHair"
};
function cleanBody(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const record = raw;
  const body = {};
  for (const field of BODY_FIELDS) {
    const tag = pooled(field, record[field] ?? record[LEGACY_FIELD[field]]);
    if (tag && allowedBeside(body, field, tag)) body[field] = tag;
  }
  return BODY_FIELDS.some((field) => body[field]) ? body : void 0;
}
var APPEARANCE_BREASTS = {
  small_breasts: "small_breasts",
  // `big_breasts` is only an alias of `large_breasts` on Danbooru, with no posts of its own.
  big_breasts: "large_breasts",
  medium_breasts: "medium_breasts",
  large_breasts: "large_breasts",
  flat_chest: "flat_chest"
};
var ANY_BREAST_TAG = /^(flat_chest|[a-z]+_breasts)$/;
function appearanceBreasts(baseAppearance) {
  for (const tag of baseAppearance) {
    const mapped = APPEARANCE_BREASTS[tag];
    if (mapped) return mapped;
  }
  return "medium_breasts";
}
var DRAW_WEIGHTS = {
  hipsThighs: {
    "": 3,
    wide_hips: 1,
    thick_thighs: 1,
    narrow_waist: 1,
    long_legs: 1,
    thigh_gap: 1
  },
  // The in-between sizes more often than the ends.
  buttocks: { "": 4, [SMALL_ASS]: 2, [FULL_ASS]: 2, flat_ass: 1, huge_ass: 1 },
  pubicHair: { "": 3, female_pubic_hair: 3, sparse_pubic_hair: 1, excessive_pubic_hair: 1 }
};
var WEIGHTED_LABELS = {
  [SMALL_ASS]: "small ass",
  [FULL_ASS]: "full ass"
};
function gateBody(character, on) {
  const { body: _legacy, ...rest } = character;
  const ex = { ...character.ex };
  if (on) {
    ex[PHOTO_FEATURE_ID] = {
      v: character.ex?.[PHOTO_FEATURE_ID]?.v ?? "0.0.0",
      data: cleanBody(bodyOf(character)) ?? {}
    };
  } else delete ex[PHOTO_FEATURE_ID];
  return { ...rest, ex };
}
function bodyAppearance(character, scope) {
  const body = bodyOf(character);
  if (!body) return [...character.baseAppearance];
  const kept = character.baseAppearance.filter((tag) => !ANY_BREAST_TAG.test(tag) && !BODY_ONLY_TAGS.has(tag));
  const breasts = body.breasts ?? appearanceBreasts(character.baseAppearance);
  const tags = [breasts, weightedBuild(body.build, scope)];
  if (scope !== "photo") tags.push(body.hipsThighs);
  if (scope === "cg") tags.push(body.buttocks);
  if (scope === "nude" || scope === "cg") tags.push(body.pubicHair);
  return [...kept, ...tags.filter((tag) => Boolean(tag))];
}
var PETITE_NEGATIVE_TAGS = ["loli", "child", "aged_down"];
function bodyNegative(character) {
  return bodyOf(character)?.build === "petite" ? [...PETITE_NEGATIVE_TAGS] : [];
}
var BODY_ONLY_TAGS = /* @__PURE__ */ new Set([
  ...BUILD_TAGS,
  ...BUILD_TAGS.map((tag) => weightedBuild(tag, "sprite")),
  ...HIPS_TAGS,
  ...BUTTOCKS_TAGS,
  ...PUBIC_TAGS
]);
function withBodyTags(kept, draft, on) {
  if (kept === draft || kept.kind === "expression" || draft.kind === "expression") return kept;
  const owned = (tag) => BODY_ONLY_TAGS.has(tag) || on && ANY_BREAST_TAG.test(tag);
  const appearance = [
    ...kept.appearance.filter((tag) => !owned(tag)),
    ...draft.appearance.filter(owned)
  ];
  const petite = new Set(PETITE_NEGATIVE_TAGS);
  const negative = [
    ...kept.negative.filter((tag) => !petite.has(tag)),
    ...draft.negative.filter((tag) => petite.has(tag))
  ];
  return { ...kept, appearance, negative };
}

// src/shared/photoDraft.ts
function registerPhotoDraft(register) {
  register(PHOTO_FEATURE_ID, {
    draft: (parts, { character, kind }) => {
      const her = gateBody({ ...character, baseAppearance: parts.appearance }, photoSwitches().body);
      return { appearance: bodyAppearance(her, kind), negative: [...parts.negative, ...bodyNegative(her)] };
    },
    regen: (kept, draft, on) => withBodyTags(kept, draft, on && photoSwitches().body)
  });
}

// src/main/photoIpc.ts
var import_electron = require("electron");
var import_shared9 = require("@vx/modkit/shared");

// src/main/services/localPhotoService.ts
var import_fs2 = require("fs");
var import_promises3 = require("fs/promises");
var import_path3 = require("path");
var import_shared7 = require("@vx/modkit/shared");

// src/shared/photoTypes.ts
var PHOTO_PROMPT_LIMIT = 8e3;

// src/shared/photoPrompt.ts
var import_shared6 = require("@vx/modkit/shared");

// src/shared/photoBody.ts
var REGIONS = ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"];
var ALWAYS_SEEN = ["stomach"];
var SEEN_BY_DEFAULT = ["bust", "nipples", "pubic", "hipsThighs"];
var FRAMING = [
  {
    // Shoulders up: nothing below her chest is in the picture at all.
    cues: ["waist up", "upper body", "bust shot", "headshot", "portrait", "close-up", "close up"],
    seen: ["bust", "nipples"]
  },
  {
    // Turned away and offered: her back, and what being bent over shows past it.
    cues: [
      "all fours",
      "hands and knees",
      "bent over",
      "bending over",
      "ass up",
      "presenting",
      "spreading her ass",
      "spreading her cheeks",
      "grabbing her ass"
    ],
    seen: ["buttocks", "hipsThighs", "pubic"]
  },
  {
    // Turned away and upright: her back only.
    cues: ["from behind", "back view", "rear view", "back turned", "over her shoulder"],
    seen: ["buttocks", "hipsThighs"]
  },
  {
    // On her back with her legs up: everything, from underneath.
    cues: [
      "legs up",
      "legs in the air",
      "legs raised",
      "knees to her chest",
      "ankles up",
      "spread eagle",
      "spread-eagle"
    ],
    seen: ["bust", "nipples", "pubic", "hipsThighs", "buttocks"]
  },
  {
    cues: ["on her back", "onto her back", "lying on her back", "lying back", "lying down"],
    seen: ["bust", "nipples", "pubic", "hipsThighs"]
  },
  {
    // Waist down: her face is not even in it.
    cues: ["waist down", "lower body", "bottomless", "no bottoms"],
    seen: ["pubic", "hipsThighs", "buttocks"]
  }
];
var SPREAD_CUES = [
  "spread legs",
  "legs apart",
  "legs open",
  "thighs spread",
  "legs spread",
  "spreading her pussy",
  "spread pussy"
];
var REAR_CUES = ["spreading her ass", "spreading her cheeks", "holding her cheeks apart"];
var FRAMED_SEEN = {
  face: [],
  waist: ["bust", "nipples"]
};
function seenIn(caption, framing) {
  const text = caption.toLowerCase();
  const close = framing ? FRAMED_SEEN[framing] : void 0;
  const row = FRAMING.find((rule) => saysAny(text, rule.cues));
  const seen = new Set(close ?? row?.seen ?? SEEN_BY_DEFAULT);
  if (saysAny(text, SPREAD_CUES)) seen.add("pubic");
  if (saysAny(text, REAR_CUES)) seen.add("buttocks");
  if (framing !== "face") for (const field of ALWAYS_SEEN) seen.add(field);
  return seen;
}
var HIDES = {
  dress: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  sundress: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  gown: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  coat: ["bust", "nipples", "stomach"],
  jacket: ["bust", "nipples", "stomach"],
  hoodie: ["bust", "nipples", "stomach"],
  sweater: ["bust", "nipples", "stomach"],
  cardigan: ["bust", "nipples", "stomach"],
  shirt: ["bust", "nipples", "stomach"],
  blouse: ["bust", "nipples", "stomach"],
  "tank top": ["bust", "nipples", "stomach"],
  "crop top": ["bust", "nipples"],
  uniform: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  pyjamas: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  pajamas: ["bust", "nipples", "stomach", "hipsThighs", "buttocks", "pubic"],
  jeans: ["hipsThighs", "buttocks", "pubic"],
  trousers: ["hipsThighs", "buttocks", "pubic"],
  pants: ["hipsThighs", "buttocks", "pubic"],
  shorts: ["buttocks", "pubic"],
  skirt: ["buttocks", "pubic"],
  towel: ["bust", "nipples", "stomach", "pubic", "buttocks"],
  // Dressed, without saying in what: her top half is covered, and what is under her waist is
  // left to the garments the caption does name.
  clothes: ["bust", "nipples", "stomach"],
  outfit: ["bust", "nipples", "stomach"]
};
var DISPLACED = "(?:pulled (?:to the side|aside|down|up|off)|bunched|hiked up|hitched up|lifted|pushed (?:up|aside|down)|moved aside|tugged (?:aside|down)|around (?:her )?(?:one )?(?:ankles?|knees?|legs?))";
function displaced(text, word) {
  const noun = `${word}(?:s|es)?`;
  const gap = "(?:\\s+(?!and\\b|with\\b|to\\b|while\\b)[a-z'\u2019-]+){0,4}?\\s+";
  return new RegExp(
    `\\b${noun}\\b${gap}${DISPLACED}\\b|\\b(?:removed|removing|took off|taken off|holding(?: up)?|dangling|dangles|swinging|twirling|no)\\b${gap}${noun}\\b|\\b${noun}\\b${gap}(?:removed|off|dangles|dangling|hanging)\\b`
  ).test(text);
}
var SHAPES = {
  bra: ["bust", "nipples"],
  bralette: ["bust", "nipples"],
  "bikini top": ["bust", "nipples"],
  bikini: ["bust", "nipples", "pubic", "buttocks"],
  swimsuit: ["bust", "nipples", "pubic", "buttocks"],
  "one-piece": ["bust", "nipples", "pubic", "buttocks"],
  lingerie: ["bust", "nipples", "pubic"],
  negligee: ["bust", "nipples"],
  corset: ["bust", "nipples", "stomach"],
  lace: ["bust", "nipples"],
  panties: ["pubic", "buttocks"],
  underwear: ["bust", "nipples", "pubic", "buttocks"],
  thong: ["pubic"],
  "g-string": ["pubic"],
  leggings: ["hipsThighs", "buttocks", "pubic"],
  stockings: []
};
var WHOLE_BARE_CUES = [
  "naked",
  "nude",
  "no clothes",
  "undressed",
  "without clothes",
  "fully exposed",
  "wearing nothing",
  "nothing on"
];
var TOP_BARE_CUES = [
  "topless",
  "bare-chested",
  "bare chested",
  "bare chest",
  "bare torso",
  "bare front",
  "chest bare",
  "breasts bare",
  "exposed breasts",
  "exposed chest",
  "uncovered breasts",
  "shirtless",
  "braless",
  "no bra",
  "without a bra",
  "nothing covering"
];
var BOTTOM_BARE_CUES = ["bottomless", "no bottoms", "no panties", "without panties", "pantiless"];
var NOTHING_BELOW = /\bnothing\s+(?:on\s+)?(?:below|underneath|under\s+it|down\s+there|on\s+the\s+bottom|from\s+the\s+waist\s+down)\b/;
var TOP_HALF = ["bust", "nipples"];
var BOTTOM_HALF = ["hipsThighs", "buttocks", "pubic"];
function withoutNothingBelow(text) {
  return text.replace(new RegExp(NOTHING_BELOW.source, "g"), "");
}
function coverageIn(caption, bare) {
  const text = caption.toLowerCase();
  const coverage = Object.fromEntries(REGIONS.map((field) => [field, "exposed"]));
  if (bare && saysAny(withoutNothingBelow(text), WHOLE_BARE_CUES)) return coverage;
  for (const [word, fields] of Object.entries(SHAPES)) {
    if (!says(text, word) || displaced(text, word)) continue;
    for (const field of fields) coverage[field] = "shape";
  }
  for (const [word, fields] of Object.entries(HIDES)) {
    if (!says(text, word) || displaced(text, word)) continue;
    for (const field of fields) coverage[field] = "hidden";
  }
  if (bare && saysAny(text, TOP_BARE_CUES)) {
    for (const field of TOP_HALF) coverage[field] = "exposed";
  }
  if (bare && (saysAny(text, BOTTOM_BARE_CUES) || NOTHING_BELOW.test(text))) {
    for (const field of BOTTOM_HALF) coverage[field] = "exposed";
  }
  return coverage;
}
function partialExposureIn(caption, reveals, outfit = []) {
  if (describesNothingOn(caption)) return void 0;
  const text = caption.toLowerCase();
  const upper = reveals.some((tag) => ["breasts_out", "shirt_lift", "bra_lift", "bra_pull"].includes(tag)) || reveals.includes("clothes_pull") && saysAny(text, ["neckline", "shirt", "top", "sweater", "blouse", "hoodie", "dress"]) || saysAny(text, TOP_BARE_CUES);
  const lower = reveals.some(
    (tag) => [
      "skirt_lift",
      "panties_aside",
      "panty_pull",
      "pants_pull",
      "no_panties",
      "panties_around_one_leg",
      "pussy",
      "bottomless"
    ].includes(tag)
  ) || saysAny(text, BOTTOM_BARE_CUES) || NOTHING_BELOW.test(text);
  if (!upper && !lower) return void 0;
  const worn = `${text} ${outfit.join(" ").replace(/_/g, " ")}`;
  const lowerCover = [...Object.entries(HIDES), ...Object.entries(SHAPES)].some(
    ([word, regions]) => regions.includes("pubic") && says(worn, word) && !displaced(text, word)
  );
  const removedBelow = reveals.some(
    (tag) => ["no_panties", "panty_pull", "pants_pull", "panties_around_one_leg"].includes(tag)
  );
  const bottomless = lower && (saysAny(text, ["bottomless", "no bottoms"]) || NOTHING_BELOW.test(text) || removedBelow && !lowerCover);
  return { upper, lower, bottomless };
}
var THROUGH_CLOTH = {
  bust: "cleavage",
  hipsThighs: "wide_hips"
};
function ownTag(body, region, bare) {
  if (region === "hipsThighs") return body.hipsThighs;
  if (region === "buttocks") return body.buttocks;
  if (region === "pubic") return bare ? body.pubicHair : void 0;
  return void 0;
}
function bodyTagsFor(body, caption, bare, framing = null, partial) {
  const seen = seenIn(caption, framing);
  const coverage = coverageIn(caption, bare);
  if (bare && partial) {
    for (const region of TOP_HALF) coverage[region] = partial.upper ? "exposed" : "hidden";
    coverage.pubic = partial.lower ? "exposed" : "hidden";
    if (!partial.upper) coverage.stomach = "hidden";
  }
  const tags = [];
  for (const region of REGIONS) {
    if (!seen.has(region)) continue;
    const state = coverage[region];
    if (state === "hidden") continue;
    const nude = BARE_TAGS[region];
    if (state === "exposed" && bare && nude) tags.push(nude);
    const own = body ? ownTag(body, region, bare && state === "exposed") : void 0;
    if (own) {
      tags.push(own);
      continue;
    }
    if (state === "shape") {
      const through = region === "hipsThighs" && body ? void 0 : THROUGH_CLOTH[region];
      if (through) tags.push(through);
    }
  }
  return tags;
}
var BARE_TAGS = {
  nipples: "nipples",
  stomach: "navel",
  pubic: "pussy"
};
function describesNothingOn(caption) {
  return saysAny(withoutNothingBelow(caption.toLowerCase()), [
    "naked",
    "nude",
    "no clothes",
    "undressed",
    "without clothes",
    "wearing nothing",
    "nothing on"
  ]);
}

// src/shared/photoFraming.ts
var CLOSE_UP = ["close-up", "closeup", "close up"];
var MEDIUM_CLOSE_UP = ["medium close-up", "medium close up"];
var FRAMINGS = [
  {
    framing: "face",
    cues: ["face shot", "face only", "just her face", "headshot", "her face filling", ...CLOSE_UP],
    tags: ["close-up", "portrait"]
  },
  {
    framing: "waist",
    cues: [
      "waist up",
      "from the waist",
      "upper body",
      "chest up",
      "bust shot",
      "shoulders up",
      "medium shot",
      "half body",
      "half-body",
      ...MEDIUM_CLOSE_UP
    ],
    tags: ["(upper_body:1.3)"]
  },
  {
    framing: "knees",
    cues: [
      "knees up",
      "from the knees",
      "thighs up",
      "thigh up",
      "mid-thigh",
      "mid thigh",
      "three-quarter",
      "three quarter",
      "cowboy shot",
      "from the thighs"
    ],
    tags: ["cowboy_shot"]
  },
  {
    framing: "full",
    cues: [
      "full body",
      "full-body",
      "head to toe",
      "whole body",
      "full length",
      "full-length",
      "whole outfit",
      "full shot"
    ],
    tags: ["full_body"]
  }
];
function framingOf(caption) {
  const text = caption.toLowerCase();
  if (saysAny(text, MEDIUM_CLOSE_UP) || saysAny(text, CLOSE_UP) && saysAny(text, ["selfie"])) {
    return "waist";
  }
  return FRAMINGS.find((row) => saysAny(text, row.cues))?.framing ?? null;
}
function framingTags(framing) {
  return FRAMINGS.find((row) => row.framing === framing)?.tags ?? [];
}
var FULL_BODY_CUES = FRAMINGS.find((row) => row.framing === "full")?.cues ?? [];
var FRAMING_TAGS = /* @__PURE__ */ new Set([
  "close-up",
  "portrait",
  "upper_body",
  "cowboy_shot",
  "full_body",
  ...FRAMINGS.flatMap((row) => row.tags)
]);
function framingInTags(tags) {
  if (tags.includes("portrait")) return "face";
  if (tags.includes("full_body")) return "full";
  if (tags.some((tag) => tag === "upper_body" || tag.startsWith("(upper_body:"))) return "waist";
  if (tags.includes("cowboy_shot")) return "knees";
  return null;
}

// src/shared/photoPose.ts
function fires(text, cues) {
  return cues instanceof RegExp ? cues.test(text) : saysAny(text, cues);
}
function firstMatch(text, table) {
  return table.find((rule) => fires(text, rule.cues)) ?? null;
}
var DRESSED_POSITIONS = [
  { cues: ["close-up", "close up"], tags: ["close-up", "upper_body", "hand_up"] },
  { cues: ["face shot", "face only", "just her face"], tags: ["close-up", "portrait"] },
  { cues: ["on her stomach", "face down", "prone"], tags: ["lying", "on_stomach"] },
  { cues: ["on her side", "side lying"], tags: ["lying", "on_side"] },
  { cues: ["on her back", "lying back"], tags: ["lying", "on_back"] },
  {
    cues: ["lying", "laying", "on the bed", "on bed", "on the floor", "on the grass"],
    tags: ["lying", "arms_at_sides"]
  },
  {
    cues: ["sitting", "seated", "cross-legged", "on the chair", "on the couch", "on a bench"],
    tags: ["sitting", "cowboy_shot", "hands_on_lap"]
  },
  { cues: ["kneeling", "crouching"], tags: ["kneeling", "hands_on_own_thighs"] },
  { cues: ["leaning over", "leaning forward"], tags: ["leaning_forward", "hand_on_own_chin"] },
  { cues: ["leaning against", "leaning on"], tags: ["against_wall", "crossed_arms"] },
  { cues: ["standing", "walking"], tags: ["standing", "cowboy_shot", "hand_on_own_hip"] },
  { cues: ["stretching", "reaching up"], tags: ["standing", "arms_up", "armpits"] }
];
var FACING = [
  {
    cues: ["looking back", "glancing back", "over her shoulder"],
    tags: ["looking_back", "from_behind", "hand_on_own_hip"]
  },
  {
    cues: ["from behind", "back view", "rear view", "back turned"],
    tags: ["from_behind", "hand_on_own_hip"]
  },
  // `from_side` alone was drawn facing three-quarters on; `profile` is what turns her.
  {
    cues: ["from the side", "side view", "in profile", "side profile", "profile shot"],
    tags: ["from_side", "profile"]
  }
];
var BARE_POSITIONS = [
  {
    cues: ["on all fours", "all fours", "hands and knees"],
    tags: ["all_fours", "solo"]
  },
  {
    cues: ["bent over", "bending over", "bent forward"],
    tags: ["bent_over", "solo", "hands_on_own_knees"]
  },
  { cues: ["from behind"], tags: ["from_behind", "solo", "ass_focus"] },
  {
    cues: ["legs up", "legs in the air", "legs raised", "knees to her chest", "ankles up"],
    tags: ["lying", "on_back", "solo", "legs_up", "knees_up"]
  },
  {
    cues: ["spread eagle", "spread-eagle", "splayed out"],
    tags: ["lying", "on_back", "solo", "spread_legs"]
  },
  {
    cues: ["on her back", "onto her back", "lying on her back", "lying back", "on back"],
    tags: ["lying", "on_back", "solo", "arms_up"]
  },
  {
    cues: ["on her stomach", "face down", "lying on her stomach", "prone"],
    tags: ["lying", "on_stomach", "solo", "head_rest"]
  },
  {
    cues: ["on her side", "lying on her side", "side lying"],
    tags: ["on_side", "solo", "head_rest"]
  },
  { cues: ["squatting", "squat"], tags: ["squatting", "solo", "spread_legs", "hand_on_own_thigh"] },
  { cues: ["on her knees", "kneeling"], tags: ["kneeling", "solo", "hands_on_own_thighs"] },
  {
    cues: ["against the wall", "against wall"],
    tags: ["against_wall", "solo", "arms_at_sides"]
  },
  {
    cues: ["sitting on the bed", "sitting on her bed"],
    tags: ["sitting", "on_bed", "solo", "hands_on_lap"]
  },
  {
    cues: ["sitting", "seated", "cross-legged"],
    tags: ["sitting", "solo", "spread_legs", "hands_on_own_thighs"]
  },
  { cues: ["standing"], tags: ["standing", "solo", "hand_on_own_hip", "cowboy_shot"] },
  // Lowest priority: whatever the dressed pass would have said, kept consistent with it.
  {
    cues: ["lying", "laying", "on the bed", "on bed", "on the floor"],
    tags: ["lying", "solo", "arms_at_sides"]
  }
];
var BARE_POSITION_DEFAULT = ["standing", "solo", "hand_on_own_hip"];
var PLACEMENT_TAGS = /* @__PURE__ */ new Set([
  "hand_on_own_hip",
  "hands_on_own_thighs",
  "hand_on_own_thigh",
  "hands_on_lap",
  "hands_on_own_knees",
  "hands_on_own_ass",
  "head_rest",
  "arms_at_sides",
  "arms_up",
  "hand_up",
  "hand_on_own_chin",
  "crossed_arms"
]);
var OCCUPIED_HAND_CUES = [
  "dangling",
  "dangles",
  "swinging",
  "twirling",
  "hanging from her finger",
  "holding up her panties",
  "holding up her bra",
  "toying",
  "fiddling",
  "touching",
  "adjusting",
  "pulling",
  "pulling down",
  "pulling up",
  "tugging",
  "lifting",
  "lowering",
  "unbuttoning",
  "unzipping",
  "slipping off",
  "sliding off",
  "peeling off",
  "holding up her top",
  "holding up her skirt",
  "holding up her shirt",
  "holding",
  "holds",
  "clutching",
  "carrying",
  "sipping",
  "drinking",
  "eating",
  "taking a bite",
  "reading",
  "waving",
  "hugging",
  "cradling",
  "playing with her hair",
  "resting on her hand",
  "cheek on her hand",
  "chin on her hand",
  "chin in her hand",
  "propped",
  "biting",
  "bites",
  "in hand",
  "in her hand",
  "in one hand",
  "glass of",
  "cup of",
  "mug of",
  "tucking her hair",
  "fixing her hair",
  // Her hands on what she is leaning on: a hand on her hip or her thighs beside them is a third.
  "on her hands",
  "hands behind her",
  "on her elbows",
  "all fours",
  "hands and knees"
];
var BUSY_HAND_CUES = [
  ...OCCUPIED_HAND_CUES,
  "playing",
  "strumming",
  "practising",
  "practicing",
  "typing",
  "writing",
  "drawing",
  "sketching",
  "painting",
  "texting",
  "scrolling",
  "cooking",
  "stirring",
  "brushing",
  "applying",
  "tying",
  "fixing",
  "knitting",
  "sewing",
  "holding up",
  "showing off",
  "pointing",
  "guitar",
  "ukulele",
  "violin",
  "cello",
  "bass",
  "keyboard",
  "piano",
  "flute",
  "microphone",
  "mic",
  "singing",
  // The activity rows below also own her hands when the caption uses these words.
  "studying",
  "doing homework",
  "on her laptop",
  "gaming",
  "controller",
  "handheld console",
  "handheld game console",
  "cuddling"
];
var HAND_ACTIONS = [
  {
    cues: [
      "touching herself",
      "playing with herself",
      "fingering",
      "fingers herself",
      "finger herself",
      "rubbing herself",
      "hand between her legs",
      "fingers inside",
      "masturbat*",
      "pleasuring herself",
      "rubbing her clit",
      "playing with her clit",
      "two fingers",
      "slips a finger",
      "slides a finger",
      "working her fingers"
    ],
    tags: ["masturbation", "fingering", "between_legs"],
    implies: ["lying", "on_back", "solo", "spread_legs"]
  },
  {
    cues: [
      "squeezing her breasts",
      "cupping her breasts",
      "cupping herself",
      "groping",
      "fondling",
      "grabbing her breasts",
      "playing with her nipples",
      "pinching her nipple",
      "tweaking her nipple",
      "hand on her breast",
      "hands on her breasts"
    ],
    tags: ["grabbing_own_breast"]
  },
  {
    cues: [
      "spreading her pussy",
      "spreading herself open",
      "holding herself open",
      "spreading her lips",
      "pulling herself open"
    ],
    tags: ["spread_pussy", "pussy", "spread_legs"],
    implies: ["lying", "on_back", "solo", "spread_legs"]
  },
  {
    cues: [
      "spreading her ass",
      "spreading her cheeks",
      "holding her cheeks apart",
      "grabbing her ass"
    ],
    tags: ["grabbing_own_ass", "ass_focus"],
    implies: ["bent_over", "solo"]
  },
  {
    cues: ["dildo", "toy inside her", "fucking herself with"],
    tags: ["sex_toy", "dildo", "vaginal_object_insertion"],
    implies: ["lying", "on_back", "solo", "spread_legs"]
  },
  {
    cues: ["vibrator", "magic wand", "vibe on her"],
    tags: ["vibrator", "sex_toy", "clitoris"],
    implies: ["sitting", "solo", "spread_legs"]
  }
];
var PLAYING_INSTRUMENT = ["playing", "strumming", "practising", "practicing"];
var PEACE_CUES = ["peace sign", "v sign", "v-sign", "flashing a v"];
function heldClothing(garment) {
  const gap = "(?:\\s+(?!over\\b|under\\b|with\\b|and\\b|while\\b)[a-z'\u2019-]+){0,4}?\\s+";
  const hold = "(?:holding(?: up)?|dangling|dangles|swinging|twirling|hanging)";
  return new RegExp(`\\b${hold}\\b${gap}${garment}\\b|\\b${garment}\\b${gap}${hold}\\b`);
}
var FREE_HAND_GESTURES = [
  { cues: ["waving"], tags: ["waving"] },
  { cues: ["pointing"], tags: ["pointing"] },
  { cues: heldClothing("panties"), tags: ["holding_panties"] },
  { cues: heldClothing("bra"), tags: ["holding_bra"] },
  {
    cues: /\b(?:toying with|touching|adjusting|fiddling with)(?:\s+[a-z'’-]+){0,3}\s+(?:chokers?|necklaces?)\b/,
    tags: ["hand_on_own_neck"]
  },
  {
    cues: /\b(?:playing with|twirling|tucking)(?:\s+[a-z'’-]+){0,3}\s+hair\b|\brunning (?:a |her )?hand through (?:her )?hair\b/,
    tags: ["hand_in_own_hair"]
  },
  {
    cues: /\bhand on (?:her |own )?cheek\b|\bcheek (?:resting )?on (?:her )?hand\b/,
    tags: ["hand_on_own_cheek"]
  },
  { cues: ["hand on her face", "hand on own face"], tags: ["hand_on_own_face"] },
  {
    cues: ["finger to her lips", "finger to her mouth", "finger on her lips"],
    tags: ["finger_to_mouth"]
  },
  { cues: ["biting her nail", "biting her nails", "biting her fingernail"], tags: ["nail_biting"] },
  { cues: ["biting her finger"], tags: ["biting_own_finger"] },
  {
    cues: ["hand on her chin", "chin on her hand", "chin in her hand"],
    tags: ["hand_on_own_chin"]
  },
  { cues: ["hand over her heart", "hand on her heart"], tags: ["hand_on_own_chest"] },
  {
    cues: /\b(?:tugging)(?:\s+[a-z'’-]+){0,3}\s+(?:hems?|sleeves?)\b|\badjusting (?:her |own )?clothes\b/,
    tags: ["adjusting_clothes"]
  },
  { cues: ["blowing a kiss", "blowing him a kiss"], tags: ["blowing_kiss"] },
  {
    cues: ["heart with her hands", "heart with both hands"],
    tags: ["heart_hands"],
    twoHanded: true
  },
  {
    cues: ["hands behind her back", "arms behind her back"],
    tags: ["arms_behind_back"],
    twoHanded: true
  },
  {
    cues: ["covering her chest", "covering her breasts"],
    tags: ["covering_breasts"],
    covering: true
  },
  {
    cues: ["covering her crotch", "covering her pussy", "covering herself"],
    tags: ["covering_crotch"],
    covering: true
  },
  { cues: PEACE_CUES, tags: ["v"] }
];
var FREE_HAND_TAGS = new Set(FREE_HAND_GESTURES.flatMap((row) => row.tags));
var TWO_HANDED_GESTURES = new Set(
  FREE_HAND_GESTURES.filter((row) => row.twoHanded).flatMap((row) => row.tags)
);
var ACTIVITIES = [
  { cues: ["playing with her hair"], tags: ["hand_in_own_hair"] },
  { cues: ["guitar"], needs: PLAYING_INSTRUMENT, tags: ["playing_guitar", "holding_instrument"] },
  {
    cues: ["ukulele"],
    needs: PLAYING_INSTRUMENT,
    tags: ["playing_instrument", "holding_instrument", "ukulele"]
  },
  {
    cues: ["bass"],
    needs: PLAYING_INSTRUMENT,
    tags: ["playing_bass_guitar", "holding_instrument"]
  },
  {
    cues: ["violin"],
    needs: PLAYING_INSTRUMENT,
    tags: ["playing_instrument", "holding_instrument", "violin"]
  },
  { cues: ["guitar"], tags: ["holding_instrument", "guitar"] },
  { cues: ["ukulele"], tags: ["holding_instrument", "ukulele"] },
  { cues: ["bass"], tags: ["holding_instrument", "bass_guitar"] },
  { cues: ["violin"], tags: ["holding_instrument", "violin"] },
  { cues: ["cello"], tags: ["holding_instrument", "cello"] },
  { cues: ["flute"], tags: ["holding_instrument", "flute"] },
  { cues: ["piano"], tags: ["playing_piano"], implies: ["sitting"] },
  { cues: ["keyboard"], tags: ["keyboard_(instrument)"], implies: ["sitting"] },
  {
    cues: ["microphone", "mic", "singing"],
    needs: ["singing"],
    tags: ["holding_microphone", "singing"]
  },
  { cues: ["microphone", "mic"], tags: ["holding_microphone"] },
  { cues: ["reading"], needs: ["book"], tags: ["reading", "holding_book"] },
  { cues: ["reading"], tags: ["reading"] },
  { cues: ["typing", "on her laptop"], tags: ["typing", "laptop"] },
  { cues: ["writing", "studying", "doing homework"], tags: ["writing", "holding_pen"] },
  { cues: ["drawing", "sketching"], tags: ["drawing_(action)", "holding_pencil"] },
  {
    cues: ["painting"],
    needs: ["picture", "canvas", "portrait", "landscape", "easel"],
    tags: ["painting_(action)", "holding_paintbrush"]
  },
  {
    cues: ["handheld console", "handheld game console"],
    tags: ["playing_games", "handheld_game_console"]
  },
  {
    cues: ["playing games", "playing a game", "playing video games", "gaming", "controller"],
    tags: ["playing_games", "holding_controller"]
  },
  { cues: ["eating"], tags: ["eating"] },
  { cues: ["drinking", "sipping"], tags: ["drinking"] },
  { cues: ["cooking", "stirring"], tags: ["cooking"] },
  { cues: ["knitting"], tags: ["knitting"] },
  { cues: ["brushing her hair", "brushing hair"], tags: ["brushing_hair"] },
  { cues: ["applying makeup", "applying lipstick"], tags: ["applying_makeup"] },
  {
    cues: ["hugging", "cuddling"],
    needs: ["plush", "plushie", "pillow"],
    tags: ["hugging_object"]
  }
];
function activityOf(text, mirror, coveringAllowed) {
  const gesture = FREE_HAND_GESTURES.find((row) => (!row.covering || coveringAllowed) && fires(text, row.cues)) ?? null;
  if (mirror) return gesture;
  const activity = ACTIVITIES.find(
    (row) => fires(text, row.cues) && (!row.needs || fires(text, row.needs))
  );
  return activity && !activity.tags.some((tag) => FREE_HAND_TAGS.has(tag)) ? activity : gesture;
}
function hasPosition(text) {
  return [...DRESSED_POSITIONS, ...BARE_POSITIONS].some(
    (row) => fires(text, row.cues) && row.tags.some((tag) => !FRAMING_TAGS.has(tag) && !PLACEMENT_TAGS.has(tag) && tag !== "solo")
  );
}
var BREAST_ACTION = HAND_ACTIONS[1];
var NIPPLE_VERBS = [
  "play*",
  "teas*",
  "pinch*",
  "tweak*",
  "roll*",
  "squeez*",
  "tug*",
  "rub*",
  "flick*"
];
function handActionsOf(text) {
  const matched = HAND_ACTIONS.filter((action) => fires(text, action.cues)).slice(0, 2);
  const looseNipples = matched.length === 0 && says(text, "nipple") && saysAny(text, NIPPLE_VERBS);
  return looseNipples ? [BREAST_ACTION] : matched;
}
var VAGUE_TOUCH = {
  cues: ["touching", "hand on", "caressing"],
  tags: ["hand_on_own_chest"]
};
var MODIFIERS = [
  {
    cues: [
      "lifting her skirt",
      "skirt up",
      "panties aside",
      "pulling down her panties",
      "taking off her bra",
      "unbuttoning",
      "unzipping",
      "sliding off",
      "slipping off",
      "lifting her shirt",
      "lifting her top"
    ],
    tags: ["undressing", "clothes_pull"]
  },
  {
    cues: [
      "finger in her mouth",
      "sucking her finger",
      "biting her lip",
      "tongue out",
      "licking her lips",
      "blowing a kiss",
      "come-hither"
    ],
    tags: ["seductive_smile"]
  },
  {
    cues: ["orgasm", "climax", "cumming", "ahegao", "ecstasy", "eyes rolled", "trembling with"],
    tags: ["orgasm", "open_mouth", "rolling_eyes"]
  },
  { cues: ["squirt", "gushing", "female ejaculation"], tags: ["female_ejaculation"] },
  {
    cues: ["spread legs", "legs apart", "legs open", "thighs spread", "legs spread"],
    tags: ["spread_legs"]
  },
  { cues: ["arching", "arched back", "arches her back"], tags: ["arched_back"] },
  { cues: ["soaking wet", "dripping", "soaked"], tags: ["wet", "sweat"] },
  { cues: ["blushing", "red cheeks", "flushed", "cheeks pink", "cheeks red"], tags: ["blush"] },
  {
    cues: ["at the camera", "at the phone", "looking at viewer", "eye contact", "staring at"],
    tags: ["looking_at_viewer"]
  },
  { cues: ["mirror"], tags: ["mirror", "reflection"] },
  // Where the camera is: a caption that says how low or high it was asks for the angle.
  {
    cues: [
      "from below",
      "low angle",
      "worm's-eye",
      "worms-eye",
      "from under",
      "shot low",
      "shot from low",
      "looking up at her",
      "angled up",
      "camera low",
      "phone low"
    ],
    tags: ["from_below"]
  },
  {
    cues: [
      "from above",
      "high angle",
      "overhead shot",
      "overhead",
      "bird's-eye",
      "birds-eye",
      "shot from above",
      "looking down at her",
      "angled down",
      "camera high",
      "phone high",
      "held up high"
    ],
    tags: ["from_above"]
  }
];
var DRESSED_MODIFIERS = /* @__PURE__ */ new Set([
  "from_below",
  "from_above",
  "undressing",
  "seductive_smile",
  "arched_back",
  "blush",
  "looking_at_viewer",
  "mirror"
]);
function poseTagsOf(caption, bare) {
  const text = caption.toLowerCase();
  const tags = [];
  const dressed = firstMatch(text, DRESSED_POSITIONS);
  const facing = firstMatch(text, FACING);
  if (!bare) {
    if (dressed) tags.push(...dressed.tags);
    if (facing) tags.push(...facing.tags);
    for (const modifier of MODIFIERS) {
      if (DRESSED_MODIFIERS.has(modifier.tags[0]) && fires(text, modifier.cues)) {
        tags.push(...modifier.tags);
      }
    }
    return onePlacement([...new Set(tags)]);
  }
  const position = firstMatch(text, BARE_POSITIONS);
  const hands = handActionsOf(text);
  const implied = hands.find((action) => action.implies)?.implies;
  tags.push(...position?.tags ?? dressed?.tags ?? implied ?? BARE_POSITION_DEFAULT);
  if (facing) tags.push(...facing.tags);
  for (const modifier of MODIFIERS) {
    if (fires(text, modifier.cues)) tags.push(...modifier.tags);
  }
  if (hands.length > 0) {
    const kept = tags.filter((tag) => !PLACEMENT_TAGS.has(tag));
    return [.../* @__PURE__ */ new Set([...kept, ...hands.flatMap((action) => action.tags)])];
  }
  if (!tags.some((tag) => PLACEMENT_TAGS.has(tag)) && fires(text, VAGUE_TOUCH.cues)) {
    tags.push(...VAGUE_TOUCH.tags);
  }
  return onePlacement([...new Set(tags)]);
}
var PHONE_NEGATIVE = ["phone", "cellphone", "smartphone", "holding_phone"];
var CAMERA_CUES = ["holding a camera", "her camera", "a camera in", "film camera", "polaroid"];
var BOTH_HANDS_CUES = ["both hands", "two hands", "both of her hands", "two-handed"];
function handsFull(text) {
  return saysAny(text, BOTH_HANDS_CUES) && saysAny(text, BUSY_HAND_CUES) || FREE_HAND_GESTURES.some((row) => row.twoHanded && fires(text, row.cues));
}
function withoutSelfieWord(scene) {
  const text = scene.toLowerCase();
  if (says(text, "mirror") || !handsFull(text)) return scene;
  return scene.replace(/\bselfie\b/gi, (word) => word[0] === "S" ? "Photo" : "photo");
}
function selfieShot(text, tags, freeHand) {
  if (!says(text, "selfie")) return null;
  const has = (tag) => tags.includes(tag);
  if (says(text, "mirror")) {
    const turned = /* @__PURE__ */ new Set(["from_behind", "looking_back", "from_side", "profile"]);
    const [hand, ...otherHands] = handActionsOf(text);
    const otherHandTags = new Set(
      hand ? otherHands.flatMap((action) => action.tags).filter((tag) => !hand.tags.includes(tag)) : []
    );
    const kept2 = tags.filter(
      (tag) => !FRAMING_TAGS.has(tag) && !turned.has(tag) && !TWO_HANDED_GESTURES.has(tag) && !otherHandTags.has(tag) && !(has("spread_pussy") && (tag === "spread_legs" || tag.startsWith("(spread_legs:")))
    );
    const framing = framingOf(text);
    const frame = framing ? [...framingTags(framing)] : says(text, "close") || says(text, "close-up") ? [] : ["full_body"];
    const add = ["mirror", "reflection", "holding_phone", ...frame];
    return { tags: [.../* @__PURE__ */ new Set([...kept2, ...add])], negative: ["dual_wielding"] };
  }
  const bodyHand = handActionsOf(text).some((action) => tags.includes(action.tags[0]));
  const peace = !bodyHand && (freeHand.includes("v") || freeHand.length === 0 && saysAny(text, PEACE_CUES));
  const camera = saysAny(text, CAMERA_CUES) ? [] : ["camera"];
  if (handsFull(text)) {
    return {
      tags: [...tags],
      negative: [...lyingNegative(tags), ...PHONE_NEGATIVE, ...camera, "selfie", "outstretched_arm"]
    };
  }
  const kept = tags.filter(
    (tag) => !FRAMING_TAGS.has(tag) && (!PLACEMENT_TAGS.has(tag) || freeHand.includes(tag))
  );
  const busy = !peace && saysAny(text, BUSY_HAND_CUES);
  const negative = [...PHONE_NEGATIVE, ...camera, ...busy ? ["v"] : []];
  const low = has("from_below") ? ["looking_down"] : [];
  const shot = (add, extra = []) => ({
    tags: [.../* @__PURE__ */ new Set([...kept, ...add, ...low, ...peace ? ["v"] : []])],
    negative: [...negative, ...extra]
  });
  const whole = saysAny(text, FULL_BODY_CUES);
  if (has("on_stomach")) {
    const rest = kept.filter((tag) => tag !== "on_stomach" && tag !== "from_above");
    const legs = whole ? ["(legs_up:1.1)"] : ["upper_body"];
    return {
      tags: [.../* @__PURE__ */ new Set(["(on_stomach:1.2)", ...legs, ...rest, "outstretched_arm"])],
      negative: [...negative, "on_back"]
    };
  }
  if (has("on_side")) {
    return shot(["selfie", "from_above", ...whole ? [] : ["upper_body"]], [
      "on_back",
      "on_stomach",
      "open_hand",
      "spread_fingers",
      "reaching_towards_viewer"
    ]);
  }
  if (has("on_back") && !whole) {
    return shot(["selfie", "from_above", "outstretched_arm", "upper_body"], ["on_stomach"]);
  }
  if (whole || has("lying") || has("sitting")) {
    const angle = has("from_below") ? [] : ["from_above", "looking_up"];
    return shot(["full_body", ...angle, "(outstretched_arm:1.2)", "foreshortening"]);
  }
  return shot(["selfie", "upper_body", "outstretched_arm", "foreshortening"]);
}
var CLOSE_CUES = ["close-up", "close up", "upper body", "waist up", "face shot", "just her face"];
var LYING_CUES = [
  ["on_stomach", ["on her stomach", "face down", "prone"]],
  ["on_side", ["on her side", "side lying"]],
  ["on_back", ["on her back", "lying back"]]
];
function closeLying(text, tags) {
  if (!saysAny(text, CLOSE_CUES)) return null;
  const lying = LYING_CUES.find(([, cues]) => saysAny(text, cues))?.[0];
  if (!lying) return null;
  const kept = tags.filter(
    (tag) => !FRAMING_TAGS.has(tag) && tag !== "hand_up" && !LYING_CUES.some(([pose]) => pose === tag)
  );
  const frame = lying === "on_stomach" ? "upper_body" : "(upper_body:1.3)";
  return [.../* @__PURE__ */ new Set(["lying", lying, frame, ...kept])];
}
function withFraming(text, tags) {
  const framing = framingOf(text);
  if (!framing) return [...tags];
  const kept = tags.filter((tag) => !FRAMING_TAGS.has(tag));
  return [.../* @__PURE__ */ new Set([...kept, ...framingTags(framing)])];
}
function lyingNegative(tags) {
  if (tags.includes("on_stomach")) return ["on_back"];
  if (tags.includes("on_side")) return ["on_back", "on_stomach"];
  if (tags.includes("on_back")) return ["on_stomach"];
  return [];
}
var DEVICE = "(?:camera|phone|cellphone|smartphone)";
var HOLD_VERB = "(?:hold\\w*|held|rais\\w*|angl\\w*|aim\\w*|lift\\w*|tilt\\w*|grip\\w*|clutch\\w*|extend\\w*)";
var HOLD_WHERE = `(?:\\s+(?:up|out|down|low|high|overhead|close|away|above\\s+her(?:\\s+(?:head|face))?|in\\s+front\\s+of\\s+her(?:\\s+face)?|at\\s+arm['\u2019]?s\\s+length|(?:with\\s+)?(?:one|her)\\s+(?:free\\s+|other\\s+)?(?:hand|arm)|and\\s+${HOLD_VERB}))*`;
var NEAR = "(?:\\s+(?!at\\b|to\\b|into\\b|toward\\b|towards\\b)[\\w'\u2019-]+){0,3}?";
var CAMERA_HOLD = new RegExp(
  `(?:\\s*\\b(?:with|and)\\b)?\\s*(?:\\b(?:one|her)\\s+(?:hand|arm)\\s+)?(?:\\b${HOLD_VERB}\\b${NEAR}\\s+${DEVICE}\\b|(?:\\b(?:her|the|a|my)\\s+)?\\b${DEVICE}\\s+${HOLD_VERB}\\b)${HOLD_WHERE}`,
  "gi"
);
function withoutCameraHold(scene) {
  const text = scene.toLowerCase();
  if (!says(text, "selfie") || says(text, "mirror") || saysAny(text, CAMERA_CUES)) return scene;
  const pieces = scene.split(/(,|;|\s+while\s+|\s+as\s+)/);
  let out = "";
  for (let i = 0; i < pieces.length; i += 2) {
    const part = pieces[i].replace(CAMERA_HOLD, "").trim().replace(/^(?:and|with)\s+/i, "");
    if (part.length === 0 || /^[.!?]+$/.test(part)) {
      if (i === pieces.length - 1) out = out.replace(/[,;]?\s*$/, part);
      continue;
    }
    const joint = pieces[i - 1]?.trim() ?? "";
    out += out.length === 0 ? part : /^[,;]$/.test(joint) ? `${joint} ${part}` : ` ${joint} ${part}`;
  }
  return out.replace(/\s+([,;.])/g, "$1").replace(/\s{2,}/g, " ").trim();
}
function onePlacement(tags) {
  const first = tags.find((tag) => PLACEMENT_TAGS.has(tag));
  return tags.filter((tag) => !PLACEMENT_TAGS.has(tag) || tag === first);
}
var PHOTO_CLAUSE_END = "(?=\\s+(?:beside|next to|in front of|near|against|under|outside|inside|while|as|with her)\\b|[,.;]|$)";
function withoutHeldObject(scene) {
  if (!says(scene.toLowerCase(), "mirror")) return scene;
  const verb = "(?:holding|clutching|carrying|cradling|sipping|drinking)";
  const hand = "in\\s+(?:her\\s+|one\\s+|her\\s+free\\s+|her\\s+other\\s+)?hand";
  const held = new RegExp(
    `\\s*,?\\s*\\b(?:with|${verb})\\s+(?:a|an|her|the|some|one)?\\s*(?:(?!${PHOTO_CLAUSE_END})[^,.;])*?\\b${hand}\\b`,
    "gi"
  );
  const holding = new RegExp(`\\s*,?\\s*\\b${verb}\\s+[^,.;]*?${PHOTO_CLAUSE_END}`, "gi");
  return scene.replace(held, (part) => /\b(?:phone|camera)\b/i.test(part) ? part : "").replace(holding, (part) => /\b(?:phone|camera)\b/i.test(part) ? part : "").replace(/\s{2,}/g, " ").replace(/\s+([,.;])/g, "$1").trim();
}
var CANDID_CUES = [
  "candid",
  "not looking",
  "isn't looking",
  "is not looking",
  "looking away",
  "unaware",
  "doesn't notice",
  "does not notice",
  "not posing",
  "isn't posing"
];
var CROSS_LEGGED_CUES = ["cross-legged", "cross legged", "criss-cross", "legs folded under"];
var CROSSED_CUES = [
  "legs crossed",
  "crossed legs",
  "crosses her legs",
  "crossing her legs",
  "legs tightly crossed",
  "thighs pressed together",
  "knees together"
];
function photoPose(caption, tier) {
  const bare = tier === "explicit";
  const text = caption.toLowerCase();
  let tags = poseTagsOf(caption, bare);
  const mirror = says(text, "mirror") && says(text, "selfie");
  const bodyAction = bare && handActionsOf(text).length > 0;
  let activity = activityOf(text, mirror, tier !== "everyday");
  const gesture = activity?.tags.some((tag) => FREE_HAND_TAGS.has(tag)) ?? false;
  if (bodyAction && gesture) activity = null;
  if (activity) {
    if (activity.implies && !hasPosition(text) && !bodyAction) {
      tags = tags.filter((tag) => tag !== "standing");
      tags.push(...activity.implies);
    }
  }
  if (saysAny(text, CANDID_CUES)) {
    tags = [.../* @__PURE__ */ new Set([...tags.filter((tag) => tag !== "looking_at_viewer"), "looking_away"])];
  }
  if (saysAny(text, CROSS_LEGGED_CUES)) tags = [.../* @__PURE__ */ new Set([...tags, "indian_style"])];
  if (saysAny(text, CROSSED_CUES)) {
    tags = [.../* @__PURE__ */ new Set([...tags.filter((tag) => tag !== "spread_legs"), "crossed_legs"])];
  }
  if (tags.includes("looking_at_viewer")) tags = tags.filter((tag) => tag !== "profile");
  const lying = closeLying(text, tags);
  tags = lying ?? withFraming(text, tags);
  const busy = saysAny(text, mirror ? OCCUPIED_HAND_CUES : BUSY_HAND_CUES);
  if (activity || busy) {
    tags = tags.filter((tag) => !PLACEMENT_TAGS.has(tag));
  }
  if (activity) {
    if (gesture) tags = tags.filter((tag) => !VAGUE_TOUCH.tags.includes(tag));
    tags.push(...activity.tags);
  }
  tags = [...new Set(tags)];
  const noCamera = saysAny(text, CAMERA_CUES) ? [] : ["camera"];
  const freeHand = activity && gesture ? activity.tags : [];
  const pose = selfieShot(text, tags, freeHand) ?? {
    tags,
    negative: [...lyingNegative(tags), ...noCamera]
  };
  return { ...pose, tags: withFraming(text, pose.tags) };
}

// src/shared/photoWardrobe.ts
var import_shared5 = require("@vx/modkit/shared");
var SWIM_GARMENTS = ["swimsuit", "swimwear", "bikini", "one-piece", "bathing suit"];
var PE_GARMENTS = [
  "pe kit",
  "pe uniform",
  "pe clothes",
  "gym clothes",
  "gym kit",
  "sportswear",
  "tracksuit"
];
var MAIN_NAMES = [
  ...["everyday", "usual"].flatMap(
    (kind) => ["clothes", "cloth", "outfit"].map((garment) => `${kind} ${garment}`)
  ),
  ...["her", "their"].flatMap(
    (who) => ["clothes", "cloth", "outfit"].flatMap((garment) => [
      `${who} ${garment}`,
      `${who} own ${garment}`
    ])
  )
];
var SWIM_PLACES = ["pool", "poolside", "beach", "swimming", "swim"];
var PE_PLACES = [
  "pe",
  "gym",
  "workout",
  "working out",
  "running",
  "jogging",
  "training",
  "yoga",
  "stadium",
  "turf",
  "track",
  "practice"
];
function namedCustomSet(character, text) {
  for (const slot of (0, import_shared5.customOutfitSlotsIn)(Object.keys(character.customOutfits ?? {}))) {
    const name = character.customOutfits?.[slot]?.name?.trim().toLowerCase();
    if (name && saysAny(text, [name])) return slot;
  }
  return null;
}
function namedWardrobe(character, text) {
  const custom = namedCustomSet(character, text);
  const name = custom && character.customOutfits?.[custom]?.name?.trim();
  if (custom && name) {
    return {
      tags: (0, import_shared5.outfitTagsFor)(character, custom),
      names: [name]
    };
  }
  if (saysAny(text, SWIM_GARMENTS)) {
    return { tags: (0, import_shared5.outfitTagsFor)(character, "swim"), names: SWIM_GARMENTS };
  }
  if (saysAny(text, PE_GARMENTS)) {
    return { tags: (0, import_shared5.outfitTagsFor)(character, "pe"), names: PE_GARMENTS };
  }
  return saysAny(text, MAIN_NAMES) ? { tags: character.outfit, names: MAIN_NAMES } : null;
}
function photoWardrobeNames(character, caption) {
  const set = namedWardrobe(character, caption.toLowerCase());
  return set && set.tags?.length > 0 ? set.names : [];
}
function photoWardrobe(character, caption, captionDressesHer, swimwearAllowed) {
  const text = caption.toLowerCase();
  const named = namedWardrobe(character, text);
  if (named) return named.tags;
  if (captionDressesHer) return null;
  if (swimwearAllowed && saysAny(text, SWIM_PLACES)) return (0, import_shared5.outfitTagsFor)(character, "swim");
  if (saysAny(text, PE_PLACES)) return (0, import_shared5.outfitTagsFor)(character, "pe");
  return character.outfit;
}
var GARMENT_NOUNS = [
  "skirt",
  "shirt",
  "blouse",
  "sweater",
  "cardigan",
  "hoodie",
  "top",
  "dress",
  "coat",
  "jacket",
  "raincoat",
  "shorts",
  "pants",
  "trousers",
  "jeans",
  "bra",
  "panties",
  "bikini",
  "swimsuit",
  "uniform",
  "camisole",
  "leggings",
  "robe"
];
var GARMENT_FILLER = /* @__PURE__ */ new Set(["her", "their", "own", "the", "and", "with", "clothes", "clothing"]);
var GARMENT_BREAK = [
  "and",
  "with",
  "beside",
  "near",
  "on",
  "under",
  "over",
  "above",
  "below",
  "next",
  "wearing",
  "dressed",
  ...GARMENT_NOUNS
].join("|");
function garmentWords(text) {
  return text.toLowerCase().replace(/\(([^():]+):[\d.]+\)/g, "$1").replace(/[_()-]/g, " ").replace(/\bminiskirt(s?)\b/g, "mini skirt$1");
}
function photoWardrobeFromGarment(character, caption) {
  const text = garmentWords(caption);
  const sets = [
    character.outfit,
    character.peOutfit,
    character.swimOutfit,
    ...(0, import_shared5.customOutfitSlotsIn)(Object.keys(character.customOutfits ?? {})).map(
      (slot) => (0, import_shared5.outfitTagsFor)(character, slot)
    )
  ];
  for (const tags of sets) {
    if (!tags) continue;
    for (const tag of tags) {
      const words = garmentWords(tag);
      for (const noun of GARMENT_NOUNS) {
        if (!says(words, noun) || !says(text, noun)) continue;
        const modifiers = words.split(/[^a-z]+/).filter((word2) => word2.length >= 3 && !GARMENT_FILLER.has(word2) && !says(word2, noun));
        const word = `(?!(?:${GARMENT_BREAK})\\b)[a-z]+`;
        const phrase = new RegExp(
          `(?:\\b${word}\\s+){0,5}\\b${noun}(?:s|es)?\\b(?:\\s+${word}){0,3}`,
          "g"
        );
        if ([...text.matchAll(phrase)].some((match) => saysAny(match[0], modifiers))) return tags;
      }
    }
  }
  return null;
}

// src/shared/photoPrompt.ts
var PHOTO_QUALITY = "masterpiece, best_quality, very_aesthetic";
var PHOTO_BASE = "1girl, solo, depth_of_field";
var PHOTO_NEGATIVE = "worst_quality, bad_quality, lowres, simple_background, white_background, transparent_background, multiple_views, reference_sheet, english_text, speech_bubble, artist_name, watermark, signature, 1boy, multiple_boys, multiple_girls, 2girls, hetero, penis, sex, gold, photo_(medium), cum, bad_hands, extra_digits, fewer_digits";
var BARE_POSITIVE = "uncensored";
var DRESSED_NEGATIVE = [
  ["nude", /\b(?:nude|naked)\b/],
  ["nipples", /\bnipples?\b/],
  ["areolae", /\bareola/],
  ["pussy", /\bpussy\b/]
];
var SHOWS_CLEAVAGE = new RegExp(
  "\\b(?:cleavage|unbuttoned|open[- ]shirt|low[- ]cut|plunging|off[- ]shoulder|strapless|tube top|bikini|swimsuit|bra|lingerie|towel|deep v)\\b"
);
function dressedNegative(text, everyday) {
  const kept = DRESSED_NEGATIVE.filter(([, said]) => !said.test(text)).map(([tag]) => tag);
  return everyday && !SHOWS_CLEAVAGE.test(text) ? [...kept, "cleavage", "downblouse"] : kept;
}
var CLOTHING_WORDS = [
  "wearing",
  "dressed",
  "outfit",
  "clothes",
  // Everything the coverage tables in `photoBody` know as clothing, so the two agree on what
  // dresses her.
  "dress",
  "sundress",
  "gown",
  "coat",
  "raincoat",
  "jacket",
  "hoodie",
  "sweater",
  "cardigan",
  "shirt",
  "blouse",
  "top",
  "tank top",
  "crop top",
  "uniform",
  "pyjamas",
  "pajamas",
  "jeans",
  "trousers",
  "pants",
  "shorts",
  "skirt",
  "towel",
  "bra",
  "bralette",
  "bikini",
  "swimsuit",
  "swimwear",
  "one-piece",
  "lingerie",
  "negligee",
  "corset",
  "panties",
  "underwear",
  "thong",
  "g-string",
  "leggings",
  "stockings",
  "robe",
  "bathrobe",
  "kimono",
  "yukata",
  "apron",
  "costume"
];
var ACCESSORIES = [
  "hat",
  "beanie",
  "cap",
  "scarf",
  "glasses",
  "sunglasses",
  "earrings",
  "necklace",
  "choker",
  "bracelet",
  "ring",
  "bag",
  "purse",
  "backpack",
  "hair clip",
  "ribbon",
  "headphones",
  "watch"
];
var GARMENT_WORDS = CLOTHING_WORDS.filter((word) => word !== "wearing" && word !== "dressed");
function describesClothing(photoPrompt) {
  const text = photoPrompt.toLowerCase().replace(/\btop of\b/g, "");
  return saysAny(text, GARMENT_WORDS) || !saysAny(text, ACCESSORIES) && saysAny(text, ["wearing", "dressed"]);
}
function properNames(character) {
  const places = [...import_shared6.LOCATIONS, ...import_shared6.NARRATIVE_LOCATIONS].flatMap((place) => [
    place.label,
    // "the Agora" is also written bare, and the article would be left dangling otherwise.
    place.label.replace(/^the /i, "")
  ]);
  return [
    `${character.firstName} ${character.lastName}`,
    character.firstName,
    character.lastName,
    ...import_shared6.DORM_IDS.map(import_shared6.dormLabel),
    ...places
  ].filter((name) => name.length > 2).sort((a, b) => b.length - a.length);
}
function escaped(name) {
  return name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function withoutNames(character, scene) {
  const stripped = properNames(character).reduce(
    (text, name) => text.replace(new RegExp(`\\b${escaped(name)}(?:['\u2019]s)?\\b`, "gi"), ""),
    scene
  );
  return stripped.replace(/\s{2,}/g, " ").replace(/\s+([,.;:])/g, "$1").replace(/^[\s,]+/, "").trim();
}
var FOOD_COLOURS = {
  cream: "ivory",
  milk: "white",
  vanilla: "off-white",
  latte: "beige",
  butter: "pale yellow",
  honey: "amber",
  caramel: "light brown",
  cinnamon: "brown",
  coffee: "brown",
  mocha: "brown",
  chocolate: "dark brown",
  wine: "burgundy",
  cherry: "red",
  strawberry: "pink",
  peach: "light orange",
  lemon: "yellow",
  mint: "light green"
};
var COLOURED_THINGS = [
  "shirt",
  "blouse",
  "top",
  "sweater",
  "cardigan",
  "hoodie",
  "jacket",
  "coat",
  "dress",
  "sundress",
  "skirt",
  "shorts",
  "jeans",
  "trousers",
  "pants",
  "socks",
  "stockings",
  "thighhighs",
  "tights",
  "bra",
  "panties",
  "lingerie",
  "underwear",
  "bikini",
  "swimsuit",
  "towel",
  "robe",
  "pajamas",
  "pyjamas",
  "nightie",
  "sheets",
  "blanket",
  "pillow",
  "scarf",
  "hat",
  "beanie",
  "ribbon",
  "bow",
  "nails",
  "lipstick",
  "hair",
  "heels",
  "shoes",
  "sneakers",
  "boots",
  "loafers",
  "bag",
  "knit",
  "wall",
  "walls"
].join("|");
var FOOD_COLOUR = new RegExp(
  `(?<![a-z])(${Object.keys(FOOD_COLOURS).join("|")})(?:[-_ ]colou?red)?(?![a-z])(?=(?:[\\s_-]+[a-z]+){0,4}?[\\s_-]+(?:${COLOURED_THINGS})s?(?![a-z]))`,
  "gi"
);
var SHADE_OF = new RegExp(
  `\\b(?:${Object.keys(FOOD_COLOURS).join("|")})[\\s-]+(red|pink|blonde|brown|white|black|yellow|orange|green|blue|purple|beige|gold|silver)\\b`,
  "gi"
);
function plainColours(scene) {
  const shaded = scene.replace(SHADE_OF, "$1");
  return shaded.replace(FOOD_COLOUR, (word, food, at, text) => {
    const said = FOOD_COLOURS[food.toLowerCase()];
    const plain = text[at + word.length] === "_" ? said.replace(/ /g, "_") : said;
    return word[0] === word[0].toUpperCase() ? plain[0].toUpperCase() + plain.slice(1) : plain;
  });
}
function lookingAtViewer(scene) {
  if (/\b(?:her|a|film)\s+camera\b|\bpolaroid\b/i.test(scene)) return scene;
  return scene.replace(
    /\b(at|into|toward|towards|to)\s+the\s+(?:camera|lens|phone)\b/gi,
    (_whole, word) => `${word} the viewer`
  );
}
function drinkNotLiquid(scene) {
  return scene.replace(/\bliquid\b/gi, (word) => word[0] === "L" ? "Drink" : "drink");
}
function shopNotDrink(scene) {
  if (/\b(?:holding|holds|sipping|drinking|cup of|glass of|mug of)\b/i.test(scene)) return scene;
  return scene.replace(/\b(?:bubble tea|boba)\s+(shop|caf[eé]|bar|place|store)\b/gi, "tea $1");
}
var SPILL_NEGATIVE = [
  ["paint_splatter", /\b(?:paint|splatter)/],
  ["splashing", /\bsplash/],
  ["stain", /\bstain/]
];
function withoutWhoTookIt(scene) {
  const person = "(?:friend|roommate|bestie|best friend|boyfriend|sister|mom)";
  const taker = `(?:(?:a|her|my|his|the)\\s+${person}|somebody|someone)`;
  const takenBy = new RegExp(`\\s*,?\\s*(?:taken|shot|snapped)\\s+by\\s+${taker}\\b`, "gi");
  const tookOf = new RegExp(
    `\\b(?:that\\s+)?${taker}\\s+(?:took|snapped|shot)(?:\\s+of\\s+(?:her|me))?\\s*`,
    "gi"
  );
  return scene.replace(takenBy, "").replace(tookOf, "").replace(/\s{2,}/g, " ").replace(/\s+([,.;])/g, "$1").trim();
}
var GARMENT_COLOUR = new RegExp(
  "(?:^|[_\\s-])(?:pink|red|blue|green|purple|yellow|orange|brown|grey|gray|black|white|beige|navy|teal|cream|ivory|lavender|violet|maroon|burgundy|gold|silver|tan|khaki|olive)(?:$|[_\\s-])"
);
var TOP_GARMENT = new RegExp(
  "(?:^|[_\\s-])(?:top|shirt|t-shirt|blouse|sweater|cardigan|hoodie|bra|bralette|camisole|bandeau|dress|sundress|tank)s?(?:$|[_\\s-])"
);
function heldColour(tag) {
  const text = tag.toLowerCase();
  return GARMENT_COLOUR.test(text) && TOP_GARMENT.test(text) && !tag.startsWith("(") ? `(${tag}:1.2)` : tag;
}
function withoutOutfitName(scene, names) {
  if (names.length === 0) return scene;
  const named = names.map(escaped).sort((a, b) => b.length - a.length).join("|");
  const reference = new RegExp(
    `\\b(?:(?:dressed\\s+in|wearing|in|of)\\s+)?(?:(?:her|their)\\s+)?(?:own\\s+)?(?:["\u201C])?(?:${named})(?:s|es)?(?![a-z0-9])(?:["\u201D])?(?:\\s+(?:clothes|cloth|outfit)\\b)?`,
    "gi"
  );
  return scene.replace(reference, "").replace(/\s{2,}/g, " ").replace(/\s+([,.;])/g, "$1").replace(/,\s*,/g, ",").replace(/^[\s,]+|[\s,]+$/g, "");
}
function buildPhotoPrompt(character, tier, photoPrompt) {
  const scene = shopNotDrink(drinkNotLiquid(plainColours(withoutNames(character, photoPrompt.trim()))));
  const bare = tier === "explicit";
  const dressed = describesClothing(scene);
  const pose = photoPose(scene, tier);
  if (tier === "everyday") pose.tags = pose.tags.filter((tag) => !EVERYDAY_DROPS.has(tag));
  const selected = wardrobeForPhoto(character, tier, scene, dressed);
  const body = bodyTagsFor(
    bodyOf(character),
    scene,
    bare,
    framingInTags(pose.tags),
    selected.exposure
  );
  const wardrobe = plainColours(selected.tags.map(heldColour).join(", "));
  const caption = withoutOutfitName(scene, selected.names);
  const appearance = bodyAppearance(character, "photo");
  const base = appearance.includes("1girl") ? PHOTO_BASE.replace("1girl, ", "") : PHOTO_BASE;
  const worn = `${appearance.join(" ")} ${wardrobe} ${scene}`;
  const positive = [
    `${PHOTO_QUALITY}, ${base}`,
    appearance.join(", "),
    body.join(", "),
    wardrobe,
    // The sentence's own full stop would sit in front of the tags that follow it.
    [
      lookingAtViewer(
        withoutSelfieWord(withoutHeldObject(withoutCameraHold(withoutWhoTookIt(caption))))
      ).replace(/[.!?]+$/, ""),
      pose.tags.join(", ")
    ].filter((part) => part.length > 0).join(", ")
  ].filter((group) => group.length > 0).join(",\n\n");
  const negative = [
    PHOTO_NEGATIVE,
    ...bare ? [] : dressedNegative(worn.toLowerCase().replace(/_/g, " "), tier === "everyday"),
    ...SPILL_NEGATIVE.filter(([, said]) => !said.test(scene.toLowerCase())).map(([tag]) => tag),
    ...pose.negative,
    ...bodyNegative(character),
    ...character.negativeTags ?? []
  ].join(", ");
  return { positive, negative };
}
function wardrobeForPhoto(character, tier, scene, captionDressesHer) {
  const bare = tier === "explicit";
  const named = photoWardrobeNames(character, scene);
  const reveals = bare ? displacedTags(scene) : [];
  const partial = bare && (captionDressesHer || named.length > 0 || reveals.length > 0) && !describesNothingOn(scene);
  const names = !bare || partial ? named : [];
  const outfit = !bare || names.length > 0 ? photoWardrobe(character, scene, captionDressesHer, tier !== "everyday") ?? [] : partial ? photoWardrobeFromGarment(character, scene) ?? [] : [];
  const exposure = partial ? partialExposureIn(scene, reveals, outfit) : void 0;
  const tags = bare ? partial ? [
    ...outfit,
    "partially_undressed",
    ...reveals,
    ...exposure?.upper ? ["breasts_out"] : [],
    ...exposure?.bottomless ? ["bottomless"] : [],
    BARE_POSITIVE
  ] : ["nude", "completely_nude", BARE_POSITIVE] : [...outfit, ...tier === "suggestive" ? suggestiveReveals(scene) : []];
  return { tags: [...new Set(tags)], names, exposure };
}
var EVERYDAY_DROPS = /* @__PURE__ */ new Set(["undressing", "clothes_pull"]);
var GARMENT_GAP = "(?:\\s+(?!to\\b|and\\b|while\\b|with\\b|beside\\b)[a-z'\u2019-]+){0,4}?\\s+";
var LOWERED = "(?:pull(?:ing|ed) down|tugg(?:ing|ed) down|lower(?:ing|ed))";
var LIFTED = "(?:lift(?:ing|ed)|rais(?:ing|ed)|pull(?:ing|ed) up|push(?:ing|ed) up|holding up|hiked up|hitched up|bunched)";
var ASIDE = "(?:pull(?:ing|ed) (?:to the side|aside)|tugg(?:ing|ed) aside|moved aside)";
var TOPS = ["shirt", "top", "blouse", "sweater", "hoodie", "tank top", "crop top"];
function garmentMove(garments, motion) {
  const garment = `(?:${garments.map(escaped).join("|")})(?:s|es)?`;
  return new RegExp(
    `\\b(?:${motion})\\b${GARMENT_GAP}${garment}\\b|\\b${garment}\\b${GARMENT_GAP}(?:${motion})\\b`
  );
}
var DISPLACEMENTS = [
  { words: garmentMove([...TOPS, "neckline", "dress"], LOWERED), tags: ["clothes_pull"] },
  { words: garmentMove(TOPS, LIFTED), tags: ["shirt_lift"] },
  { words: garmentMove(["skirt", "dress"], LIFTED), tags: ["skirt_lift"] },
  { words: garmentMove(["skirt", "dress"], ASIDE), tags: ["skirt_lift"] },
  {
    words: garmentMove(["thong", "panties", "underwear", "g-string", "bikini bottom"], ASIDE),
    tags: ["panties_aside"]
  },
  {
    words: garmentMove(["thong", "panties", "underwear", "g-string", "bikini bottom"], LOWERED),
    tags: ["panty_pull"]
  },
  { words: garmentMove(["shorts", "pants", "trousers"], LOWERED), tags: ["pants_pull"] },
  { words: garmentMove(["bra", "bikini top"], LIFTED), tags: ["bra_lift"] },
  { words: garmentMove(["bra", "bikini top"], LOWERED), tags: ["bra_pull"] },
  {
    words: garmentMove(["shirt", "blouse"], "(?:open|unbuttoned|unbuttoning)"),
    tags: ["open_shirt"]
  },
  { words: /\b(?:unbuttoned|unbuttoning|open clothes|clothes open)\b/, tags: ["open_clothes"] },
  {
    words: new RegExp(
      "\\b(?:bare|baring|bared|show(?:ing|n)?|expos(?:e|ing|ed)|reveal(?:ing|ed)?|uncover(?:ing|ed)?)\\b(?:\\s+[a-z'\u2019-]+){0,3}\\s+(?:breasts?|boobs?|chest)\\b|\\b(?:breasts?|boobs?|chest)\\b(?:\\s+[a-z'\u2019-]+){0,3}\\s+(?:bare|bared|shown|exposed|uncovered)\\b"
    ),
    tags: ["breasts_out"]
  },
  { words: /\bunderboob\b/, tags: ["underboob"] },
  { words: /\btopless\b/, tags: ["breasts_out"] },
  { words: /\bbottomless\b/, tags: ["bottomless"] },
  {
    words: garmentMove(
      ["panties", "underwear", "thong"],
      "(?:removed|removing|took off|taken off|no)"
    ),
    tags: ["no_panties"]
  },
  {
    words: /\bpanties\b(?:\s+[a-z'’-]+){0,2}\s+around (?:her |one )?(?:ankles?|knees?|legs?)\b/,
    tags: ["panty_pull"]
  },
  {
    words: /\bpanties\b(?:\s+[a-z'’-]+){0,2}\s+around (?:her )?one leg\b/,
    tags: ["panties_around_one_leg"]
  },
  {
    words: new RegExp(
      "\\b(?:bare|expos(?:e|ing|ed)|show(?:ing|n)?)(?:\\s+[a-z'\u2019-]+){0,3}\\s+(?:slit|pussy)\\b|\\b(?:slit|pussy)\\b(?:\\s+[a-z'\u2019-]+){0,3}\\s+(?:bare|showing|shown|exposed)\\b"
    ),
    tags: ["pussy"]
  }
];
var SUGGESTIVE_REVEALS = [
  {
    words: new RegExp(
      "\\boff[- ]shoulder\\b|\\b(?:sweater|top|shirt|blouse)\\b(?:\\s+[a-z'\u2019-]+){0,4}\\s+off(?:\\s+[a-z'\u2019-]+){0,3}\\s+shoulder\\b"
    ),
    tags: ["off_shoulder"]
  },
  {
    words: /\bstraps?\b(?:\s+[a-z'’-]+){0,3}\s+(?:slipp(?:ing|ed)|slid(?:ing)?)\s+down\b/,
    tags: ["strap_slip"]
  },
  {
    words: garmentMove(TOPS, LIFTED),
    needs: ["bra", "stomach", "midriff", "belly"],
    tags: ["shirt_lift", "bra"]
  },
  { words: garmentMove(["neckline"], "(?:tugg(?:ing|ed)|pull(?:ing|ed))"), tags: ["clothes_pull"] },
  {
    words: garmentMove(["skirt"], `(?:${LIFTED}|flipp(?:ing|ed))`),
    needs: ["panties", "underwear", "thong"],
    tags: ["skirt_lift", "panties"]
  }
];
function revealTags(scene, table) {
  const text = scene.toLowerCase();
  return [
    ...new Set(
      table.filter((row) => row.words.test(text) && (!row.needs || saysAny(text, row.needs))).flatMap((row) => row.tags)
    )
  ];
}
function displacedTags(scene) {
  const tags = revealTags(scene, DISPLACEMENTS);
  const moved = new RegExp(
    `\\b(?:${LOWERED}|${LIFTED}|${ASIDE}|pull(?:ing|ed)|tugg(?:ing|ed)|pushed aside)\\b`,
    "i"
  );
  if (!tags.some((tag) => tag !== "breasts_out" && tag !== "underboob") && moved.test(scene)) {
    tags.push("clothes_pull");
  }
  return tags;
}
function suggestiveReveals(scene) {
  return revealTags(scene, SUGGESTIVE_REVEALS);
}
var TOUCHING = new RegExp(
  `\\s*,?\\s*\\b(?:hugg\\w*|hugs?|cuddl\\w*|snuggl\\w*|embrac\\w*|kiss\\w*|holding hands|hand in hand|arm in arm|arms? (?:around|linked|wrapped)|leaning (?:on|against) (?:each other|her)|cheek to cheek|head on (?:her|each other)\\S*\\s+shoulder)[^,.;]*?(?=\\s+and\\s|${PHOTO_CLAUSE_END})`,
  "gi"
);
function withoutTouching(scene) {
  return scene.replace(TOUCHING, "").replace(/\s{2,}/g, " ").replace(/\s+([,.;])/g, "$1").trim();
}
var WORN_CLAUSE = new RegExp(
  `,?\\s*\\b(?:wearing|dressed in|in (?:their|her|matching)\\b)[^,.;]*?(?=\\s+(?:wearing|dressed in)\\b|${PHOTO_CLAUSE_END})`,
  "gi"
);
var DUO_EXPRESSIONS = [
  [/\blaugh/i, ["laughing", "open_mouth"]],
  [/\bgrin/i, ["grin"]],
  [/\bwink/i, ["one_eye_closed"]],
  [/\bpout/i, ["pout"]],
  [/\btongue/i, ["tongue_out"]],
  [/\bsleepy|\bdrowsy|\byawn/i, ["sleepy"]],
  [/\bsmirk/i, ["smirk"]],
  [/\bsmil/i, ["smile"]]
];
function duoExpression(text) {
  const said = DUO_EXPRESSIONS.filter(([words]) => words.test(text)).flatMap(([, tags]) => tags);
  return [...new Set(said.length > 0 ? said : ["smile"]), .../\bblush/i.test(text) ? ["blush"] : []];
}
var BELOW_WAIST = /(?:thigh[_\s-]?high|socks?|stockings?|pantyhose|tights|legwear|leggings|shoes|sneakers|boots|heels|loafers|sandals|mary_janes|skirt|jeans|pants|trousers|shorts|buruma|bloomers|belt|^navel$|^midriff$|^thighs$|^bare_legs$)/i;
var DUO_POSTURE = /* @__PURE__ */ new Set([
  "standing",
  "sitting",
  "lying",
  "on_back",
  "on_side",
  "on_stomach",
  "kneeling",
  "from_above",
  "looking_at_viewer",
  "looking_away",
  "indian_style",
  "crossed_legs"
]);
function duoFraming(text) {
  if (saysAny(text, ["from behind", "back view", "backs to", "looking back", "over her shoulder"])) {
    return {
      tags: ["(from_behind:1.3)", "looking_back", "(upper_body:1.3)"],
      scene: ["both with their backs to the viewer"]
    };
  }
  if (framingOf(text) === "face") {
    return { tags: ["(close-up:1.3)", "(portrait:1.3)"], scene: [] };
  }
  return { tags: ["(upper_body:1.3)"], scene: ["same height"] };
}
function duoHalf(girl, tier, scene, posture, extra) {
  const bare = tier === "explicit";
  const dressed = bare && describesClothing(scene);
  const appearance = bodyAppearance(girl, "photo").filter((tag) => tag !== "1girl");
  const selected = wardrobeForPhoto(girl, tier, scene, dressed);
  const body = bodyTagsFor(bodyOf(girl), scene, bare, "waist", selected.exposure).filter(
    (tag) => bare || !BELOW_WAIST.test(tag)
  );
  const wardrobe = selected.tags.filter((tag) => bare || !BELOW_WAIST.test(tag)).map(heldColour);
  return {
    prompt: plainColours(
      [PHOTO_QUALITY, "1girl, solo", ...appearance, ...body, ...wardrobe, ...posture, ...extra].join(
        ", "
      )
    ),
    worn: `${appearance.join(" ")} ${wardrobe.join(" ")}`,
    names: selected.names
  };
}
function friendAsFriend(friend, scene) {
  return [`${friend.firstName} ${friend.lastName}`, friend.firstName].filter((name) => name.length > 2).reduce(
    (text, name) => text.replace(new RegExp(`\\b${escaped(name)}(?:['\u2019]s)?\\b`, "gi"), "her friend"),
    scene
  );
}
function senderAsHer(sender, scene) {
  return [`${sender.firstName} ${sender.lastName}`, sender.firstName].filter((name) => name.length > 2).reduce(
    (text, name) => text.replace(
      new RegExp(`\\b${escaped(name)}(?:['\u2019]s)?\\b`, "gi"),
      (_said, at) => at === 0 ? "Her" : "her"
    ),
    scene
  );
}
function buildDuoPhotoPrompt(sender, friend, tier, photoPrompt) {
  const named = withoutNames(sender, senderAsHer(sender, friendAsFriend(friend, photoPrompt.trim())));
  const scene = withoutTouching(shopNotDrink(drinkNotLiquid(plainColours(named))));
  const text = scene.toLowerCase();
  const bare = tier === "explicit";
  const pose = photoPose(scene, tier);
  const posture = pose.tags.filter((tag) => DUO_POSTURE.has(tag));
  const framing = duoFraming(text);
  const selfie = says(text, "selfie");
  const mirror = selfie && says(text, "mirror");
  const lying = posture.includes("lying");
  const holds = mirror ? ["holding_phone"] : selfie && !lying ? ["selfie", "outstretched_arm"] : [];
  const phoneNegative = selfie && !mirror ? ["phone", "cellphone", "smartphone", "holding_phone"] : [];
  const shared = [...framing.tags];
  const faces = duoExpression(text);
  const left = duoHalf(sender, tier, scene, posture, [...faces, ...shared, ...holds]);
  const right = duoHalf(friend, tier, scene, posture, [...faces, ...shared]);
  const dressedScene = withoutOutfitName(scene, [...left.names, ...right.names]);
  const sentence = lookingAtViewer(
    withoutWhoTookIt(
      withoutCameraHold(lying ? dressedScene.replace(/\bselfie\b/gi, "photo") : dressedScene)
    )
  ).replace(WORN_CLAUSE, (clause) => describesClothing(clause) ? "" : clause).replace(/\s{2,}/g, " ").replace(/\s+([,.;])/g, "$1").replace(/[.!?]+$/, "");
  const sceneTags = [
    `${PHOTO_QUALITY}, 2girls, multiple_girls, depth_of_field`,
    sentence,
    "side by side",
    ...framing.scene,
    ...mirror ? ["mirror", "reflection"] : [],
    ...shared
  ];
  const worn = `${scene} ${left.worn} ${right.worn}`;
  const negative = [
    PHOTO_NEGATIVE.replace("multiple_girls, 2girls, ", ""),
    "3girls",
    ...bare ? [] : dressedNegative(worn.toLowerCase().replace(/_/g, " "), tier === "everyday"),
    ...SPILL_NEGATIVE.filter(([, said]) => !said.test(text)).map(([tag]) => tag),
    ...phoneNegative,
    ...mirror || saysAny(text, ["camera"]) ? [] : ["camera"],
    .../* @__PURE__ */ new Set([...bodyNegative(sender), ...bodyNegative(friend)])
  ].join(", ");
  return {
    scene: sceneTags.filter((part) => part.length > 0).join(", "),
    left: left.prompt,
    right: right.prompt,
    negative
  };
}

// src/main/bodySetting.ts
async function withBodySetting(character) {
  return gateBody(character, photoFeatureOn() && photoSwitches().body);
}

// src/main/services/localPhotoService.ts
var import_main3 = require("@vx/modkit/main");

// assets/workflows/characterPhoto.json
var characterPhoto_default = {
  "1": {
    class_type: "CheckpointLoaderSimple",
    _meta: {
      title: "Checkpoint"
    },
    inputs: {
      ckpt_name: "novaAnimeXL_ilV190.safetensors"
    }
  },
  "3": {
    class_type: "LoraLoader",
    _meta: {
      title: "Style LoRA"
    },
    inputs: {
      model: [
        "1",
        0
      ],
      clip: [
        "1",
        1
      ],
      lora_name: "usnrStyle.safetensors",
      strength_model: 1,
      strength_clip: 1
    }
  },
  "4": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Positive"
    },
    inputs: {
      clip: [
        "100",
        1
      ],
      text: ""
    }
  },
  "5": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Negative"
    },
    inputs: {
      clip: [
        "100",
        1
      ],
      text: ""
    }
  },
  "7": {
    class_type: "KSampler",
    _meta: {
      title: "KSampler"
    },
    inputs: {
      model: [
        "100",
        0
      ],
      positive: [
        "4",
        0
      ],
      negative: [
        "5",
        0
      ],
      latent_image: [
        "15",
        0
      ],
      seed: [
        "14",
        0
      ],
      steps: 16,
      cfg: 4,
      sampler_name: "dpmpp_2m_sde",
      scheduler: "sgm_uniform",
      denoise: 1
    }
  },
  "8": {
    class_type: "VAEDecode",
    _meta: {
      title: "Decode"
    },
    inputs: {
      samples: [
        "7",
        0
      ],
      vae: [
        "1",
        2
      ]
    }
  },
  "14": {
    class_type: "SeedNode",
    _meta: {
      title: "Photo Seed"
    },
    inputs: {
      seed: 0
    }
  },
  "15": {
    class_type: "EmptyLatentImage",
    _meta: {
      title: "Latent"
    },
    inputs: {
      width: 832,
      height: 1216,
      batch_size: 1
    }
  },
  "16": {
    class_type: "ImageUpscaleWithModel",
    _meta: {
      title: "Upscale 4x"
    },
    inputs: {
      upscale_model: [
        "17",
        0
      ],
      image: [
        "8",
        0
      ]
    }
  },
  "17": {
    class_type: "UpscaleModelLoader",
    _meta: {
      title: "Upscaler"
    },
    inputs: {
      model_name: "RealESRGAN_x4plus_anime_6B.pth"
    }
  },
  "19": {
    class_type: "ImageScaleBy",
    _meta: {
      title: "Scale back"
    },
    inputs: {
      image: [
        "16",
        0
      ],
      upscale_method: "lanczos",
      scale_by: 0.35
    }
  },
  "20": {
    class_type: "FaceDetailer",
    _meta: {
      title: "Face pass"
    },
    inputs: {
      image: [
        "19",
        0
      ],
      model: [
        "100",
        0
      ],
      clip: [
        "100",
        1
      ],
      vae: [
        "1",
        2
      ],
      positive: [
        "4",
        0
      ],
      negative: [
        "5",
        0
      ],
      bbox_detector: [
        "29",
        0
      ],
      segm_detector_opt: [
        "29",
        1
      ],
      guide_size: 512,
      guide_size_for: true,
      max_size: 1024,
      seed: [
        "14",
        0
      ],
      steps: 12,
      cfg: 4,
      sampler_name: "dpmpp_2m_sde",
      scheduler: "simple",
      denoise: 0.35,
      feather: 5,
      noise_mask: true,
      force_inpaint: true,
      bbox_threshold: 0.5,
      bbox_dilation: 10,
      bbox_crop_factor: 3,
      sam_detection_hint: "center-1",
      sam_dilation: 0,
      sam_threshold: 0.93,
      sam_bbox_expansion: 0,
      sam_mask_hint_threshold: 0.7,
      sam_mask_hint_use_negative: "False",
      drop_size: 10,
      wildcard: "",
      cycle: 1,
      inpaint_model: false,
      noise_mask_feather: 20,
      tiled_encode: false,
      tiled_decode: false
    }
  },
  "29": {
    class_type: "UltralyticsDetectorProvider",
    _meta: {
      title: "Face segmenter"
    },
    inputs: {
      model_name: "segm/Anzhc%20Face%20seg%20640%20v2%20y8n.pt"
    }
  },
  "41": {
    class_type: "SaveImage",
    _meta: {
      title: "Save Photo"
    },
    inputs: {
      images: [
        "20",
        0
      ],
      filename_prefix: "venus-university/photo"
    }
  },
  "100": {
    class_type: "LoraLoader",
    _meta: {
      title: "Character LoRA"
    },
    inputs: {
      model: [
        "3",
        0
      ],
      clip: [
        "3",
        1
      ],
      lora_name: "characterLora.safetensors",
      strength_model: 1,
      strength_clip: 1
    }
  }
};

// assets/workflows/characterPhotoDuo.json
var characterPhotoDuo_default = {
  "1": {
    class_type: "CheckpointLoaderSimple",
    _meta: {
      title: "Checkpoint"
    },
    inputs: {
      ckpt_name: "novaAnimeXL_ilV190.safetensors"
    }
  },
  "3": {
    class_type: "LoraLoader",
    _meta: {
      title: "Style LoRA"
    },
    inputs: {
      model: [
        "1",
        0
      ],
      clip: [
        "1",
        1
      ],
      lora_name: "usnrStyle.safetensors",
      strength_model: 1,
      strength_clip: 1
    }
  },
  "4": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Scene"
    },
    inputs: {
      clip: [
        "3",
        1
      ],
      text: ""
    }
  },
  "5": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Negative"
    },
    inputs: {
      clip: [
        "3",
        1
      ],
      text: ""
    }
  },
  "7": {
    class_type: "KSampler",
    _meta: {
      title: "KSampler"
    },
    inputs: {
      model: [
        "3",
        0
      ],
      positive: [
        "55",
        0
      ],
      negative: [
        "5",
        0
      ],
      latent_image: [
        "15",
        0
      ],
      seed: [
        "14",
        0
      ],
      steps: 16,
      cfg: 4,
      sampler_name: "dpmpp_2m_sde",
      scheduler: "sgm_uniform",
      denoise: 1
    }
  },
  "8": {
    class_type: "VAEDecode",
    _meta: {
      title: "Decode"
    },
    inputs: {
      samples: [
        "7",
        0
      ],
      vae: [
        "1",
        2
      ]
    }
  },
  "14": {
    class_type: "SeedNode",
    _meta: {
      title: "Photo Seed"
    },
    inputs: {
      seed: 0
    }
  },
  "15": {
    class_type: "EmptyLatentImage",
    _meta: {
      title: "Latent"
    },
    inputs: {
      width: 832,
      height: 1216,
      batch_size: 1
    }
  },
  "16": {
    class_type: "ImageUpscaleWithModel",
    _meta: {
      title: "Upscale 4x"
    },
    inputs: {
      upscale_model: [
        "17",
        0
      ],
      image: [
        "8",
        0
      ]
    }
  },
  "17": {
    class_type: "UpscaleModelLoader",
    _meta: {
      title: "Upscaler"
    },
    inputs: {
      model_name: "RealESRGAN_x4plus_anime_6B.pth"
    }
  },
  "19": {
    class_type: "ImageScaleBy",
    _meta: {
      title: "Scale back"
    },
    inputs: {
      image: [
        "16",
        0
      ],
      upscale_method: "lanczos",
      scale_by: 0.35
    }
  },
  "41": {
    class_type: "SaveImage",
    _meta: {
      title: "Save Photo"
    },
    inputs: {
      images: [
        "61",
        0
      ],
      filename_prefix: "venus-university/photo-duo"
    }
  },
  "50": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Left girl"
    },
    inputs: {
      clip: [
        "3",
        1
      ],
      text: ""
    }
  },
  "51": {
    class_type: "CLIPTextEncode",
    _meta: {
      title: "Right girl"
    },
    inputs: {
      clip: [
        "3",
        1
      ],
      text: ""
    }
  },
  "52": {
    class_type: "ConditioningSetArea",
    _meta: {
      title: "Left half"
    },
    inputs: {
      conditioning: [
        "50",
        0
      ],
      width: 416,
      height: 1216,
      x: 0,
      y: 0,
      strength: 2
    }
  },
  "53": {
    class_type: "ConditioningSetArea",
    _meta: {
      title: "Right half"
    },
    inputs: {
      conditioning: [
        "51",
        0
      ],
      width: 416,
      height: 1216,
      x: 416,
      y: 0,
      strength: 2
    }
  },
  "54": {
    class_type: "ConditioningCombine",
    _meta: {
      title: "Both halves"
    },
    inputs: {
      conditioning_1: [
        "52",
        0
      ],
      conditioning_2: [
        "53",
        0
      ]
    }
  },
  "55": {
    class_type: "ConditioningCombine",
    _meta: {
      title: "Scene and halves"
    },
    inputs: {
      conditioning_1: [
        "4",
        0
      ],
      conditioning_2: [
        "54",
        0
      ]
    }
  },
  "29": {
    class_type: "UltralyticsDetectorProvider",
    _meta: {
      title: "Face segmenter"
    },
    inputs: {
      model_name: "segm/Anzhc%20Face%20seg%20640%20v2%20y8n.pt"
    }
  },
  "56": {
    class_type: "ImageCrop",
    _meta: {
      title: "Left half"
    },
    inputs: {
      image: [
        "19",
        0
      ],
      width: 582,
      height: 1702,
      x: 0,
      y: 0
    }
  },
  "57": {
    class_type: "ImageCrop",
    _meta: {
      title: "Right half"
    },
    inputs: {
      image: [
        "19",
        0
      ],
      width: 583,
      height: 1702,
      x: 582,
      y: 0
    }
  },
  "58": {
    class_type: "FaceDetailer",
    _meta: {
      title: "Left face"
    },
    inputs: {
      image: [
        "56",
        0
      ],
      model: [
        "3",
        0
      ],
      clip: [
        "3",
        1
      ],
      vae: [
        "1",
        2
      ],
      positive: [
        "50",
        0
      ],
      negative: [
        "5",
        0
      ],
      bbox_detector: [
        "29",
        0
      ],
      segm_detector_opt: [
        "29",
        1
      ],
      guide_size: 512,
      guide_size_for: true,
      max_size: 1024,
      seed: [
        "14",
        0
      ],
      steps: 12,
      cfg: 4,
      sampler_name: "dpmpp_2m_sde",
      scheduler: "simple",
      denoise: 0.35,
      feather: 5,
      noise_mask: true,
      force_inpaint: true,
      bbox_threshold: 0.5,
      bbox_dilation: 10,
      bbox_crop_factor: 3,
      sam_detection_hint: "center-1",
      sam_dilation: 0,
      sam_threshold: 0.93,
      sam_bbox_expansion: 0,
      sam_mask_hint_threshold: 0.7,
      sam_mask_hint_use_negative: "False",
      drop_size: 10,
      wildcard: "",
      cycle: 1,
      inpaint_model: false,
      noise_mask_feather: 20,
      tiled_encode: false,
      tiled_decode: false
    }
  },
  "59": {
    class_type: "FaceDetailer",
    _meta: {
      title: "Right face"
    },
    inputs: {
      image: [
        "57",
        0
      ],
      model: [
        "3",
        0
      ],
      clip: [
        "3",
        1
      ],
      vae: [
        "1",
        2
      ],
      positive: [
        "51",
        0
      ],
      negative: [
        "5",
        0
      ],
      bbox_detector: [
        "29",
        0
      ],
      segm_detector_opt: [
        "29",
        1
      ],
      guide_size: 512,
      guide_size_for: true,
      max_size: 1024,
      seed: [
        "14",
        0
      ],
      steps: 12,
      cfg: 4,
      sampler_name: "dpmpp_2m_sde",
      scheduler: "simple",
      denoise: 0.35,
      feather: 5,
      noise_mask: true,
      force_inpaint: true,
      bbox_threshold: 0.5,
      bbox_dilation: 10,
      bbox_crop_factor: 3,
      sam_detection_hint: "center-1",
      sam_dilation: 0,
      sam_threshold: 0.93,
      sam_bbox_expansion: 0,
      sam_mask_hint_threshold: 0.7,
      sam_mask_hint_use_negative: "False",
      drop_size: 10,
      wildcard: "",
      cycle: 1,
      inpaint_model: false,
      noise_mask_feather: 20,
      tiled_encode: false,
      tiled_decode: false
    }
  },
  "60": {
    class_type: "ImageCompositeMasked",
    _meta: {
      title: "Left back in"
    },
    inputs: {
      destination: [
        "19",
        0
      ],
      source: [
        "58",
        0
      ],
      x: 0,
      y: 0,
      resize_source: false
    }
  },
  "61": {
    class_type: "ImageCompositeMasked",
    _meta: {
      title: "Right back in"
    },
    inputs: {
      destination: [
        "60",
        0
      ],
      source: [
        "59",
        0
      ],
      x: 582,
      y: 0,
      resize_source: false
    }
  }
};

// src/main/services/localPhotoService.ts
var DUO_PHOTO_NODE = {
  seed: "14",
  positivePrompt: "4",
  negativePrompt: "5",
  saveImage: "41"
};
var PHOTO_NODE = { ...DUO_PHOTO_NODE, characterLora: "100" };
function assertPhotoFile(file) {
  if (!isPhotoFile(file)) {
    throw (0, import_shared7.appError)("PHOTO_FILE_INVALID", "That is not a picture this game would have named.", file);
  }
}
var reservedPhotoNames = /* @__PURE__ */ new Map();
async function takenPhotoNames(playthroughId, charId) {
  const folder = getPhotosPath(playthroughId, charId);
  await movePhotoFiles(playthroughId);
  const onDisk = [
    ...await photoNames(folder),
    ...await photoNames((0, import_path3.join)(legacyPhotosRoot(playthroughId), charId))
  ];
  return [...onDisk, ...reservedPhotoNames.get(folder) ?? []];
}
async function reservePhotoName(playthroughId, character, kind, inSave = []) {
  (0, import_shared7.assertSafeCharId)(character.charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  if (!isPhotoKind(kind)) {
    throw (0, import_shared7.appError)("PHOTO_KIND_UNKNOWN", `"${String(kind)}" is not a kind of picture.`, kind);
  }
  const slug = photoSlug(character.firstName, character.charId);
  const saved = Array.isArray(inSave) ? inSave.filter((name) => typeof name === "string" && isPhotoFile(name)) : [];
  const taken = [...await takenPhotoNames(playthroughId, character.charId), ...saved];
  const file = photoFileName(
    slug,
    kind,
    nextPhotoIndex(taken, slug, kind),
    photoSwitches().webp ? "webp" : "png"
  );
  const folder = getPhotosPath(playthroughId, character.charId);
  const held = reservedPhotoNames.get(folder) ?? /* @__PURE__ */ new Set();
  held.add(file);
  reservedPhotoNames.set(folder, held);
  return file;
}
async function photoLanded(playthroughId, charId, file) {
  (0, import_shared7.assertSafeCharId)(charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  if (!isPhotoFile(file)) return false;
  return await findPhotoImage(playthroughId, charId, file) !== null;
}
async function readPhotoBytes(playthroughId, charId, file) {
  (0, import_shared7.assertSafeCharId)(charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  assertPhotoFile(file);
  return readPhotoImage(playthroughId, charId, file);
}
async function storeWebpPhoto(playthroughId, charId, file, bytes) {
  (0, import_shared7.assertSafeCharId)(charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  if (!isWebpPhoto(file)) {
    throw (0, import_shared7.appError)("PHOTO_FILE_INVALID", "That picture was not meant to be WebP.", file);
  }
  if (!(bytes instanceof Uint8Array) || (0, import_shared7.imageTypeOf)(bytes) !== "image/webp") {
    throw (0, import_shared7.appError)("PHOTO_NOT_WEBP", "The encoded picture is not a WebP.", file);
  }
  await movePhotoFiles(playthroughId);
  await (0, import_promises3.mkdir)(getPhotosPath(playthroughId, charId), { recursive: true });
  const path = getPhotoPath(playthroughId, charId, file);
  await (0, import_main3.writeAtomicBytes)(path, bytes, {
    code: "PHOTO_WRITE_FAILED",
    message: "Could not save the photo as WebP."
  });
  await dropPhotoTwins(path);
}
async function carryPhotos(fromPlaythroughId, toPlaythroughId, charIds) {
  (0, import_shared7.assertSafePlaythroughId)(fromPlaythroughId);
  (0, import_shared7.assertSafePlaythroughId)(toPlaythroughId);
  await movePhotoFiles(fromPlaythroughId);
  await movePhotoFiles(toPlaythroughId);
  const roots = [getPhotosRoot(fromPlaythroughId), legacyPhotosRoot(fromPlaythroughId)];
  const who = charIds ?? [...new Set((await Promise.all(roots.map(photoCharacters))).flat())];
  for (const charId of who) {
    (0, import_shared7.assertSafeCharId)(charId);
    const sources = /* @__PURE__ */ new Map();
    for (const root of roots) {
      for (const file of await photoNames((0, import_path3.join)(root, charId))) {
        if (!sources.has(file)) sources.set(file, (0, import_path3.join)(root, charId, file));
      }
    }
    for (const [file, source] of sources) {
      if (!isPhotoSidecar(file)) {
        await copyPhotoFile(source, getPhotoPath(toPlaythroughId, charId, file), true);
      }
    }
    for (const [file, source] of sources) {
      if (!isPhotoSidecar(file) || !await readPhotoSidecar(source)) continue;
      const stem = file.replace(/\.json$/, "");
      const targetImage = await findPhotoImage(toPlaythroughId, charId, `${stem}.png`);
      if (!targetImage) continue;
      let matched = false;
      for (const name of [`${stem}.webp`, `${stem}.png`]) {
        const sourceImage = sources.get(name);
        if (sourceImage && (await (0, import_promises3.readFile)(sourceImage)).equals(await (0, import_promises3.readFile)(targetImage))) {
          matched = true;
          break;
        }
      }
      if (matched) await copyPhotoFile(source, getPhotoPath(toPlaythroughId, charId, file), true);
    }
  }
}
function isOverrideRecord(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function validatePhotoOverrides(value, duo) {
  const invalid = () => {
    throw (0, import_shared7.appError)("PHOTO_OVERRIDE_INVALID", "The photo seed or prompts are invalid.");
  };
  if (!isOverrideRecord(value)) invalid();
  const overrides = value;
  if (Object.keys(overrides).some((key) => key !== "seed" && key !== "prompts")) invalid();
  if (overrides.seed !== void 0 && (!Number.isSafeInteger(overrides.seed) || overrides.seed < 0)) {
    invalid();
  }
  if (overrides.prompts === void 0) return;
  if (!isOverrideRecord(overrides.prompts)) invalid();
  const prompts = overrides.prompts;
  const keys = duo ? ["positive", "negative", "left", "right"] : ["positive", "negative"];
  if (Object.keys(prompts).some((key) => !keys.includes(key))) invalid();
  for (const key of keys) {
    if (typeof prompts[key] !== "string" || prompts[key].length > PHOTO_PROMPT_LIMIT) invalid();
  }
  if (!prompts.positive.trim()) invalid();
}
async function generatePhoto(playthroughId, character, tier, photoPrompt, file, options = {}, overrides = {}) {
  validatePhotoOverrides(overrides, false);
  (0, import_shared7.assertSafeCharId)(character.charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  if (!isPhotoTier(tier)) {
    throw (0, import_shared7.appError)("PHOTO_TIER_UNKNOWN", `"${String(tier)}" is not a photo tier.`, tier);
  }
  if (!photoPrompt.trim()) {
    throw (0, import_shared7.appError)("PHOTO_PROMPT_MISSING", "There is nothing to take a picture of.");
  }
  if (options.signal?.aborted) throw (0, import_shared7.appError)("CANCELLED", "Generation was cancelled.");
  options.onProgress?.("Preparing");
  assertPhotoFile(file);
  const seed = overrides.seed ?? Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
  const lora = (0, import_shared7.characterLoraOf)(character);
  const prompts = overrides.prompts ? { positive: overrides.prompts.positive, negative: overrides.prompts.negative } : buildPhotoPrompt(await withBodySetting(character), tier, photoPrompt);
  await renderPhotoImage(playthroughId, character.charId, file, {
    workflow: characterPhoto_default,
    nodes: PHOTO_NODE,
    prompts,
    seed,
    lora
  }, { schemaVersion: 1, seed, tier, ...prompts, ...lora ? { lora } : {} }, options);
  reservedPhotoNames.get(getPhotosPath(playthroughId, character.charId))?.delete(file);
  return file;
}
var DUO_GIRL_NODE = { left: "50", right: "51" };
async function generateDuoPhoto(playthroughId, character, friend, tier, photoPrompt, file, options = {}, overrides = {}) {
  validatePhotoOverrides(overrides, true);
  (0, import_shared7.assertSafeCharId)(character.charId);
  (0, import_shared7.assertSafeCharId)(friend.charId);
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  if (!isPhotoTier(tier)) {
    throw (0, import_shared7.appError)("PHOTO_TIER_UNKNOWN", `"${String(tier)}" is not a photo tier.`, tier);
  }
  if (!photoPrompt.trim()) {
    throw (0, import_shared7.appError)("PHOTO_PROMPT_MISSING", "There is nothing to take a picture of.");
  }
  if (options.signal?.aborted) throw (0, import_shared7.appError)("CANCELLED", "Generation was cancelled.");
  options.onProgress?.("Preparing");
  assertPhotoFile(file);
  const seed = overrides.seed ?? Math.floor(Math.random() * Number.MAX_SAFE_INTEGER);
  const built = overrides.prompts ? {
    scene: overrides.prompts.positive,
    negative: overrides.prompts.negative,
    left: overrides.prompts.left ?? "",
    right: overrides.prompts.right ?? ""
  } : buildDuoPhotoPrompt(
    await withBodySetting(character),
    await withBodySetting(friend),
    tier,
    photoPrompt
  );
  const prompts = {
    positive: built.scene,
    negative: built.negative,
    left: built.left,
    right: built.right
  };
  await renderPhotoImage(playthroughId, character.charId, file, {
    workflow: characterPhotoDuo_default,
    nodes: DUO_PHOTO_NODE,
    prompts: { positive: prompts.positive, negative: prompts.negative },
    texts: { [DUO_GIRL_NODE.left]: prompts.left, [DUO_GIRL_NODE.right]: prompts.right },
    seed
  }, { schemaVersion: 1, seed, tier, ...prompts }, options);
  reservedPhotoNames.get(getPhotosPath(playthroughId, character.charId))?.delete(file);
  return file;
}
async function renderPhotoImage(playthroughId, charId, file, request, sidecar, options) {
  const release = beginPhotoFile(playthroughId, charId, file);
  try {
    await movePhotoFiles(playthroughId);
    const signal = options.signal ?? new AbortController().signal;
    const check = () => {
      if (signal.aborted) throw (0, import_shared7.appError)("CANCELLED", "Generation was cancelled.");
    };
    const bytes = await (0, import_main3.renderComfyImage)(PHOTO_FEATURE_ID, request, {
      signal,
      onProgress: options.onProgress
    });
    check();
    const dest = getPhotoPath(playthroughId, charId, pngPhotoOf(file));
    await (0, import_promises3.mkdir)(getPhotosPath(playthroughId, charId), { recursive: true });
    check();
    let written = false;
    try {
      await (0, import_main3.writeAtomicBytes)(dest, bytes, {
        code: "PHOTO_WRITE_FAILED",
        message: "Could not save the photo."
      });
      written = true;
      check();
      await dropPhotoTwins(dest);
      check();
      await keepPhotoSidecar(playthroughId, charId, file, sidecar);
      check();
    } catch (error) {
      if (written && signal.aborted) {
        await (0, import_promises3.rm)(dest, { force: true });
        await (0, import_promises3.rm)(getPhotoPath(playthroughId, charId, photoSidecarOf(file)), { force: true });
      }
      check();
      throw error;
    }
  } finally {
    release();
  }
}
async function keepPhotoSidecar(playthroughId, charId, file, info) {
  try {
    await (0, import_main3.writeAtomicBytes)(
      getPhotoPath(playthroughId, charId, photoSidecarOf(file)),
      Buffer.from(JSON.stringify(info)),
      {
        code: "PHOTO_SIDECAR_WRITE_FAILED",
        message: "Could not save the photo prompt."
      }
    );
  } catch (error) {
    console.warn(`[photo] could not keep the prompt for ${file}:`, error);
  }
}
async function recordedPhotoInfo(playthroughId, charId, file) {
  return findPhotoSidecar(playthroughId, charId, photoSidecarOf(file));
}
async function photoInfo(playthroughId, character, friend, tier, scene, file, rebuild = false) {
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  (0, import_shared7.assertSafeCharId)(character.charId);
  if (friend) (0, import_shared7.assertSafeCharId)(friend.charId);
  assertPhotoFile(file);
  if (!isPhotoTier(tier))
    throw (0, import_shared7.appError)("PHOTO_TIER_UNKNOWN", `"${String(tier)}" is not a photo tier.`, tier);
  const saved = await recordedPhotoInfo(playthroughId, character.charId, file);
  if (saved && !rebuild) return { ...saved, recorded: true };
  const seed = saved?.seed;
  if (friend) {
    const prompts = buildDuoPhotoPrompt(
      await withBodySetting(character),
      await withBodySetting(friend),
      tier,
      scene
    );
    return {
      recorded: false,
      seed,
      tier,
      positive: prompts.scene,
      negative: prompts.negative,
      left: prompts.left,
      right: prompts.right
    };
  }
  const lora = (0, import_shared7.characterLoraOf)(character);
  return {
    recorded: false,
    seed,
    tier,
    ...buildPhotoPrompt(await withBodySetting(character), tier, scene),
    ...lora ? { lora } : {}
  };
}
async function dropPhoto(playthroughId, charId, file) {
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  (0, import_shared7.assertSafeCharId)(charId);
  assertPhotoFile(file);
  await photoMoveSettled(playthroughId);
  try {
    if ((await photoReferences(playthroughId)).all.has(pngPhotoOf(file))) return;
  } catch {
    return;
  }
  await removePhotoFiles(playthroughId, charId, file);
}
async function removePhotoFiles(playthroughId, charId, file) {
  const png = pngPhotoOf(file);
  for (const root of [getPhotosRoot(playthroughId), legacyPhotosRoot(playthroughId)]) {
    for (const name of [png, png.replace(/\.png$/, ".webp"), photoSidecarOf(file)]) {
      await (0, import_promises3.rm)((0, import_path3.join)(root, charId, name), { force: true });
    }
  }
}
var photoCleanups = /* @__PURE__ */ new Map();
async function flushRetiredPhotos(playthroughId) {
  const cleanup = photoCleanups.get(playthroughId);
  if (!cleanup) return;
  if (cleanup.running) return cleanup.running;
  const revision = cleanup.revision;
  cleanup.running = (async () => {
    try {
      const refs = await photoReferences(playthroughId);
      await afterOneMove(playthroughId, refs, async () => {
        for (const [key, photo] of cleanup.pending) {
          if (cleanup.revision !== revision) break;
          if (!refs.saved.has(pngPhotoOf(photo.newFile)) || refs.all.has(pngPhotoOf(photo.oldFile))) continue;
          if (!await photoLanded(playthroughId, photo.charId, photo.newFile)) continue;
          if (cleanup.revision !== revision) break;
          await removePhotoFiles(playthroughId, photo.charId, photo.oldFile);
          cleanup.pending.delete(key);
        }
      });
    } catch {
    }
    if (cleanup.pending.size === 0) {
      cleanup.watcher.close();
      clearTimeout(cleanup.timer);
      photoCleanups.delete(playthroughId);
    }
  })();
  try {
    await cleanup.running;
  } finally {
    cleanup.running = void 0;
    if (cleanup.pending.size > 0 && cleanup.revision !== revision) schedulePhotoCleanup(playthroughId);
  }
}
function schedulePhotoCleanup(playthroughId) {
  const cleanup = photoCleanups.get(playthroughId);
  if (!cleanup) return;
  clearTimeout(cleanup.timer);
  cleanup.timer = setTimeout(() => void flushRetiredPhotos(playthroughId), 100);
  cleanup.timer.unref();
}
function photoCheckpointChanged(file) {
  if (file === null) return true;
  const parts = file.replaceAll("\\", "/").split("/");
  if (parts.length === 1) return parts[0] === "replays" || parts[0].endsWith(".json");
  return parts.length === 2 && parts[0] === "replays" && parts[1].endsWith(".json");
}
async function retirePhoto(playthroughId, charId, oldFile, newFile) {
  (0, import_shared7.assertSafePlaythroughId)(playthroughId);
  (0, import_shared7.assertSafeCharId)(charId);
  assertPhotoFile(oldFile);
  assertPhotoFile(newFile);
  if (pngPhotoOf(oldFile) === pngPhotoOf(newFile)) return;
  let cleanup = photoCleanups.get(playthroughId);
  if (!cleanup) {
    try {
      const watcher = (0, import_fs2.watch)(
        photoPlaythroughPath(playthroughId),
        { recursive: true, persistent: false },
        (_event, file) => {
          if (!photoCheckpointChanged(file)) return;
          const current = photoCleanups.get(playthroughId);
          if (!current) return;
          current.revision += 1;
          schedulePhotoCleanup(playthroughId);
        }
      );
      watcher.on("error", () => {
        watcher.close();
        photoCleanups.delete(playthroughId);
      });
      cleanup = { watcher, pending: /* @__PURE__ */ new Map(), revision: 0 };
      photoCleanups.set(playthroughId, cleanup);
    } catch {
      return;
    }
  }
  cleanup.pending.set(`${charId}/${oldFile}`, { charId, oldFile, newFile });
  await flushRetiredPhotos(playthroughId);
}

// src/main/photoIpc.ts
var renders = /* @__PURE__ */ new Map();
function renderKey(playthroughId, charId, file) {
  return `${playthroughId}/${charId}/${file}`;
}
async function cancelPhoto(playthroughId, charId, file) {
  const render = renders.get(renderKey(playthroughId, charId, file));
  if (!render) return;
  render.controller.abort();
  await render.settled.catch(() => {
  });
}
function runPhoto(event, playthroughId, charId, file, run) {
  const key = renderKey(playthroughId, charId, file);
  const previous = renders.get(key);
  previous?.controller.abort();
  const controller = new AbortController();
  const abort = () => controller.abort();
  event.signal.addEventListener("abort", abort, { once: true });
  if (event.signal.aborted) controller.abort();
  const jobId = `photo:${key}`;
  const report = (status, step) => {
    try {
      for (const window of import_electron.BrowserWindow.getAllWindows()) {
        if (window.isDestroyed()) continue;
        window.webContents.send("jobs:progress", {
          jobId,
          group: charId,
          key: `photo:${playthroughId}:${file}`,
          status,
          step
        });
      }
    } catch (error) {
      console.warn("[photo] could not report render progress:", error);
    }
  };
  const render = { controller, settled: Promise.resolve("") };
  renders.set(key, render);
  render.settled = (async () => {
    try {
      await previous?.settled.catch(() => {
      });
      if (controller.signal.aborted) throw (0, import_shared9.appError)("CANCELLED", "Generation was cancelled.");
      const result = await run({
        signal: controller.signal,
        onProgress: (step) => report("running", step)
      });
      report("done", "Done");
      return result;
    } catch (error) {
      report("error", controller.signal.aborted ? "Cancelled" : "Failed");
      throw error;
    } finally {
      event.signal.removeEventListener("abort", abort);
      if (renders.get(key) === render) renders.delete(key);
    }
  })();
  return render.settled;
}
function photoInvocations() {
  const handlers = {};
  function handle(name, listener) {
    handlers[name] = (context, ...args) => listener(context, ...args);
  }
  registerPhotoBackup();
  registerPhotoDraft(import_shared8.registerImagePromptDraft);
  handle(
    "reserve-name",
    (_event, playthroughId, character, kind, inSave) => reservePhotoName(playthroughId, character, kind, inSave)
  );
  handle(
    "carry",
    (_event, fromPlaythroughId, toPlaythroughId, charIds) => carryPhotos(fromPlaythroughId, toPlaythroughId, charIds)
  );
  handle(
    "landed",
    (_event, playthroughId, charId, file) => photoLanded(playthroughId, charId, file)
  );
  handle(
    "read",
    (_event, playthroughId, charId, file) => readPhotoBytes(playthroughId, charId, file)
  );
  handle(
    "store-webp",
    (_event, playthroughId, charId, file, bytes) => storeWebpPhoto(playthroughId, charId, file, bytes)
  );
  handle(
    "info",
    (_event, playthroughId, character, friend, tier, scene, file, rebuild = false) => photoInfo(playthroughId, character, friend, tier, scene, file, rebuild)
  );
  handle(
    "drop",
    async (_event, playthroughId, charId, file, options) => {
      await cancelPhoto(playthroughId, charId, file);
      if (options?.cancelOnly) return;
      if (options?.replacement) return retirePhoto(playthroughId, charId, file, options.replacement);
      return dropPhoto(playthroughId, charId, file);
    }
  );
  handle(
    "generate",
    (event, playthroughId, character, tier, photoPrompt, file, overrides = {}) => {
      validatePhotoOverrides(overrides, false);
      return runPhoto(
        event,
        playthroughId,
        character.charId,
        file,
        (options) => generatePhoto(playthroughId, character, tier, photoPrompt, file, options, overrides)
      );
    }
  );
  handle(
    "generate-duo",
    (event, playthroughId, character, friend, tier, photoPrompt, file, overrides = {}) => {
      validatePhotoOverrides(overrides, true);
      return runPhoto(
        event,
        playthroughId,
        character.charId,
        file,
        (options) => generateDuoPhoto(
          playthroughId,
          character,
          friend,
          tier,
          photoPrompt,
          file,
          options,
          overrides
        )
      );
    }
  );
  return handlers;
}

// src/main/photoProtocol.ts
var import_shared10 = require("@vx/modkit/shared");
async function photoRoute(request) {
  const url = new URL(request.url);
  const [playthroughId, charId, file, ...rest] = decodeURIComponent(url.pathname).replace(/^\/@\/photos\//, "").split("/");
  if (rest.length > 0 || !import_shared10.SAFE_NUMERIC_ID.test(playthroughId ?? "") || !import_shared10.SAFE_CHAR_ID.test(charId ?? "") || !isPhotoFile(file ?? "")) {
    console.warn(`[photo-route] refused ${request.url}`);
    return new Response("Not found", { status: 404 });
  }
  try {
    const bytes = await readPhotoImage(playthroughId, charId, file);
    return new Response(bytes, {
      headers: { "Content-Type": (0, import_shared10.imageTypeOf)(bytes) ?? "application/octet-stream" }
    });
  } catch (err) {
    console.warn(`[photo-route] ${playthroughId}/${charId}/${file}: ${String(err)}`);
    return new Response("Not found", { status: 404 });
  }
}

// src/main/modEntries/photo-feature.ts
function photoMainEntry() {
  bindPhotoOptionReader((option) => (0, import_main4.modOptionOn)(PHOTO_FEATURE_ID, option));
  return { invoke: photoInvocations(), protocols: [{ route: "photos", handle: photoRoute }] };
}

// ../../../tmp/claude-0/-home-user/c131246f-1bb3-5571-b524-793842e9fc17/scratchpad/rel/photo-feature/_main.ts
var f = Object.values(photo_feature_exports).find((v) => typeof v === "function");
module.exports = f();
