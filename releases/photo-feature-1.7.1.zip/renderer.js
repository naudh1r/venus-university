// src/renderer/stores/photoInvoke.ts
import { invoke } from "@vx/modkit/renderer";

// src/shared/photoLoader.ts
var PHOTO_LOADERS = [
  { value: "bunny", label: "Bunny hop" },
  { value: "shimmer", label: "Dot shimmer" },
  { value: "dots", label: "Typing dots" }
];

// src/shared/photoDefinition.ts
var PHOTO_FEATURE_ID = "photo-feature";
var PHOTO_FEATURE_MOD = {
  id: PHOTO_FEATURE_ID,
  name: "Photo Feature",
  author: "naudh1r",
  scope: "anytime",
  defaultOn: false,
  blurb: "The girls send photos in their DMs and post them on their feeds, with comments from the rest of campus. Adds a gallery to each contact and optional body details for characters. Separate from the game's own Photos tab, where you make pictures yourself. Needs ComfyUI to draw the pictures, the game's own or yours.",
  offNote: "Off, nobody takes a new photo, posts get no new comments and body details are not used. Photos, galleries and comments already made are hidden. Nothing is deleted: everything comes back when it is on again.",
  options: [
    {
      id: "photos",
      label: "Photo generation",
      hint: "Off, no new photos are made, and characters don't know they can send one. Photos already sent stay visible.",
      default: true
    },
    {
      id: "explicit",
      label: "Explicit photos",
      hint: "Off, nobody sends an undressed photo, and ones already sent stay covered. Settings \u2192 No NSFW images turns them off too.",
      default: true
    },
    {
      id: "body",
      label: "Body details",
      hint: "Gives characters a build and body shape for their pictures. Set them from the main menu, in Manage Characters, under a character's Generation settings.",
      default: false
    },
    {
      id: "duo",
      label: "2 girls 1 photo (experimental)",
      hint: "A girl's feed post can be a photo of her and a friend, and a scene you are in with other girls can bring a photo of two of them, posted on one's feed. Always two girls, never more. Still being tuned: now and then a face, an outfit or a colour comes out wrong.",
      default: false
    },
    {
      id: "webp",
      label: "Save photos as WebP",
      hint: "New photos are saved as WebP, with no visible quality loss while taking much less space than PNG. Off, they are saved as PNG. Photos already saved stay as they are.",
      default: true
    },
    // One of these is on at a time: the store turns the others off.
    ...PHOTO_LOADERS.map((loader) => ({
      id: `loader-${loader.value}`,
      label: loader.label,
      hint: "",
      default: loader.value === "bunny",
      group: "loader"
    }))
  ],
  optionGroups: [
    {
      id: "loader",
      label: "Loading animation",
      hint: "The animation shown while a photo is being made."
    }
  ]
};

// src/shared/photoSwitches.ts
import { sharedModOn } from "@vx/modkit/shared";
var DEFAULT_PHOTO_SWITCHES = {
  on: true,
  photos: true,
  explicit: true,
  loader: "bunny",
  webp: true,
  body: false,
  duo: false
};
var readOption = null;
var snapshot = DEFAULT_PHOTO_SWITCHES;
function bindPhotoOptionReader(reader) {
  readOption = reader;
}
function photoSwitches() {
  const option = readOption;
  if (!option) return DEFAULT_PHOTO_SWITCHES;
  const next = {
    on: sharedModOn(PHOTO_FEATURE_ID),
    photos: option("photos"),
    explicit: option("explicit"),
    webp: option("webp"),
    body: option("body"),
    duo: option("duo"),
    loader: PHOTO_LOADERS.find((loader) => option(loaderOptionId(loader.value)))?.value ?? "bunny"
  };
  if (Object.keys(next).some((key) => next[key] !== snapshot[key])) snapshot = next;
  return snapshot;
}
function photoFeatureOn() {
  return readOption ? sharedModOn(PHOTO_FEATURE_ID) : DEFAULT_PHOTO_SWITCHES.on;
}
function photosVisible(switches = photoSwitches()) {
  return switches.on;
}
function photoGenerationOn(switches = photoSwitches()) {
  return switches.on && switches.photos;
}
function explicitPhotosAllowed(noNsfwImages3, switches = photoSwitches()) {
  return switches.explicit && !noNsfwImages3;
}
function duoPhotosOn(switches = photoSwitches()) {
  return photoGenerationOn(switches) && switches.duo;
}
function loaderOptionId(loader) {
  return `loader-${loader}`;
}

// src/renderer/stores/photoInvoke.ts
async function photoInvoke(name, args) {
  const result = await invoke(PHOTO_FEATURE_ID, name.replace(/[A-Z]/g, (letter) => "-" + letter.toLowerCase()), args);
  if (result.ok || result.error.code !== "DESKTOP_ONLY") return result;
  if (name === "carry") return { ok: true, data: void 0 };
  return { ok: false, error: {
    ...result.error,
    message: "The browser build cannot render pictures; the desktop build can."
  } };
}

// src/renderer/modEntries/photo-feature.ts
import { registerImagePromptDraft } from "@vx/modkit/shared";

// src/shared/characterBody.ts
function bodyOf(character4) {
  const stored = character4.ex?.[PHOTO_FEATURE_ID]?.data;
  return stored === void 0 ? character4.body : stored;
}
var BODY_FIELDS = ["build", "breasts", "hipsThighs", "buttocks", "pubicHair"];
var BUILD_TAGS = ["petite", "curvy", "toned", "muscular_female", "tall_female"];
var BUILD_WEIGHTS = {
  petite: 1.4,
  curvy: 1.1
};
function weightedBuild(build, scope) {
  const weight = build && (scope === "sprite" || scope === "nude") ? BUILD_WEIGHTS[build] : void 0;
  return weight ? `(${build}:${weight})` : build;
}
var BREAST_TAGS = ["flat_chest", "small_breasts", "medium_breasts", "large_breasts"];
var HIPS_TAGS = ["wide_hips", "thick_thighs", "narrow_waist", "long_legs", "thigh_gap"];
var SMALL_ASS = "(flat_ass:0.6)";
var FULL_ASS = "(huge_ass:0.6)";
var BUTTOCKS_TAGS = ["flat_ass", "(flat_ass:0.6)", "(huge_ass:0.6)", "huge_ass"];
var PUBIC_TAGS = ["female_pubic_hair", "sparse_pubic_hair", "excessive_pubic_hair"];
var BODY_POOLS = {
  build: BUILD_TAGS,
  breasts: BREAST_TAGS,
  hipsThighs: HIPS_TAGS,
  buttocks: BUTTOCKS_TAGS,
  pubicHair: PUBIC_TAGS
};
var CONFLICTS = [
  {
    field: "build",
    tag: "petite",
    rules: {
      hipsThighs: ["wide_hips", "thick_thighs", "long_legs"],
      buttocks: [FULL_ASS, "huge_ass"]
    }
  },
  {
    field: "build",
    tag: "curvy",
    // `curvy` is a full chest as much as full hips: anything under medium contradicts it.
    rules: { breasts: ["flat_chest", "small_breasts"], buttocks: ["flat_ass", SMALL_ASS] }
  },
  { field: "hipsThighs", tag: "wide_hips", rules: { buttocks: ["flat_ass", SMALL_ASS] } },
  { field: "hipsThighs", tag: "thick_thighs", rules: { buttocks: ["flat_ass", SMALL_ASS] } }
];
function allowedBeside(body, field, tag) {
  if (!BODY_POOLS[field].includes(tag)) return false;
  return !CONFLICTS.some(
    (conflict) => conflict.field !== field && body[conflict.field] === conflict.tag && (conflict.rules[field] ?? []).includes(tag)
  );
}
function pooled(field, written) {
  const tags = Array.isArray(written) ? written : typeof written === "string" ? written.split(",") : [];
  return tags.map((tag) => typeof tag === "string" ? tag.trim() : "").find((tag) => BODY_POOLS[field].includes(tag));
}
var LEGACY_FIELD = {
  build: "bodyType",
  breasts: "bust",
  hipsThighs: "hipsThighs",
  buttocks: "buttocks",
  pubicHair: "pubicHair"
};
function cleanBody(raw) {
  if (!raw || typeof raw !== "object") return void 0;
  const record = raw;
  const body = {};
  for (const field of BODY_FIELDS) {
    const tag = pooled(field, record[field] ?? record[LEGACY_FIELD[field]]);
    if (tag && allowedBeside(body, field, tag)) body[field] = tag;
  }
  return BODY_FIELDS.some((field) => body[field]) ? body : void 0;
}
var APPEARANCE_BREASTS = {
  small_breasts: "small_breasts",
  // `big_breasts` is only an alias of `large_breasts` on Danbooru, with no posts of its own.
  big_breasts: "large_breasts",
  medium_breasts: "medium_breasts",
  large_breasts: "large_breasts",
  flat_chest: "flat_chest"
};
var ANY_BREAST_TAG = /^(flat_chest|[a-z]+_breasts)$/;
function appearanceBreasts(baseAppearance) {
  for (const tag of baseAppearance) {
    const mapped = APPEARANCE_BREASTS[tag];
    if (mapped) return mapped;
  }
  return "medium_breasts";
}
var DRAW_WEIGHTS = {
  hipsThighs: {
    "": 3,
    wide_hips: 1,
    thick_thighs: 1,
    narrow_waist: 1,
    long_legs: 1,
    thigh_gap: 1
  },
  // The in-between sizes more often than the ends.
  buttocks: { "": 4, [SMALL_ASS]: 2, [FULL_ASS]: 2, flat_ass: 1, huge_ass: 1 },
  pubicHair: { "": 3, female_pubic_hair: 3, sparse_pubic_hair: 1, excessive_pubic_hair: 1 }
};
function draw(weights, allowed, rand) {
  const options = Object.entries(weights).filter(([tag]) => tag === "" || allowed(tag));
  const total = options.reduce((sum, [, weight]) => sum + weight, 0);
  let at = rand() * total;
  for (const [tag, weight] of options) {
    at -= weight;
    if (at < 0) return tag;
  }
  return "";
}
function drawBody(build, baseAppearance, rand = Math.random, chosenBreasts) {
  const body = {};
  if (build && allowedBeside(body, "build", build)) body.build = build;
  const breasts = [chosenBreasts, appearanceBreasts(baseAppearance), "medium_breasts"].find(
    (tag) => tag !== void 0 && allowedBeside(body, "breasts", tag)
  );
  if (breasts) body.breasts = breasts;
  for (const field of ["hipsThighs", "buttocks", "pubicHair"]) {
    const tag = draw(DRAW_WEIGHTS[field] ?? {}, (one) => allowedBeside(body, field, one), rand);
    if (tag) body[field] = tag;
  }
  return body;
}
var WEIGHTED_LABELS = {
  [SMALL_ASS]: "small ass",
  [FULL_ASS]: "full ass"
};
function bodyTagLabel(tag) {
  return WEIGHTED_LABELS[tag] ?? tag.replace(/_/g, " ");
}
function gateBody(character4, on) {
  const { body: _legacy, ...rest } = character4;
  const ex = { ...character4.ex };
  if (on) {
    ex[PHOTO_FEATURE_ID] = {
      v: character4.ex?.[PHOTO_FEATURE_ID]?.v ?? "0.0.0",
      data: cleanBody(bodyOf(character4)) ?? {}
    };
  } else delete ex[PHOTO_FEATURE_ID];
  return { ...rest, ex };
}
function bodyAppearance(character4, scope) {
  const body = bodyOf(character4);
  if (!body) return [...character4.baseAppearance];
  const kept = character4.baseAppearance.filter((tag) => !ANY_BREAST_TAG.test(tag) && !BODY_ONLY_TAGS.has(tag));
  const breasts = body.breasts ?? appearanceBreasts(character4.baseAppearance);
  const tags = [breasts, weightedBuild(body.build, scope)];
  if (scope !== "photo") tags.push(body.hipsThighs);
  if (scope === "cg") tags.push(body.buttocks);
  if (scope === "nude" || scope === "cg") tags.push(body.pubicHair);
  return [...kept, ...tags.filter((tag) => Boolean(tag))];
}
var PETITE_NEGATIVE_TAGS = ["loli", "child", "aged_down"];
function bodyNegative(character4) {
  return bodyOf(character4)?.build === "petite" ? [...PETITE_NEGATIVE_TAGS] : [];
}
var BODY_ONLY_TAGS = /* @__PURE__ */ new Set([
  ...BUILD_TAGS,
  ...BUILD_TAGS.map((tag) => weightedBuild(tag, "sprite")),
  ...HIPS_TAGS,
  ...BUTTOCKS_TAGS,
  ...PUBIC_TAGS
]);
function withBodyTags(kept, draft, on) {
  if (kept === draft || kept.kind === "expression" || draft.kind === "expression") return kept;
  const owned = (tag) => BODY_ONLY_TAGS.has(tag) || on && ANY_BREAST_TAG.test(tag);
  const appearance = [
    ...kept.appearance.filter((tag) => !owned(tag)),
    ...draft.appearance.filter(owned)
  ];
  const petite = new Set(PETITE_NEGATIVE_TAGS);
  const negative = [
    ...kept.negative.filter((tag) => !petite.has(tag)),
    ...draft.negative.filter((tag) => petite.has(tag))
  ];
  return { ...kept, appearance, negative };
}

// src/shared/photoDraft.ts
function registerPhotoDraft(register) {
  register(PHOTO_FEATURE_ID, {
    draft: (parts, { character: character4, kind }) => {
      const her = gateBody({ ...character4, baseAppearance: parts.appearance }, photoSwitches().body);
      return { appearance: bodyAppearance(her, kind), negative: [...parts.negative, ...bodyNegative(her)] };
    },
    regen: (kept, draft, on) => withBodyTags(kept, draft, on && photoSwitches().body)
  });
}

// src/shared/postAudience.ts
import { hasTrait } from "@vx/modkit/shared";
var REACH_FLOOR = 40;
var REACH_SPAN = 460;
function hashUnit(seed) {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0) % 1e5 / 1e5;
}
function reachOf(playthroughId, charId, character4) {
  const roll = hashUnit(`${playthroughId ?? "unsaved"}:${charId}`);
  const reach = REACH_FLOOR + Math.round(REACH_SPAN * roll * roll);
  return hasTrait(character4, "Terminally Online") ? reach * 2 : reach;
}
var ENGAGEMENT = {
  none: 0.02,
  everyday: 0.045,
  suggestive: 0.11,
  explicit: 0.11
};
function rollAudienceLikes(input, rand = Math.random) {
  const share = ENGAGEMENT[input.photoTier] * (0.6 + rand() * 0.8);
  return input.friends + Math.round(input.reach * share);
}
var MAX_COMMENTS = 8;
function rollCrowdCount(input, rand = Math.random) {
  const { photoTier, reach } = input;
  const talkers = reach / 100 * (photoTier === "none" ? 0.35 : photoTier === "suggestive" ? 2.2 : 0.9);
  const drawn = Math.floor(rand() * (talkers + 1) + rand() * talkers * 0.6);
  return Math.min(drawn, MAX_COMMENTS);
}

// src/shared/photoTypes.ts
function normalizePhoto(stored, legacy) {
  const raw = stored !== void 0 ? stored : legacy.photo;
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const value = raw;
  if (typeof value.tier !== "string") return null;
  const photo = { tier: value.tier };
  for (const key of ["scene", "file", "with"]) {
    if (typeof value[key] === "string") photo[key] = value[key];
  }
  for (const key of ["held", "pending", "failed"]) {
    if (value[key] === true) photo[key] = true;
  }
  if (typeof value.outAt === "number" && Number.isFinite(value.outAt)) photo.outAt = value.outAt;
  return photo;
}
function savedPhoto(record) {
  return normalizePhoto(record.ex?.[PHOTO_FEATURE_ID]?.data, record);
}

// src/shared/heldPosts.ts
function postIsOut(post) {
  return savedPhoto(post)?.held !== true || !photoFeatureOn();
}

// src/renderer/stores/photoRecords.ts
import { recordField } from "@vx/modkit/renderer";
var spec = { empty: null, legacy: ["photo"], normalize: normalizePhoto };
var messagePhoto = recordField(PHOTO_FEATURE_ID, spec);
var postPhoto = recordField(PHOTO_FEATURE_ID, spec);

// src/shared/photoWords.ts
var WORD_CHAR = "[a-z0-9]";
var compiled = /* @__PURE__ */ new Map();
function patternOf(cue) {
  const cached = compiled.get(cue);
  if (cached) return cached;
  const stem = cue.endsWith("*");
  const body = (stem ? cue.slice(0, -1) : cue).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const tail = stem ? `${WORD_CHAR}*` : "(?:s|es)?";
  const pattern = new RegExp(`(?<!${WORD_CHAR})${body}${tail}(?!${WORD_CHAR})`);
  compiled.set(cue, pattern);
  return pattern;
}
function says(text, cue) {
  return patternOf(cue).test(text);
}
function saysAny(text, cues) {
  return cues.some((cue) => says(text, cue));
}

// src/shared/photoGate.ts
import { dispositionOf, hasTrait as hasTrait2 } from "@vx/modkit/shared";
var PHOTO_TIERS = ["none", "everyday", "suggestive", "explicit"];
function isPhotoTier(value) {
  return PHOTO_TIERS.includes(value);
}
function rankOf(tier) {
  return PHOTO_TIERS.indexOf(tier);
}
function allowedPhotoTier(input) {
  const { flags, affection, traits, noNsfwImages: noNsfwImages3, canRender } = input;
  if (!canRender) return "none";
  if (!flags?.gaveContactInfo || flags.blocked) return "none";
  const feeling = dispositionOf(affection);
  if (feeling === "hostile" || feeling === "annoyed") return "none";
  if (hasTrait2(traits ? { traits } : void 0, "Promiscuous")) {
    return noNsfwImages3 ? "suggestive" : "explicit";
  }
  if (photoReasonOf(flags, traits) !== null && !noNsfwImages3) return "explicit";
  if (flags.hasKissed || flags.hasCrush || flags.benefits || flags.isLover) return "suggestive";
  return "everyday";
}
function photoReasonOf(flags, traits) {
  if (flags?.hadSex || flags?.benefits || flags?.isLover) return "intimate";
  if (hasTrait2(traits ? { traits } : void 0, "Promiscuous")) return "promiscuous";
  if (flags?.hasCrush) return "crush";
  return null;
}
function allowedPostTier(noNsfwImages3) {
  return noNsfwImages3 ? "everyday" : "suggestive";
}
var EXPLICIT_WORDS = [
  "nude",
  "naked",
  "topless",
  "bottomless",
  "undressed",
  // The same phrases `photoBody` strips her on, so the two cannot disagree about what bare is:
  // a caption the builder would draw undressed must read as undressed here first.
  "nothing on",
  "wearing nothing",
  "no clothes",
  "without clothes",
  "fully exposed",
  "nipple",
  "breasts out",
  "bare breasts",
  "pussy",
  "vagina",
  "genital*",
  "masturbat*",
  "spread legs",
  "cum",
  "cumming",
  "sex",
  // Her own, and hers alone: explicit, so only a girl the gate lets undress sends it. Anything
  // with somebody else in it is refused whatever it is, by the list below.
  "anal",
  "anus",
  "asshole",
  "butthole",
  "butt plug",
  "buttplug",
  "anal beads",
  // Ways of saying it that carry no word from the list above. She wrote "bare-chested and
  // wearing only black lace panties" and it read as suggestive, because every word naming what
  // was bare was one nobody had thought of.
  "bare-chested",
  "bare chested",
  "bare chest",
  "bare torso",
  "bare front",
  "bare from the waist up",
  "chest bare",
  "breasts bare",
  "exposed breasts",
  "exposed chest",
  "uncovered breasts",
  "shirtless",
  "braless",
  "no bra",
  "without a bra",
  "nothing covering",
  // "wearing only <one thing>" says what is not there without naming it.
  "wearing only",
  "wearing nothing but",
  "dressed in only",
  "in only her",
  "clad only in"
];
var SUGGESTIVE_WORDS = [
  "underwear",
  "lingerie",
  "bra",
  "panties",
  "bikini",
  "swimsuit",
  "swimwear",
  "towel",
  "lace",
  "cleavage",
  "thigh",
  "bare shoulder",
  "tease",
  "teasing",
  "seductive",
  "suggestive",
  "in bed",
  "bedroom eyes",
  "shower",
  "bath",
  "changing room",
  "skimpy",
  "revealing"
];
function describedPhotoTier(photoPrompt) {
  const text = photoPrompt.toLowerCase();
  if (!text.trim()) return "none";
  if (saysAny(text, EXPLICIT_WORDS)) return "explicit";
  if (saysAny(text, SUGGESTIVE_WORDS)) return "suggestive";
  return "everyday";
}
var NOT_SOLO_WORDS = [
  // Another body in it.
  "his hand",
  "his fingers",
  "his mouth",
  "his tongue",
  "his lap",
  "his chest",
  "his arms",
  "on top of him",
  "riding him",
  "straddling him",
  "with him",
  "boyfriend",
  "another girl",
  "other girl",
  "two girls",
  "threesome",
  "couple",
  // Acts that take two.
  "blowjob",
  "fellatio",
  "handjob",
  "titjob",
  "paizuri",
  "deepthroat*",
  "intercourse",
  "creampie",
  "fucking him",
  "fucked by",
  "sucking him",
  "kissing him"
];
var PARTNER_BODY_WORDS = ["penis", "cock", "dick"];
var TOY_WORDS = ["dildo", "vibrator", "toy", "magic wand"];
function describesSomebodyElse(photoPrompt) {
  const text = photoPrompt.toLowerCase();
  if (saysAny(text, NOT_SOLO_WORDS)) return true;
  return saysAny(text, PARTNER_BODY_WORDS) && !saysAny(text, TOY_WORDS);
}
function settlePhoto(input) {
  const { sendPhoto: sendPhoto2, photoPrompt, allowed, stated } = input;
  if (!sendPhoto2 || !photoPrompt.trim()) return { send: false, tier: "none" };
  if (allowed === "none") return { send: false, tier: "none", note: "she sends him nothing" };
  if (describesSomebodyElse(photoPrompt)) {
    return { send: false, tier: "none", note: "the picture is not of her alone" };
  }
  const described = describedPhotoTier(photoPrompt);
  const tier = stated && rankOf(stated) > rankOf(described) ? stated : described;
  if (rankOf(tier) > rankOf(allowed)) {
    return {
      send: false,
      tier: "none",
      note: `read as ${tier} (described ${described}, said ${stated ?? "nothing"}), allowed ${allowed}`
    };
  }
  return { send: true, tier };
}

// src/renderer/prompts/photoBrief.ts
import { affectionFor } from "@vx/modkit/shared";

// src/shared/photoWardrobe.ts
import {
  customOutfitSlotsIn,
  outfitTagsFor
} from "@vx/modkit/shared";
var MAIN_NAMES = [
  ...["everyday", "usual"].flatMap(
    (kind) => ["clothes", "cloth", "outfit"].map((garment) => `${kind} ${garment}`)
  ),
  ...["her", "their"].flatMap(
    (who) => ["clothes", "cloth", "outfit"].flatMap((garment) => [
      `${who} ${garment}`,
      `${who} own ${garment}`
    ])
  )
];
var GARMENT_NOUNS = [
  "skirt",
  "shirt",
  "blouse",
  "sweater",
  "cardigan",
  "hoodie",
  "top",
  "dress",
  "coat",
  "jacket",
  "raincoat",
  "shorts",
  "pants",
  "trousers",
  "jeans",
  "bra",
  "panties",
  "bikini",
  "swimsuit",
  "uniform",
  "camisole",
  "leggings",
  "robe"
];
var GARMENT_BREAK = [
  "and",
  "with",
  "beside",
  "near",
  "on",
  "under",
  "over",
  "above",
  "below",
  "next",
  "wearing",
  "dressed",
  ...GARMENT_NOUNS
].join("|");
function spoken(tags) {
  return tags.map((tag) => tag.replace(/_/g, " ")).join(", ");
}
function wardrobeLine(character4) {
  const sets = [
    `everyday \u2014 ${spoken(character4.outfit)}`,
    `PE kit \u2014 ${spoken(character4.peOutfit)}`,
    `swimsuit \u2014 ${spoken(character4.swimOutfit)}`,
    ...customOutfitSlotsIn(Object.keys(character4.customOutfits ?? {})).flatMap((slot) => {
      const set = character4.customOutfits?.[slot];
      const name = set?.name?.trim();
      return name && set && set.tags.length > 0 ? [`"${name}" \u2014 ${spoken(set.tags)}`] : [];
    })
  ];
  return `${character4.firstName}'s clothes: ${sets.join("; ")}. If the picture has her in one of these, say which \u2014 "her everyday clothes", "her PE kit", "her swimsuit"${sets.length > 3 ? ", or the name of the set" : ""} \u2014 rather than describing it. For something else, or a picture from another day, say what she is wearing and its colour in a few words, as she would dress for it, in her own style: not an oversized knit sweater, cardigan or hoodie unless one is hers.`;
}

// src/renderer/prompts/photoBrief.ts
function withoutDorm(scene) {
  return scene.replace(/\bdorm(itory)?\s+(room|bed)\b/gi, "$2").replace(/\bdorm(itory)?\b/gi, "room");
}
function photoStub(message, flatText, nameOf = () => void 0) {
  const scene = messagePhoto.read(message)?.scene?.trim();
  if (!scene) return "";
  const friend = messagePhoto.read(message)?.with ? nameOf(messagePhoto.read(message).with) : void 0;
  return ` [attached a photo${friend ? ` with ${friend}` : ""}: ${flatText(withoutDorm(scene))}]`;
}
function photoLines(character4, info, state, occasion = "reply") {
  const tier = allowedPhotoTier({
    flags: info?.flags,
    affection: affectionFor(info, state.date, character4),
    traits: character4.traits,
    noNsfwImages: state.noNsfwImages === true,
    canRender: state.canRenderImages === true
  });
  if (tier === "none") {
    return [];
  }
  return tier === "explicit" ? intimateBrief(character4, photoReasonOf(info?.flags, character4.traits) ?? "crush", occasion) : normalBrief(character4, tier, occasion);
}
function normalBrief(character4, tier, occasion) {
  const name = character4.firstName;
  return [
    ...opening(name, occasion),
    tier === "suggestive" ? `${name} will send a flirty one \u2014 what she is wearing, a swimsuit, underwear \u2014 but nothing more than that. Nothing undressed.` : `${name} only sends ordinary pictures: where she is, what she is eating, her outfit, something that made her laugh. Nothing flirty, nothing undressed.`,
    ...captioning(character4, occasion),
    ...keeping(name, occasion)
  ];
}
function intimateBrief(character4, reason, occasion) {
  const name = character4.firstName;
  return [
    ...opening(name, occasion),
    `${name} will send anything of herself, undressed included. ${INTIMATE_REASON[reason]}`,
    ...captioning(character4, occasion),
    // The gate has already allowed this; a caption that will not say it renders a picture that
    // does not show it, and the tease is read as the whole of what she sent.
    `So a picture of ${name} undressed is captioned as one, in plain words: what is bare, what she is doing, what the shot shows. Coy wording is a coy picture \u2014 "the top of a shirt" is a photograph of a shirt.`,
    `Write it as she would, not as a catalogue: she is sending this to ${reason === "intimate" ? "somebody she has slept with" : "somebody she's into"}, and she knows what she is doing.`,
    ...keeping(name, occasion)
  ];
}
var INTIMATE_REASON = {
  intimate: "She has already been that far with him, so nothing is being asked for the first time.",
  promiscuous: "This is nothing new for her: she sends pictures like this to people she's into, and he has her number.",
  crush: "She's into him, but they haven't been together. Sending one is her own decision, and not a small one: she does it when she wants to, never because he pushed."
};
function opening(name, occasion) {
  return [
    "PHOTOS",
    occasion === "reply" ? `${name} can attach one picture to this reply. Set "sendPhoto" and describe it in "photoPrompt".` : `${name} can attach one picture to these texts. Set "sendPhoto" in her entry and describe it in "photoPrompt".`
  ];
}
function captioning(character4, occasion) {
  const name = character4.firstName;
  return [
    occasion === "reply" ? 'A picture is worth sending when the conversation is already about one \u2014 she offers it, or he asked and she wants to. Most replies are just words: set "sendPhoto" false and leave "photoPrompt" empty.' : 'A picture is worth sending when it is part of what she is texting about, and she would rather show him than tell him. Most texts like these are just words: set "sendPhoto" false and leave "photoPrompt" empty.',
    `Write "photoPrompt" as what the picture shows, the way ${name} would caption it to herself. One sentence, and a full one: start with where she is, then what she is doing, what she is wearing, how she is sitting or lying or standing, what her hands are doing, where she is looking, how close the shot is \u2014 her face, from the waist up, from the knees up, or head to toe \u2014 and the angle if it isn't straight on: from above, from below, from the side, or from behind \u2014 from behind only if somebody else took it, or in a mirror.`,
    // A friend behind the camera is listed first.
    "It can be one a friend took of her, or one from earlier \u2014 today, a weekend, a trip, a night out. A selfie is for showing him right now.",
    "A mirror selfie only where there would be a mirror: her room, a bathroom, a changing room.",
    'What is not written is not drawn. A caption that says only "a photo of me" gets a picture of nobody in particular.',
    wardrobeLine(character4),
    'Then set "photoTier" to what that picture is, which is a separate question from whether she would send it: "everyday" for one with nothing on show, "suggestive" for underwear, swimwear or a towel, "explicit" for one where any part of her usually covered is not. Judge the picture you described, not the words you described it in \u2014 a caption that never says a word for it can still be a picture of one. "none" where there is no picture.'
  ];
}
function keeping(name, occasion) {
  return [
    // Not every picture is a selfie: somebody else may have taken it, or a timer, so the phone is
    // in it only where it would be.
    "Describe the picture itself: how she looks in it, not how it was taken or sent. A phone only appears in it when it's a mirror selfie.",
    // The renderer draws one girl and nobody else, and the gate refuses a caption that says otherwise.
    `${name} is the only person in the picture. Whoever took it stays behind the camera: nobody else is in it, touching her, or doing anything with her.`,
    'Name nobody and nowhere: not herself, not the reader, not a building or a place on the map. A picture cannot show a name. "her room", "a lecture hall", "the cafe" \u2014 what it looks like, never what it is called. Her own room is "her room" or "her bedroom", never a dorm.',
    "Her texts should read like somebody who just sent that picture. Do not describe it in them.",
    // The slot's opening sums her thread up rather than quoting it, so only a reply is told where
    // her pictures are written.
    occasion === "reply" ? "Any picture she has already sent is written into RECENT MESSAGES beside the text it came with. She knows what she sent him and would not send the same one twice, or the same kind of shot every time." : "She knows what she has already sent him and would not send the same picture twice, or the same kind of shot every time.",
    ""
  ];
}
var PHOTO_SCHEMA_REQUIRED = ["sendPhoto", "photoPrompt", "photoTier"];
var PHOTO_SCHEMA_FIELDS = {
  sendPhoto: { type: "boolean" },
  photoPrompt: { type: "string" },
  // What she says the picture is. Required and answered "none" where there is no picture, since
  // an optional field is one a model leaves out.
  photoTier: { type: "string", enum: [...PHOTO_TIERS] }
};
function postPhotoLines(canRenderImages2) {
  if (!canRenderImages2) return ['Leave "image" empty on every post: nobody posts a picture today.'];
  return [
    'A post may carry a picture of her. Describe it in "image" \u2014 what the photograph shows, the way she would caption it to herself. One sentence, and a full one: start with where she is, then what she is doing, what she is wearing, how she is standing or sitting, how close the shot is \u2014 her face, from the waist up, from the knees up, or head to toe \u2014 and the angle if it isn\u2019t straight on: from above, from below, from the side, or from behind \u2014 from behind only if somebody else took it, or in a mirror. Leave "image" empty on a post that is just words, which most of them are.',
    "What she owns is listed under her name above.",
    "It can be one a friend took of her, a candid one where she is not posing, or one from earlier \u2014 today, a weekend, a trip, a night out. A selfie is for showing her year right now.",
    "A mirror selfie only where there would be a mirror: her room, a bathroom, a changing room.",
    'What is not written is not drawn: "a photo of me" gets a picture of nobody in particular.',
    "Her whole year sees this, so it is an ordinary picture or a flirty one at most \u2014 what she is wearing, a day out, a swimsuit. Never anything undressed, whatever she might send one person in a message.",
    'Name nobody and nowhere: a picture cannot show a name. "her room", "the quad", "a cafe" \u2014 what it looks like, never what it is called.',
    "She is the only person in the picture, unless her entry says it is a picture with a friend.",
    'The post\u2019s own "text" should read like somebody who just posted that picture, without describing it.'
  ];
}
function posterPhotoLines(character4, canRenderImages2) {
  return canRenderImages2 ? [`  ${wardrobeLine(character4)}`] : [];
}
function postCommentLines(on = photoFeatureOn()) {
  if (!on) return ['Leave "comments" empty on every post.'];
  return [
    'Each post also carries "comments": what other students replied underneath it, in their own voices \u2014 up to five, and an empty array on the posts nobody answers, which is most of them. A post with a picture draws more than one without.',
    "They are strangers from the four thousand this campus holds, not the characters above: they do not know her, they are not the reader, and none of them may be named. No handles and no @s \u2014 just what each one said.",
    "They answer the post they are under. A reply to a picture is a reply to that picture; one under a picture with skin in it reads like a public feed at its least charming, which is strangers being obvious at somebody who did not ask."
  ];
}
var POST_PHOTO_SCHEMA_FIELD = {
  image: { type: "string" },
  comments: { type: "array", items: { type: "string" } }
};
var POST_PHOTO_SCHEMA_REQUIRED = ["image", "comments"];

// src/renderer/prompts/bodyBrief.ts
function bodyDetailsOn() {
  return photoFeatureOn() && photoSwitches().body;
}
function bodyBriefLines(on = bodyDetailsOn()) {
  if (!on) return [];
  return [
    "BODY",
    `build (pick 0-1, omit for an average build): ${BODY_POOLS.build.join(", ")}`,
    "Pick it from who she is and how she lives, not from her outfit.",
    ""
  ];
}
function bodySchemaRequired(on = bodyDetailsOn()) {
  return on ? ["body"] : [];
}
function bodySchemaFields(on = bodyDetailsOn()) {
  if (!on) return {};
  return {
    body: {
      type: "object",
      additionalProperties: false,
      required: ["build"],
      properties: {
        // An array because the pick is 0–1 and the strict subset has no optional key.
        build: { type: "array", items: { type: "string", enum: [...BODY_POOLS.build] } }
      }
    }
  };
}
function bodyOfDraft(draft, baseAppearance, rand) {
  if (!draft) return void 0;
  return drawBody(draft.build?.[0], baseAppearance, rand);
}

// src/renderer/stores/localPhotoStore.ts
import {
  canRenderLocalImages,
  noNsfwImages,
  conversation,
  feed,
  currentRun,
  saveChanges
} from "@vx/modkit/renderer";
function canRenderImages() {
  return canRenderLocalImages();
}
function canSendPhotos() {
  return photoGenerationOn() && canRenderImages();
}
function noExplicitPhotos() {
  return !explicitPhotosAllowed(noNsfwImages());
}
function setMessagePhoto(charId, messageId, photo, options = { run: currentRun() }) {
  return messagePhoto.set({ kind: "message", charId, messageId }, photo, options);
}
function photoNamesInSave(charId) {
  return [
    ...(conversation(charId)?.messages ?? []).map((item) => messagePhoto.read(item)),
    ...feed(charId).map((item) => postPhoto.read(item))
  ].flatMap((photo) => photo?.file ? [photo.file] : []);
}
function setFeedPostPhoto(charId, postId, photo, options = { run: currentRun() }) {
  return postPhoto.set({ kind: "post", charId, postId }, photo, options);
}
function savePhotoState() {
  void savePhotoStateAwaitable();
}
async function savePhotoStateAwaitable(run = currentRun()) {
  await saveChanges(PHOTO_FEATURE_ID, { run });
}

// src/renderer/stores/photoComments.ts
import { rollPostLikes, npcFriendsOf, globalSlotOf } from "@vx/modkit/shared";

// src/renderer/stores/photoGame.ts
import {
  character,
  characterInfo,
  conversation as conversation2,
  rosterIds,
  npcRelationships,
  clock,
  gameFacts,
  currentRun as currentRun2
} from "@vx/modkit/renderer";
import { charKeyOf } from "@vx/modkit/shared";
function photoGame() {
  const ids = rosterIds({ alumni: true });
  const characters = {};
  const charInfo = {};
  const conversations = {};
  const charKeyToId = {};
  for (const id of ids) {
    const girl = character(id);
    const info = characterInfo(id);
    const thread = conversation2(id);
    if (girl) {
      characters[id] = girl;
      charKeyToId[charKeyOf(girl.firstName, girl.lastName)] = id;
    }
    if (info) charInfo[id] = info;
    if (thread) conversations[id] = thread;
  }
  return {
    ...gameFacts(),
    date: clock()?.date ?? 0,
    time: clock()?.time ?? 0,
    characters,
    charInfo,
    bunnyboard: { conversations },
    charKeyToId,
    chars: [...rosterIds()],
    npcRelationships: npcRelationships() ?? {},
    run: currentRun2()
  };
}

// src/renderer/stores/photoComments.ts
import { drawFeedEmoji, drawFeedHandles, FEED_EMOJI, FEED_HANDLE_POOL } from "@vx/modkit/renderer";
function rollComments(charId, written, photoTier = "none") {
  const lines = (written ?? []).map((text) => text.trim()).filter(Boolean);
  if (lines.length === 0 || !photoFeatureOn()) return [];
  const game = photoGame();
  const reach = reachOf(game.playthroughId, charId, game.characters[charId]);
  const count = Math.min(lines.length, rollCrowdCount({ photoTier, reach }));
  if (count === 0) return [];
  const kept = lines.slice(0, count);
  const handles = drawFeedHandles(kept.length);
  const emoji = drawFeedEmoji(kept.length);
  const posted = globalSlotOf(game.date, game.time);
  return kept.map((text, i) => ({
    id: crypto.randomUUID(),
    handle: handles[i] ?? FEED_HANDLE_POOL[0].handle,
    emoji: emoji[i] ?? FEED_EMOJI[0],
    text,
    at: posted + Math.min(2, Math.floor(i / 3))
  }));
}
function postLikes(charId, photoTier = "none") {
  const game = photoGame();
  if (!photoFeatureOn()) {
    return rollPostLikes(npcFriendsOf(game.npcRelationships, charId, game.chars).length);
  }
  return rollAudienceLikes({
    reach: reachOf(game.playthroughId, charId, game.characters[charId]),
    friends: npcFriendsOf(game.npcRelationships, charId, game.chars).length,
    photoTier
  });
}
function strangerLikes(handle) {
  if (!photoFeatureOn()) return rollPostLikes(0);
  const game = photoGame();
  return rollAudienceLikes({
    reach: reachOf(game.playthroughId, handle, void 0),
    friends: 0,
    photoTier: "none"
  });
}

// src/renderer/stores/photoRedraw.ts
import { useSyncExternalStore } from "react";

// src/shared/photoFiles.ts
var WEBP_QUALITY = 0.85;
var PHOTO_FILE = /^[a-z0-9]+_(?:bunnyboard|chat)_\d{3,6}\.(?:png|webp)$/;
var LEGACY_PHOTO_FILE = /^photo_\d{1,20}_[a-f0-9]{8}\.png$/;
function isPhotoFile(file) {
  return PHOTO_FILE.test(file) || LEGACY_PHOTO_FILE.test(file);
}
function isWebpPhoto(file) {
  return isPhotoFile(file) && file.endsWith(".webp");
}
function photoUrl(playthroughId, charId, file) {
  return `vxmod://photo-feature/@/photos/${playthroughId}/${charId}/${file}`;
}

// src/renderer/stores/photoWebp.ts
async function renderPhoto(playthroughId, character4, tier, scene, file, friend, options) {
  const result = friend ? await photoInvoke("generateDuo", [playthroughId, character4, friend, tier, scene, file, options]) : await photoInvoke("generate", [playthroughId, character4, tier, scene, file, options]);
  if (result.ok && isWebpPhoto(file)) await encodeWebp(playthroughId, character4.charId, file);
  return result;
}
async function encodeWebp(playthroughId, charId, file) {
  try {
    const png = await photoInvoke("read", [playthroughId, charId, file]);
    if (!png.ok) throw new Error(`could not read it back: ${png.error.code}`);
    const blob = new Blob([new Uint8Array(png.data)], { type: "image/png" });
    const bitmap = await createImageBitmap(blob);
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    canvas.getContext("2d")?.drawImage(bitmap, 0, 0);
    bitmap.close();
    const webp = await canvas.convertToBlob({ type: "image/webp", quality: WEBP_QUALITY });
    if (webp.type !== "image/webp") throw new Error(`the encoder gave ${webp.type}`);
    const bytes = new Uint8Array(await webp.arrayBuffer());
    const stored = await photoInvoke("storeWebp", [playthroughId, charId, file, bytes]);
    if (!stored.ok) throw new Error(`${stored.error.code}: ${stored.error.message}`);
  } catch (error) {
    console.warn(`[photo] kept ${file} as PNG: ${String(error)}`);
  }
}

// src/renderer/stores/photoRedraw.ts
var RENDER_PATIENCE_MS = 3 * 60 * 1e3;
var redraws = /* @__PURE__ */ new Map();
var listeners = /* @__PURE__ */ new Set();
function photoRedrawKey(playthroughId, charId, file) {
  return `${playthroughId}:${charId}:${file}`;
}
function changed() {
  for (const listener of listeners) listener();
}
function beginPhotoRedraw(key) {
  const previous = redraws.get(key);
  if (previous?.state === "drawing") return void 0;
  clearTimeout(previous?.timer);
  const token = {};
  redraws.set(key, { token, state: "drawing" });
  changed();
  return token;
}
function endPhotoRedraw(key, token, failed = false) {
  const entry = redraws.get(key);
  if (entry?.token !== token) return;
  if (failed && entry.state === "failed") return;
  clearTimeout(entry.timer);
  if (failed) {
    entry.state = "failed";
    entry.timer = setTimeout(() => endPhotoRedraw(key, token), 4e3);
  } else {
    redraws.delete(key);
  }
  changed();
}
function usePhotoRedraw(key) {
  return useSyncExternalStore(
    (listener) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    () => redraws.get(key)?.state ?? "idle",
    () => "idle"
  );
}
async function redrawPhoto({ playthroughId, character: character4, friend, kind, read, write, live, inSave }, options) {
  const photo = read();
  if (!live() || !photoGenerationOn() || !photo?.file || !photo.scene || photo.pending || photo.failed || photo.held || photo.with && !friend) {
    return;
  }
  const charId = character4.charId;
  const oldFile = photo.file;
  const key = photoRedrawKey(playthroughId, charId, oldFile);
  const token = beginPhotoRedraw(key);
  if (!token) return;
  let settled = false;
  let timer;
  try {
    const named = await photoInvoke("reserveName", [playthroughId, character4, kind, inSave()]);
    if (!named.ok) throw new Error(`${named.error.code}: ${named.error.message}`);
    if (!live() || read()?.file !== oldFile || !photoGenerationOn()) return;
    const newFile = named.data;
    timer = setTimeout(() => {
      console.warn(`[photo] redraw of ${oldFile} has not answered in time`);
      settled = true;
      endPhotoRedraw(key, token, live() && read()?.file === oldFile);
    }, RENDER_PATIENCE_MS);
    const result = await renderPhoto(
      playthroughId,
      character4,
      photo.tier,
      photo.scene,
      newFile,
      friend,
      options
    );
    if (!result.ok) throw new Error(`${result.error.code}: ${result.error.message}`);
    const now = read();
    const replace = live() && now?.file === oldFile;
    if (replace) await write({ ...now, file: newFile });
    const dropped = replace ? await photoInvoke("drop", [playthroughId, charId, oldFile, { replacement: newFile }]) : await photoInvoke("drop", [playthroughId, charId, newFile]);
    if (!dropped.ok) {
      console.warn(`[photo] could not drop ${replace ? oldFile : newFile}:`, dropped.error.message);
    }
    settled = true;
    endPhotoRedraw(key, token);
  } catch (error) {
    console.warn(`[photo] redraw of ${oldFile} failed:`, error);
    settled = true;
    endPhotoRedraw(key, token, live() && read()?.file === oldFile);
  } finally {
    clearTimeout(timer);
    if (!settled) endPhotoRedraw(key, token);
  }
}

// src/renderer/stores/photoPost.ts
import { noNsfwImages as noNsfwImages2 } from "@vx/modkit/renderer";
function settlePostPhoto(image) {
  const scene = image?.trim();
  if (!scene || !canSendPhotos()) return null;
  const allowed = allowedPostTier(noNsfwImages2());
  const verdict = settlePhoto({ sendPhoto: true, photoPrompt: scene, allowed });
  if (!verdict.send) {
    if (verdict.note) console.log(`[feed] no picture on a post: ${verdict.note}`);
    return null;
  }
  return { tier: verdict.tier, scene };
}
async function reservePostPhotoName(charId) {
  const game = photoGame();
  const character4 = game.characters[charId];
  if (!character4 || !game.playthroughId) return null;
  const result = await photoInvoke("reserveName", [game.playthroughId, character4, "bunnyboard", photoNamesInSave(charId)]);
  if (result.ok) return result.data;
  console.warn(`[feed] no name for a post's picture: ${result.error.code}`, result.error.message);
  return null;
}
var SWIMWEAR = /\b(swim\w*|bikini\w*)/i;
async function preparePostPhoto(charId, image, friendId) {
  const shot = settlePostPhoto(image);
  if (!shot) return null;
  const file = await reservePostPhotoName(charId);
  if (!file) return null;
  const dressed = shot.tier === "everyday" || shot.tier === "suggestive" && SWIMWEAR.test(shot.scene);
  const friend = friendId && dressed ? photoGame().characters[friendId] : void 0;
  if (friendId && !friend) console.log("[photo] the friend is left out of a picture past everyday clothes");
  return { shot, file, ...friend ? { with: friend.charId } : {} };
}
var nudgeOf = null;
function holdPostPhoto(_charId, written, prepared, nudge) {
  nudgeOf = nudge;
  const { tier, scene } = prepared.shot;
  return postPhoto.with(written, {
    tier,
    scene,
    file: prepared.file,
    held: true,
    ...prepared.with ? { with: prepared.with } : {}
  });
}
var drawing = /* @__PURE__ */ new Set();
var chain = Promise.resolve();
var queued = /* @__PURE__ */ new Set();
function keyOf(playthroughId, postId) {
  return `${playthroughId}:${postId}`;
}
function photoOf(charId, postId) {
  const post = photoGame().charInfo[charId]?.feed?.find((one) => one.id === postId);
  return post ? postPhoto.read(post) : null;
}
function settle(charId, postId, photo) {
  const before = photoOf(charId, postId);
  if (!before) return;
  const changed2 = setFeedPostPhoto(charId, postId, before.held ? { ...photo, outAt: Date.now() } : photo);
  if (!changed2.ok) return;
  if (before.held) {
    const flags = photoGame().charInfo[charId]?.flags;
    if (flags?.gaveContactInfo && !flags.blocked) nudgeOf?.(charId);
  }
  savePhotoState();
}
async function drawPostPhoto(charId, postId) {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  const character4 = game.characters[charId];
  const photo = photoOf(charId, postId);
  if (!playthroughId || !character4 || !photo?.file || !photo.scene) return;
  const key = keyOf(playthroughId, postId);
  if (drawing.has(key)) return;
  const { tier, scene, file } = photo;
  const drawn = { tier, scene, file, ...photo.with ? { with: photo.with } : {} };
  const friend = photo.with ? game.characters[photo.with] : void 0;
  const live = () => photoGame().playthroughId === playthroughId && photoGame().run === game.run;
  const landed2 = await photoInvoke("landed", [playthroughId, charId, file]);
  if (!live()) return;
  if (landed2.ok && landed2.data) {
    settle(charId, postId, drawn);
    console.log(`[feed] ${character4.firstName}'s picture was already drawn: ${file}`);
    return;
  }
  drawing.add(key);
  const render = renderPhoto(playthroughId, character4, tier, scene, file, friend).catch((error) => ({
    ok: false,
    error: { code: "PHOTO_THREW", message: String(error) }
  })).then((result) => {
    drawing.delete(key);
    if (!live()) return;
    if (result.ok) {
      settle(charId, postId, drawn);
      console.log(`[feed] ${character4.firstName} posted ${file}`);
      return;
    }
    console.warn(
      `[feed] a post's picture failed, so the post goes up without it: ${result.error.code}`,
      result.error.message
    );
    settle(charId, postId, { ...drawn, failed: true });
  });
  let timer;
  const patience = new Promise((resolve) => {
    timer = setTimeout(() => {
      const now = photoOf(charId, postId);
      if (live() && (now?.held || now?.pending)) {
        console.warn(`[feed] a post's picture has not answered in time, so it goes up without it`);
        settle(charId, postId, { ...drawn, failed: true });
      }
      resolve();
    }, RENDER_PATIENCE_MS);
  });
  await Promise.race([render, patience]);
  clearTimeout(timer);
}
function enqueue(charId, postId) {
  chain = chain.then(async () => {
    try {
      await drawPostPhoto(charId, postId);
    } catch (error) {
      console.warn("[feed] a post's picture threw:", error);
    }
  });
}
function startHeldPostPhoto() {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  if (!playthroughId) return;
  if (!canSendPhotos()) return;
  const held = Object.entries(game.charInfo).flatMap(
    ([charId, info]) => (info?.feed ?? []).filter((post) => postPhoto.read(post)?.held).map((post) => ({ charId, post }))
  );
  held.sort((a, b) => a.post.date - b.post.date || a.post.time - b.post.time);
  for (const { charId, post } of held) {
    const key = keyOf(playthroughId, post.id);
    if (drawing.has(key) || queued.has(key)) continue;
    queued.add(key);
    enqueue(charId, post.id);
    chain = chain.finally(() => queued.delete(key));
  }
}
function rerollPostPhoto(charId, postId) {
  const game = photoGame();
  const photo = photoOf(charId, postId);
  if (!game.playthroughId || !photo?.file || !photo.scene || !canSendPhotos()) return;
  const { tier, scene, file } = photo;
  setFeedPostPhoto(charId, postId, {
    tier,
    scene,
    file,
    pending: true,
    ...photo.with ? { with: photo.with } : {}
  });
  if (drawing.has(keyOf(game.playthroughId, postId))) return;
  enqueue(charId, postId);
}
async function redrawPostPhoto(charId, postId, options) {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  const character4 = game.characters[charId];
  if (!playthroughId || !character4 || !canSendPhotos()) return;
  const photo = photoOf(charId, postId);
  await redrawPhoto({
    playthroughId,
    character: character4,
    friend: photo?.with ? game.characters[photo.with] : void 0,
    kind: "bunnyboard",
    read: () => photoOf(charId, postId),
    write: async (next) => {
      setFeedPostPhoto(charId, postId, next);
      await savePhotoStateAwaitable(game.run);
    },
    live: () => {
      const now = photoGame();
      return now.playthroughId === playthroughId && now.run === game.run;
    },
    inSave: () => photoNamesInSave(charId)
  }, options);
}

// src/renderer/stores/photoRecovery.ts
import { runStale } from "@vx/modkit/renderer";
async function settlePendingPhotos() {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  if (!playthroughId) return;
  let settled = false;
  for (const charId of Object.keys(game.charInfo)) {
    for (const post of game.charInfo[charId]?.feed ?? []) {
      const photo = postPhoto.read(post);
      if (!photo?.pending) continue;
      const landed2 = photo.file ? await photoInvoke("landed", [playthroughId, charId, photo.file]) : { ok: true, data: false };
      const found = landed2.ok && landed2.data;
      if (runStale(game.run) || photoGame().playthroughId !== playthroughId) return;
      setFeedPostPhoto(charId, post.id, {
        tier: photo.tier,
        scene: photo.scene,
        ...photo.file ? { file: photo.file } : {},
        ...photo.with ? { with: photo.with } : {},
        ...found ? {} : { failed: true }
      });
      settled = true;
      console.log(
        `[feed] a post's picture was still waiting: ${photo.file ?? "unnamed"} \u2014 ${found ? "found it" : "gone"}`
      );
    }
  }
  for (const [charId, thread] of Object.entries(game.bunnyboard.conversations)) {
    for (const message of thread?.messages ?? []) {
      const photo = messagePhoto.read(message);
      if (!photo?.pending) continue;
      const landed2 = photo.file ? await photoInvoke("landed", [playthroughId, charId, photo.file]) : { ok: true, data: false };
      const found = landed2.ok && landed2.data;
      if (runStale(game.run) || photoGame().playthroughId !== playthroughId) return;
      setMessagePhoto(charId, message.id, {
        tier: photo.tier,
        scene: photo.scene,
        ...photo.file ? { file: photo.file } : {},
        ...photo.with ? { with: photo.with } : {},
        ...found ? {} : { failed: true }
      });
      settled = true;
      console.log(
        `[texting] her picture was still waiting: ${photo.file ?? "unnamed"} \u2014 ${found ? "found it" : "gone"}`
      );
    }
  }
  if (settled) savePhotoState();
}

// src/renderer/stores/photoTurn.ts
import { affectionFor as affectionFor2 } from "@vx/modkit/shared";

// src/renderer/stores/photoTipDelivery.ts
import { bunnybotSays } from "@vx/modkit/renderer";

// src/renderer/prompts/photoTips.ts
var DM_PHOTO_TIP_MARK = `the spicy ones come covered, so tap to take a peek... tap again to see it full size. if one ever fails to load, just hit reroll`;
function bunnybotDmPhotoTexts(firstName) {
  return [
    `ooh, ${firstName.toLowerCase()} just sent you a pic. photos on bunnyboard get drawn right on your own pc, so give them a sec to show up`,
    DM_PHOTO_TIP_MARK,
    `what they're willing to send depends on how close you two are, and her page keeps a gallery of everything she's sent you`,
    `and if you'd rather not get any, you can switch photos off in settings`
  ];
}
var FEED_PHOTO_TIP_MARK = `pics on posts get drawn right on your own pc, so a post only shows up once its pic is ready. tap one to see it full size`;
function bunnybotFeedPhotoTexts(firstName) {
  return [
    `peep the updates tab... ${firstName.toLowerCase()} posted a pic`,
    FEED_PHOTO_TIP_MARK,
    `if one ever fails to load, you can hit reroll right there on the post. and photos can be switched off in settings if they're not your thing`
  ];
}

// src/renderer/stores/photoTipDelivery.ts
import { character as character2 } from "@vx/modkit/renderer";
function tellAboutDmPhotos(firstName) {
  bunnybotSays(PHOTO_FEATURE_ID, bunnybotDmPhotoTexts(firstName), { once: DM_PHOTO_TIP_MARK });
}
function tellAboutFeedPhotos(charId) {
  const firstName = character2(charId)?.firstName;
  if (!firstName) return;
  bunnybotSays(PHOTO_FEATURE_ID, bunnybotFeedPhotoTexts(firstName), { once: FEED_PHOTO_TIP_MARK });
}

// src/renderer/stores/photoTurn.ts
function settleReplyPhoto(charId, character4, data) {
  const game = photoGame();
  const info = game.charInfo[charId];
  return settlePhoto({
    sendPhoto: data.sendPhoto === true,
    photoPrompt: data.photoPrompt ?? "",
    // Her own reading of what she drew, which may raise the caption's but never lower it.
    stated: data.photoTier && isPhotoTier(data.photoTier) ? data.photoTier : void 0,
    allowed: allowedPhotoTier({
      flags: info?.flags,
      affection: affectionFor2(info, game.date, character4),
      traits: character4.traits,
      noNsfwImages: noExplicitPhotos(),
      canRender: canSendPhotos()
    })
  });
}
var earlyPhotos = /* @__PURE__ */ new Map();
function earlyIsLive(early) {
  const game = photoGame();
  return game.playthroughId === early.playthroughId && game.run === early.run;
}
function discardEarlyPhoto(early) {
  if (early.attached || early.discarded) return;
  early.discarded = true;
  early.release();
  if (early.file) {
    void photoInvoke("drop", [early.playthroughId, early.charId, early.file, { cancelOnly: true }]).catch((error) => console.warn("[photo] could not cancel an early photo:", error));
  }
  if (earlyPhotos.get(early.charId) === early) earlyPhotos.delete(early.charId);
  void early.render.then(async () => {
    if (!early.file) return;
    const game = photoGame();
    if (game.playthroughId === early.playthroughId && photoNamesInSave(early.charId).includes(early.file))
      return;
    const dropped = await photoInvoke("drop", [early.playthroughId, early.charId, early.file]);
    if (!dropped.ok) console.warn("[photo] could not drop an unused early photo:", dropped.error);
  }).catch((error) => console.warn("[photo] could not clean up an early photo:", error));
}
function clearEarlyPhotos() {
  for (const early of earlyPhotos.values()) discardEarlyPhoto(early);
}
function startDmPhoto(charId, character4, lead, signal) {
  if (signal.aborted) return;
  const previous = earlyPhotos.get(charId);
  if (previous) discardEarlyPhoto(previous);
  const data = {
    sendPhoto: lead.sendPhoto === true,
    photoPrompt: typeof lead.photoPrompt === "string" ? lead.photoPrompt : "",
    photoTier: typeof lead.photoTier === "string" ? lead.photoTier : void 0
  };
  const verdict = settleReplyPhoto(charId, character4, data);
  const game = photoGame();
  if (!verdict.send || !game.playthroughId) return;
  const cancelled = {
    ok: false,
    error: {
      code: "CANCELLED",
      message: "The photo reply was abandoned."
    }
  };
  const early = {
    charId,
    tier: verdict.tier,
    scene: data.photoPrompt.trim(),
    playthroughId: game.playthroughId,
    run: game.run,
    release: () => signal.removeEventListener("abort", abort),
    ready: Promise.resolve(cancelled),
    render: Promise.resolve(cancelled),
    attached: false,
    discarded: false
  };
  const abort = () => discardEarlyPhoto(early);
  signal.addEventListener("abort", abort, { once: true });
  earlyPhotos.set(charId, early);
  early.ready = photoInvoke("reserveName", [early.playthroughId, character4, "chat", photoNamesInSave(charId)]).then((named) => {
    if (named.ok) early.file = named.data;
    return named;
  }).catch((error) => ({
    ok: false,
    error: { code: "PHOTO_THREW", message: String(error) }
  }));
  early.render = early.ready.then((named) => {
    if (!named.ok) return named;
    if (early.discarded || !earlyIsLive(early) || !canSendPhotos()) return cancelled;
    console.log(`[photo] starting early DM render: ${named.data}`);
    return renderPhoto(early.playthroughId, character4, early.tier, early.scene, named.data);
  }).catch((error) => ({
    ok: false,
    error: { code: "PHOTO_THREW", message: String(error) }
  })).then((result) => {
    early.result = result;
    if (!early.attached && (!earlyIsLive(early) || !canSendPhotos())) discardEarlyPhoto(early);
    return result;
  });
}
async function sendPhoto(charId, character4, data, useEarly = false) {
  const early = useEarly ? earlyPhotos.get(charId) : void 0;
  if (early) earlyPhotos.delete(charId);
  const game = photoGame();
  const verdict = settleReplyPhoto(charId, character4, data);
  if (early && (!verdict.send || !earlyIsLive(early) || data.sendPhoto !== true || data.photoPrompt?.trim() !== early.scene || verdict.tier !== early.tier))
    discardEarlyPhoto(early);
  if (!verdict.send) {
    if (verdict.note) console.log(`[texting] no photo from ${character4.firstName}: ${verdict.note}`);
    return;
  }
  const messages = game.bunnyboard.conversations[charId]?.messages ?? [];
  const last = [...messages].reverse().find((message) => message.sender === "contact");
  const playthroughId = game.playthroughId;
  if (!last || !playthroughId) {
    if (early) discardEarlyPhoto(early);
    return;
  }
  const scene = (data.photoPrompt ?? "").trim();
  if (early && !early.discarded) {
    const named2 = await early.ready;
    const now = photoGame();
    const message = now.bunnyboard.conversations[charId]?.messages.find((one) => one.id === last.id);
    if (early.discarded || !earlyIsLive(early) || !message || messagePhoto.read(message) || !canSendPhotos()) {
      discardEarlyPhoto(early);
      return;
    }
    if (named2.ok && early.file) {
      early.attached = true;
      early.release();
      setMessagePhoto(charId, last.id, {
        tier: early.tier,
        scene: early.scene,
        file: early.file,
        ...early.result?.ok ? {} : { pending: true }
      });
      tellAboutDmPhotos(character4.firstName);
      savePhotoState();
      if (!early.result?.ok) drawMessagePhoto(charId, last.id, early.render);
      return;
    }
    discardEarlyPhoto(early);
  }
  const named = await photoInvoke("reserveName", [playthroughId, character4, "chat", photoNamesInSave(charId)]);
  if (!named.ok) {
    console.warn(`[texting] no name for her photo: ${named.error.code}`, named.error.message);
    return;
  }
  const file = named.data;
  const live = photoGame();
  const held = live.bunnyboard.conversations[charId]?.messages.find(
    (message) => message.id === last.id
  );
  if (live.playthroughId !== playthroughId || live.run !== game.run || !held || messagePhoto.read(held) || !canSendPhotos())
    return;
  setMessagePhoto(charId, last.id, { tier: verdict.tier, scene, file, pending: true });
  tellAboutDmPhotos(character4.firstName);
  savePhotoState();
  drawMessagePhoto(charId, last.id);
}
var drawing2 = /* @__PURE__ */ new Set();
function messagePhotoOf(charId, messageId) {
  const chat = photoGame().bunnyboard.conversations[charId];
  const message = chat?.messages.find((message2) => message2.id === messageId);
  return message ? messagePhoto.read(message) : null;
}
function drawMessagePhoto(charId, messageId, started) {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  const character4 = game.characters[charId];
  const photo = messagePhotoOf(charId, messageId);
  if (!playthroughId || !character4 || !photo?.file || !photo.scene) return;
  const key = `${playthroughId}:${messageId}`;
  if (drawing2.has(key)) return;
  const { tier, scene, file } = photo;
  const drawn = { tier, scene, file, ...photo.with ? { with: photo.with } : {} };
  const friend = photo.with ? game.characters[photo.with] : void 0;
  const live = () => {
    const now = photoGame();
    return now.playthroughId === playthroughId && now.run === game.run && messagePhotoOf(charId, messageId)?.file === file;
  };
  const settle2 = (next) => {
    if (!live() || !messagePhotoOf(charId, messageId)) return;
    setMessagePhoto(charId, messageId, next);
    savePhotoState();
  };
  drawing2.add(key);
  const timer = setTimeout(() => {
    if (messagePhotoOf(charId, messageId)?.pending) {
      console.warn(`[texting] her photo has not answered in time`);
      settle2({ ...drawn, failed: true });
    }
  }, RENDER_PATIENCE_MS);
  void (started ?? renderPhoto(playthroughId, character4, tier, scene, file, friend)).catch((error) => ({
    ok: false,
    error: { code: "PHOTO_THREW", message: String(error) }
  })).then((result) => {
    clearTimeout(timer);
    drawing2.delete(key);
    if (result.ok) {
      settle2(drawn);
      return;
    }
    console.warn(`[texting] her photo failed: ${result.error.code}`, result.error.message);
    settle2({ ...drawn, failed: true });
  });
}
function rerollMessagePhoto(charId, messageId) {
  const photo = messagePhotoOf(charId, messageId);
  if (!photo?.file || !photo.scene || !canSendPhotos()) return;
  const { tier, scene, file } = photo;
  setMessagePhoto(charId, messageId, {
    tier,
    scene,
    file,
    pending: true,
    ...photo.with ? { with: photo.with } : {}
  });
  drawMessagePhoto(charId, messageId);
}
async function redrawMessagePhoto(charId, messageId, options) {
  const game = photoGame();
  const playthroughId = game.playthroughId;
  const character4 = game.characters[charId];
  if (!playthroughId || !character4 || !canSendPhotos()) return;
  const photo = messagePhotoOf(charId, messageId);
  await redrawPhoto(
    {
      playthroughId,
      character: character4,
      friend: photo?.with ? game.characters[photo.with] : void 0,
      kind: "chat",
      read: () => messagePhotoOf(charId, messageId),
      write: async (next) => {
        setMessagePhoto(charId, messageId, next);
        await savePhotoStateAwaitable(game.run);
      },
      live: () => {
        const now = photoGame();
        return now.playthroughId === playthroughId && now.run === game.run;
      },
      inSave: () => photoNamesInSave(charId)
    },
    options
  );
}

// src/renderer/stores/photoGroup.ts
import { npcFriendsOf as npcFriendsOf2 } from "@vx/modkit/shared";

// src/shared/photoDuo.ts
import {
  areNpcFriends,
  npcPairOf,
  zoneOf
} from "@vx/modkit/shared";
function groupPhotoPair(cast, relationships, rand = Math.random) {
  const girls = [...new Set(cast)];
  const pairs = [];
  for (let i = 0; i < girls.length; i++) {
    for (let j = i + 1; j < girls.length; j++) {
      const a = girls[i];
      const b = girls[j];
      if (zoneOf(npcPairOf(relationships, a, b)?.affinity ?? 0) === "enemies") continue;
      pairs.push({ poster: a, friend: b }, { poster: b, friend: a });
    }
  }
  return pairs.length ? pairs[Math.floor(rand() * pairs.length)] : null;
}
function photoFriendHandle(relationships, posterId, friendId, charInfo) {
  if (!friendId || friendId === posterId || !areNpcFriends(relationships, posterId, friendId)) {
    return null;
  }
  return charInfo[friendId]?.handle || null;
}

// src/renderer/stores/photoGroup.ts
import {
  ownsPostComments,
  promptFields,
  promptLines,
  promptRequired,
  fileLatePost
} from "@vx/modkit/renderer";
var asked = null;
var settledSlot = null;
function slotKey() {
  const { playthroughId, date, time } = photoGame();
  return playthroughId ? `${playthroughId}:${date}:${time}` : null;
}
function postedThisSlot() {
  const { charInfo, date, time } = photoGame();
  return Object.values(charInfo).some(
    (info) => (info?.feed ?? []).some((post) => post.date === date && post.time === time && postPhoto.read(post)?.with)
  );
}
function postFieldLines() {
  if (ownsPostComments(PHOTO_FEATURE_ID)) return postCommentLines(true);
  const own = new Set(postPhotoLines(true));
  return promptLines("slot-posts", {}).filter((line) => !own.has(line));
}
function groupPostField() {
  return {
    type: "object",
    properties: {
      ...promptFields("slot-posts"),
      text: { type: "string" },
      image: { type: "string" }
    },
    required: [.../* @__PURE__ */ new Set(["text", "image", ...promptRequired("slot-posts")])]
  };
}
function withGroupPhotoRequest(request, cast) {
  if (!duoPhotosOn() || !canSendPhotos()) return request;
  const slot = slotKey();
  if (!slot || settledSlot === slot) return request;
  if (postedThisSlot()) {
    settledSlot = slot;
    return request;
  }
  const ids = cast.map((girl) => girl.charId);
  if (!asked || asked.slot !== slot || !ids.includes(asked.poster) || !ids.includes(asked.friend)) {
    const pair = groupPhotoPair(ids, photoGame().npcRelationships);
    asked = pair ? { ...pair, slot } : null;
    if (!asked) return request;
  }
  const characters = photoGame().characters;
  const poster = characters[asked.poster];
  const friend = characters[asked.friend];
  if (!poster || !friend) return request;
  console.log(`[photo] group photo asked of the scene: ${poster.firstName} with ${friend.firstName}`);
  const block = [
    "GROUP PHOTO",
    `${poster.firstName} is posting a photo of herself and ${friend.firstName}, taken here as this scene begins. Fill "groupPost": "text" is her post, one or two short lines in her own voice; "image" is one full sentence describing the photograph: where they are, "in their everyday clothes", "in their PE kit" for sport or the gym, or "in their swimsuits" at a pool or a beach, rather than what each one wears; the two of them side by side and not touching, from the waist up, looking at the camera with the faces friends pull in a photo together: smiling, laughing, a grin or a pout. Say "her and her friend" rather than either name, and never "two girls". The scene itself does not mention the photo.`,
    ...postFieldLines(),
    ""
  ].join("\n");
  const at = request.user.lastIndexOf("YOUR TURN");
  const user = at >= 0 ? `${request.user.slice(0, at)}${block}
${request.user.slice(at)}` : `${request.user}

${block}`;
  const schema = request.schema.schema;
  return {
    ...request,
    user,
    schema: {
      ...request.schema,
      schema: {
        ...schema,
        properties: { ...schema.properties ?? {}, groupPost: groupPostField() },
        required: [...schema.required ?? [], "groupPost"]
      }
    }
  };
}
function fileGroupPhoto({ reply }) {
  const slot = slotKey();
  const waiting = asked;
  if (!waiting || waiting.slot !== slot || settledSlot === slot) return;
  settledSlot = slot;
  asked = null;
  const written = reply.groupPost;
  const text = typeof written?.text === "string" ? written.text.trim() : "";
  const image = typeof written?.image === "string" ? written.image.trim() : "";
  if (!written || !text || !image) {
    console.log("[photo] the scene wrote no group photo");
    return;
  }
  const game = photoGame();
  const char = Object.keys(game.charKeyToId).find((key) => game.charKeyToId[key] === waiting.poster);
  if (!char) return;
  void fileLatePost({ ...written, char, text, image, groupWith: waiting.friend }).then(() => startHeldPostPhoto());
}
var FEED_FRIEND_CHANCE = 0.25;
var feedFriends = null;
function feedFriendOf(character4, date, time) {
  if (!duoPhotosOn() || !canSendPhotos()) return null;
  const { playthroughId } = photoGame();
  if (!playthroughId) return null;
  const slot = `${playthroughId}:${date}:${time}`;
  if (feedFriends?.slot !== slot) feedFriends = { slot, rolled: /* @__PURE__ */ new Set(), pairs: /* @__PURE__ */ new Map() };
  const game = photoGame();
  const known = feedFriends.pairs.get(character4.charId);
  if (feedFriends.rolled.has(character4.charId)) return known ? game.characters[known] ?? null : null;
  feedFriends.rolled.add(character4.charId);
  if (feedFriends.pairs.size > 0) return null;
  const friends = npcFriendsOf2(game.npcRelationships, character4.charId, game.chars).filter(
    (id) => game.characters[id]
  );
  if (friends.length === 0 || Math.random() >= FEED_FRIEND_CHANCE) return null;
  const friend = game.characters[friends[Math.floor(Math.random() * friends.length)]];
  if (!friend) return null;
  feedFriends.pairs.set(character4.charId, friend.charId);
  console.log(`[photo] ${character4.firstName}'s post this slot is a picture with ${friend.firstName}`);
  return friend;
}
function feedFriendLines(character4, date, time) {
  const friend = feedFriendOf(character4, date, time);
  if (!friend) return [];
  return [
    `  Her post is a picture of her and her friend ${friend.firstName}, so it carries an "image": the two of them side by side and not touching, from the waist up, "in their everyday clothes", "in their PE kit" for sport or the gym, or "in their swimsuits" only where they are at a pool or a beach, rather than what each one wears, and pulling the faces friends do in a photo together: smiling, laughing, a grin or a pout. Say "her and her friend", never ${friend.firstName}'s name.`
  ];
}
function feedFriendFor(charId) {
  return feedFriends?.slot === slotKey() ? feedFriends?.pairs.get(charId) : void 0;
}

// src/renderer/modEntries/photo-feature.ts
import { character as character3, gameFacts as gameFacts2, modOptionOn } from "@vx/modkit/renderer";
import { registerTermFiles } from "@vx/modkit/shared";
import { ownsPostComments as ownsPostComments2, registerHooks } from "@vx/modkit/renderer";

// src/renderer/views/bodyFields.tsx
import { motion } from "motion/react";

// src/renderer/stores/photoSwitchHooks.ts
import { useModOn, useModOption, useNoNsfwImages } from "@vx/modkit/renderer";
function usePhotoSwitches() {
  useModOn(PHOTO_FEATURE_ID);
  useModOption(PHOTO_FEATURE_ID, "photos");
  useModOption(PHOTO_FEATURE_ID, "explicit");
  useModOption(PHOTO_FEATURE_ID, "webp");
  useModOption(PHOTO_FEATURE_ID, "body");
  useModOption(PHOTO_FEATURE_ID, "duo");
  useModOption(PHOTO_FEATURE_ID, "loader-bunny");
  useModOption(PHOTO_FEATURE_ID, "loader-shimmer");
  useModOption(PHOTO_FEATURE_ID, "loader-dots");
  return photoSwitches();
}
function usePhotosVisible() {
  return photosVisible(usePhotoSwitches());
}
function useExplicitBlocked() {
  const noNsfw = useNoNsfwImages();
  return !explicitPhotosAllowed(noNsfw, usePhotoSwitches());
}

// src/renderer/views/bodyFields.tsx
import { gestures, quietLift, quietPress, recordField as recordField2 } from "@vx/modkit/renderer";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var LABELS = {
  build: "Build",
  breasts: "Breasts",
  hipsThighs: "Hips and thighs",
  buttocks: "Backside",
  pubicHair: "Pubic hair"
};
function noneLabel(field, baseAppearance) {
  if (field === "breasts")
    return `As her appearance says (${bodyTagLabel(appearanceBreasts(baseAppearance))})`;
  if (field === "pubicHair") return "Clean";
  return "Average";
}
var PHOTO_BODY_FIELD = recordField2(PHOTO_FEATURE_ID, {
  empty: {},
  legacy: ["body"],
  normalize: (stored, legacy) => cleanBody(stored === void 0 ? legacy.body : stored) ?? {}
});
function writeBody(value) {
  return {
    ex: PHOTO_BODY_FIELD.with({ ex: {} }, cleanBody(value) ?? {}).ex,
    body: void 0
  };
}
function bodyForm(body) {
  return cleanBody(body) ?? {};
}
function BodyFieldsSection({
  body,
  baseAppearance,
  onChange
}) {
  const { on: modOn, body: switchedOn } = usePhotoSwitches();
  const on = switchedOn && modOn;
  if (!on) return null;
  const hasBody = BODY_FIELDS.some((field) => body[field]);
  function pickBuild(value) {
    if (value === NOT_SET) onChange({});
    else
      onChange(
        drawBody(value === AVERAGE ? void 0 : value, baseAppearance, Math.random, body.breasts)
      );
  }
  function pickBreasts(value) {
    onChange(cleanBody({ ...body, breasts: value }) ?? {});
  }
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs("div", { className: "vu-edit-body-head", children: [
      /* @__PURE__ */ jsx("span", { className: "vu-field-label", children: "Body" }),
      /* @__PURE__ */ jsx("span", { className: "vu-check-note", children: "Pick her build and her chest, and the rest is drawn to fit, from tags the image model knows; reroll for another combination. Her chest starts from her appearance. Used in her sprites, CGs and photos once they are generated again." })
    ] }),
    /* @__PURE__ */ jsxs("label", { className: "vu-field", htmlFor: "edit-body-build", children: [
      /* @__PURE__ */ jsx("span", { className: "vu-field-label", children: LABELS.build }),
      /* @__PURE__ */ jsxs(
        "select",
        {
          id: "edit-body-build",
          className: "vu-input vu-select",
          value: hasBody ? body.build ?? AVERAGE : NOT_SET,
          onChange: (e) => pickBuild(e.target.value),
          children: [
            /* @__PURE__ */ jsx("option", { value: NOT_SET, children: "Not set (her appearance only)" }),
            /* @__PURE__ */ jsx("option", { value: AVERAGE, children: "Average" }),
            BODY_POOLS.build.map((tag) => /* @__PURE__ */ jsx("option", { value: tag, children: bodyTagLabel(tag) }, tag))
          ]
        }
      )
    ] }),
    hasBody && /* @__PURE__ */ jsxs("label", { className: "vu-field", htmlFor: "edit-body-breasts", children: [
      /* @__PURE__ */ jsx("span", { className: "vu-field-label", children: LABELS.breasts }),
      /* @__PURE__ */ jsx(
        "select",
        {
          id: "edit-body-breasts",
          className: "vu-input vu-select",
          value: body.breasts ?? appearanceBreasts(baseAppearance),
          onChange: (e) => pickBreasts(e.target.value),
          children: BODY_POOLS.breasts.map((tag) => /* @__PURE__ */ jsx(
            "option",
            {
              value: tag,
              disabled: !allowedBeside({ build: body.build }, "breasts", tag),
              children: bodyTagLabel(tag)
            },
            tag
          ))
        }
      )
    ] }),
    hasBody && /* @__PURE__ */ jsxs("div", { className: "vu-edit-body-drawn", children: [
      /* @__PURE__ */ jsx("span", { className: "vu-check-note", children: DRAWN_FIELDS.map(
        (field) => `${LABELS[field]}: ${body[field] ? bodyTagLabel(body[field]) : noneLabel(field, baseAppearance)}`
      ).join(" \xB7 ") }),
      /* @__PURE__ */ jsx(
        motion.button,
        {
          type: "button",
          id: "edit-body-reroll",
          className: "vu-pill",
          ...gestures(false, quietLift, quietPress),
          onClick: () => onChange(drawBody(body.build, baseAppearance, Math.random, body.breasts)),
          children: "Reroll"
        }
      )
    ] })
  ] });
}
var NOT_SET = "not-set";
var AVERAGE = "average";
var DRAWN_FIELDS = ["hipsThighs", "buttocks", "pubicHair"];
var BODY_EDITOR_FIELD = {
  read: (character4) => bodyForm(bodyOf(character4)),
  write: writeBody,
  Field: ({ value, onChange, baseAppearance }) => /* @__PURE__ */ jsx(BodyFieldsSection, { body: value, baseAppearance, onChange })
};

// src/renderer/components/PhotoPostSpots.tsx
import { useEffect as useEffect3, useId as useId2, useState as useState3 } from "react";
import { AnimatePresence as AnimatePresence2, motion as motion4 } from "motion/react";
import { hashString, shownComments } from "@vx/modkit/shared";
import { noteIn } from "@vx/modkit/renderer";
import { useFeed, useGameFacts as useGameFacts2, useNpcRelationships, useCharacterInfo, useClock } from "@vx/modkit/renderer";

// src/renderer/components/PhotoBubble.tsx
import { motion as motion3, useReducedMotion as useReducedMotion2 } from "motion/react";
import { useEffect as useEffect2, useState as useState2 } from "react";
import { useCharacter, useGameFacts } from "@vx/modkit/renderer";
import {
  bunnyHop,
  typingDot,
  BunnyMark,
  EyeIcon,
  EyeOffIcon,
  Lightbox,
  useViewingThread
} from "@vx/modkit/renderer";

// src/renderer/components/PhotoInfo.tsx
import { useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { AnimatePresence, motion as motion2, useReducedMotion } from "motion/react";
import {
  gestures as gestures2,
  lift,
  panelUnderTab,
  press,
  quietLift as quietLift2,
  quietPress as quietPress2,
  TextField,
  TitleTab,
  useModalShell,
  veilIn
} from "@vx/modkit/renderer";
import { Fragment as Fragment2, jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function PhotoInfoButton({ redrawing = false, ...props }) {
  const [theme, setTheme] = useState(null);
  return /* @__PURE__ */ jsxs2(Fragment2, { children: [
    !redrawing && /* @__PURE__ */ jsx2(
      "button",
      {
        type: "button",
        className: "vu-bb-photo-info",
        "aria-label": "Photo info",
        title: "Photo info",
        onPointerDownCapture: (event) => event.stopPropagation(),
        onClick: (event) => {
          event.stopPropagation();
          setTheme(
            event.currentTarget.closest("[data-theme]")?.getAttribute("data-theme") === "day" ? "day" : "night"
          );
        },
        children: /* @__PURE__ */ jsxs2(
          "svg",
          {
            width: "16",
            height: "16",
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: "currentColor",
            strokeWidth: "2.5",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            "aria-hidden": "true",
            focusable: "false",
            children: [
              /* @__PURE__ */ jsx2("circle", { cx: "12", cy: "12", r: "9" }),
              /* @__PURE__ */ jsx2("path", { d: "m11 11 2-.5-2 6h2M13.5 7h.01" })
            ]
          }
        )
      }
    ),
    /* @__PURE__ */ jsx2(AnimatePresence, { children: theme && /* @__PURE__ */ jsx2(
      PhotoInfoModal,
      {
        ...props,
        theme,
        onClose: () => setTheme(null)
      },
      props.photo.file
    ) })
  ] });
}
function PhotoRedrawFailure({ failed }) {
  const still = useReducedMotion() ?? false;
  return /* @__PURE__ */ jsx2(AnimatePresence, { children: failed && /* @__PURE__ */ jsx2(
    motion2.span,
    {
      className: "vu-photo-redraw-failure",
      role: "status",
      initial: { opacity: still ? 1 : 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
      transition: { duration: still ? 0 : 0.14 },
      children: "Redraw failed. This photo stays."
    }
  ) });
}
function PhotoInfoModal({
  playthroughId,
  character: character4,
  friend,
  photo,
  onRedraw,
  theme,
  onClose
}) {
  const [info, setInfo] = useState(null);
  const [recorded, setRecorded] = useState(false);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const photosOn = photoGenerationOn(usePhotoSwitches());
  const id = useId();
  const body = useRef(null);
  const refitFields = useRef(true);
  const dead = busy || !info || !photosOn;
  const redraw = (same) => {
    if (dead || !info) return;
    const prompts = {
      positive: info.positive,
      negative: info.negative,
      ...friend ? { left: info.left ?? "", right: info.right ?? "" } : {}
    };
    onClose();
    onRedraw({ seed: same ? info.seed : void 0, prompts });
  };
  const { host, overlayProps, primaryProps } = useModalShell(
    onClose,
    "panel",
    () => redraw(info?.seed !== void 0)
  );
  useLayoutEffect(() => {
    const fit = (reset2) => {
      for (const key of ["positive", "left", "right", "negative"]) {
        const area = document.getElementById(`${id}-${key}`);
        if (!(area instanceof HTMLTextAreaElement)) continue;
        const style = getComputedStyle(area);
        const border = parseFloat(style.borderTopWidth) + parseFloat(style.borderBottomWidth);
        if (reset2) area.style.height = "auto";
        if (reset2 || area.scrollHeight > area.clientHeight) {
          const height = area.scrollHeight + border;
          area.style.height = `${reset2 ? height : Math.max(height, area.offsetHeight)}px`;
          const overflow = area.scrollHeight - area.clientHeight;
          if (overflow > 0) {
            const fittedHeight = parseFloat(area.style.height);
            area.style.height = `${fittedHeight + overflow + 1}px`;
          }
        }
      }
    };
    const reset = refitFields.current;
    fit(reset);
    refitFields.current = false;
    const element = body.current;
    if (!element) return;
    let width = reset ? -1 : element.clientWidth;
    const observer = new ResizeObserver(() => {
      const nextWidth = element.clientWidth;
      if (Math.abs(nextWidth - width) < 0.5) return;
      width = nextWidth;
      fit(true);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [info, host, id]);
  useEffect(() => {
    let active = true;
    void photoInvoke("info", [playthroughId, character4, friend, photo.tier, photo.scene ?? "", photo.file]).then((result) => {
      if (!active) return;
      if (result.ok) {
        refitFields.current = true;
        setInfo(result.data);
        setRecorded(result.data.recorded);
      } else setError("Could not read the photo prompt.");
    }).catch(() => {
      if (active) setError("Could not read the photo prompt.");
    }).finally(() => {
      if (active) setBusy(false);
    });
    return () => {
      active = false;
    };
  }, [playthroughId, photo.file]);
  const rebuild = async () => {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const result = await photoInvoke("info", [playthroughId, character4, friend, photo.tier, photo.scene ?? "", photo.file, true]);
      if (result.ok) {
        refitFields.current = true;
        setInfo(result.data);
      } else setError("Could not rebuild the photo prompt.");
    } catch {
      setError("Could not rebuild the photo prompt.");
    } finally {
      setBusy(false);
    }
  };
  const field = (key, label, first = false) => /* @__PURE__ */ jsx2(
    TextField,
    {
      id: `${id}-${key}`,
      label,
      value: info?.[key] ?? "",
      multiline: true,
      rows: 3,
      autoFocus: first,
      disabled: busy,
      onChange: (value) => setInfo((before) => before && { ...before, [key]: value })
    }
  );
  if (!host) return null;
  return createPortal(
    /* @__PURE__ */ jsx2(
      motion2.div,
      {
        className: "vu-veil vu-photo-info-veil",
        "data-theme": theme,
        variants: veilIn,
        initial: "hidden",
        animate: "shown",
        exit: "gone",
        ...overlayProps,
        children: /* @__PURE__ */ jsxs2(
          motion2.section,
          {
            className: "vu-photo-info vu-paper",
            role: "dialog",
            "aria-modal": "true",
            "aria-label": "Photo info",
            "aria-busy": busy,
            variants: panelUnderTab,
            ...primaryProps,
            children: [
              /* @__PURE__ */ jsx2(TitleTab, { children: "Photo info" }),
              /* @__PURE__ */ jsx2("div", { className: "vu-photo-info-body", ref: body, children: info ? /* @__PURE__ */ jsxs2(Fragment2, { children: [
                /* @__PURE__ */ jsxs2("p", { className: "vu-photo-info-meta", children: [
                  "Seed: ",
                  info.seed ?? "unknown",
                  " \xB7 Tier: ",
                  info.tier,
                  " \xB7 LoRA:",
                  " ",
                  info.lora ? `${info.lora.name} @ ${info.lora.weight}` : "none",
                  friend ? ` \xB7 With: ${friend.firstName}` : ""
                ] }),
                !info.recorded && /* @__PURE__ */ jsx2("p", { className: "vu-photo-info-note", children: "This prompt was rebuilt from her current tags and settings." }),
                recorded && /* @__PURE__ */ jsx2(
                  motion2.button,
                  {
                    type: "button",
                    className: "vu-btn vu-btn--quiet vu-photo-info-rebuild",
                    disabled: busy,
                    ...gestures2(busy, quietLift2, quietPress2),
                    onClick: () => {
                      void rebuild();
                    },
                    children: "Rebuild"
                  }
                ),
                field("positive", friend ? "Scene" : "Positive", true),
                friend && field("left", character4.firstName),
                friend && field("right", friend.firstName),
                field("negative", "Negative")
              ] }) : /* @__PURE__ */ jsx2("p", { className: "vu-photo-info-note", children: busy ? "Reading the photo prompt\u2026" : "The photo prompt could not be read." }) }),
              /* @__PURE__ */ jsxs2("div", { className: "vu-foot-stack", children: [
                /* @__PURE__ */ jsx2("p", { className: "vu-form-status", role: "status", children: (error || !photosOn) && /* @__PURE__ */ jsxs2(Fragment2, { children: [
                  /* @__PURE__ */ jsx2("span", { className: "vu-form-dot vu-form-dot--warn" }),
                  error || "Photo generation is switched off."
                ] }) }),
                /* @__PURE__ */ jsxs2("div", { className: "vu-foot", children: [
                  /* @__PURE__ */ jsx2(
                    motion2.button,
                    {
                      type: "button",
                      className: "vu-btn vu-btn--quiet",
                      ...gestures2(false, quietLift2, quietPress2),
                      onClick: onClose,
                      children: "Close"
                    }
                  ),
                  /* @__PURE__ */ jsx2(
                    motion2.button,
                    {
                      type: "button",
                      disabled: dead,
                      className: info?.seed === void 0 ? "vu-btn vu-btn--primary vu-btn--panel vu-paper" : "vu-btn vu-btn--quiet",
                      ...gestures2(
                        dead,
                        info?.seed === void 0 ? lift : quietLift2,
                        info?.seed === void 0 ? press : quietPress2
                      ),
                      onClick: () => redraw(false),
                      children: "Redraw with new seed"
                    }
                  ),
                  info?.seed !== void 0 && /* @__PURE__ */ jsx2(
                    motion2.button,
                    {
                      type: "button",
                      disabled: dead,
                      className: "vu-btn vu-btn--primary vu-btn--panel vu-paper",
                      ...gestures2(dead, lift, press),
                      onClick: () => redraw(true),
                      children: "Redraw with same seed"
                    }
                  )
                ] })
              ] })
            ]
          }
        )
      }
    ),
    host
  );
}

// src/renderer/components/PhotoBubble.tsx
import { jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
function PhotoWait() {
  const still = useReducedMotion2() ?? false;
  const loader = usePhotoSwitches().loader;
  return /* @__PURE__ */ jsx3(
    "div",
    {
      className: `vu-bb-photo vu-bb-photo--pending vu-bb-photo--${loader}`,
      role: "img",
      "aria-label": "Sending a photo",
      children: loader === "shimmer" ? /* @__PURE__ */ jsx3("span", { className: "vu-bb-photo__shimmer", "aria-hidden": "true" }) : loader === "dots" ? /* @__PURE__ */ jsx3("span", { className: "vu-bb-photo__dots", "aria-hidden": "true", children: typingDot.map((beat, index) => /* @__PURE__ */ jsx3(motion3.span, { className: "vu-bb-dot", animate: still ? void 0 : beat }, index)) }) : /* @__PURE__ */ jsx3(
        motion3.span,
        {
          className: "vu-bb-photo__bunny",
          "aria-hidden": "true",
          animate: still ? void 0 : { y: [0, -9, 0] },
          transition: bunnyHop,
          children: /* @__PURE__ */ jsx3(BunnyMark, {})
        }
      )
    }
  );
}
function MessagePhoto({
  charId,
  photo,
  onOpen,
  onMissing,
  onRedraw
}) {
  const playthroughId = useGameFacts().playthroughId;
  const character4 = useCharacter(charId);
  const friend = useCharacter(photo.with ?? "");
  const redraw = usePhotoRedraw(photoRedrawKey(playthroughId, charId, photo.file));
  const [opened, setShown] = useState2(photo.tier !== "explicit");
  const [broken, setBroken] = useState2(false);
  useEffect2(() => {
    setBroken(false);
  }, [photo.file]);
  const modOn = usePhotoSwitches().on;
  const explicitBlocked = useExplicitBlocked();
  const locked = photo.tier === "explicit" && explicitBlocked;
  const shown = opened && !locked;
  if (photo.pending) {
    return modOn ? /* @__PURE__ */ jsx3(PhotoWait, {}) : null;
  }
  if (photo.failed || broken || !photo.file || !playthroughId) {
    return /* @__PURE__ */ jsx3("div", { className: "vu-bb-photo vu-bb-photo--failed", children: "The photo never came through." });
  }
  const src = photoUrl(playthroughId, charId, photo.file);
  const eye = /* @__PURE__ */ jsx3(
    "button",
    {
      type: "button",
      className: `vu-bb-photo-eye${shown ? "" : " vu-bb-photo-eye--covered"}`,
      "aria-pressed": !shown,
      "aria-label": shown ? "Cover the photo" : "Uncover the photo",
      title: shown ? "Cover the photo" : "Uncover the photo",
      onClick: () => setShown(!shown),
      disabled: locked,
      children: shown ? /* @__PURE__ */ jsx3(EyeOffIcon, { size: 16 }) : /* @__PURE__ */ jsx3(EyeIcon, { size: 16 })
    }
  );
  const covers = photo.tier === "explicit";
  const image = /* @__PURE__ */ jsx3(
    "img",
    {
      className: `vu-bb-photo${shown ? "" : " vu-bb-photo--veiled"}`,
      src,
      alt: "",
      onError: () => {
        setBroken(true);
        onMissing?.();
      }
    }
  );
  const picture = locked ? /* @__PURE__ */ jsx3("span", { className: "vu-bb-photo-open", title: "Explicit photos are switched off", children: image }) : !shown ? /* @__PURE__ */ jsx3("button", { type: "button", className: "vu-bb-photo-open", onClick: () => setShown(true), children: image }) : onOpen ? /* @__PURE__ */ jsx3("button", { type: "button", className: "vu-bb-photo-open", onClick: () => onOpen(src), children: image }) : image;
  return /* @__PURE__ */ jsxs3("div", { className: "vu-bb-photo-frame", children: [
    redraw === "drawing" ? /* @__PURE__ */ jsx3(PhotoWait, {}) : picture,
    redraw !== "drawing" && covers && !locked && eye,
    shown && character4 && onRedraw && (!photo.with || friend) && /* @__PURE__ */ jsx3(
      PhotoInfoButton,
      {
        playthroughId,
        character: character4,
        friend,
        photo: { ...photo, file: photo.file },
        onRedraw,
        redrawing: redraw === "drawing"
      }
    ),
    /* @__PURE__ */ jsx3(PhotoRedrawFailure, { failed: redraw === "failed" })
  ] });
}
function RerollablePhoto({
  charId,
  photo,
  onReroll,
  onRedraw
}) {
  const photosOn = photoGenerationOn(usePhotoSwitches());
  const [missing, setMissing] = useState2(false);
  if ((photo.failed || missing && !photo.pending) && photo.file && photo.scene) {
    return /* @__PURE__ */ jsxs3("div", { className: "vu-bb-photo vu-bb-photo--failed vu-bb-photo--reroll", children: [
      /* @__PURE__ */ jsx3("span", { children: "Image failed to generate." }),
      photosOn && /* @__PURE__ */ jsx3(
        "button",
        {
          type: "button",
          className: "vu-bb-photo-reroll",
          onClick: () => {
            setMissing(false);
            onReroll();
          },
          children: "Reroll"
        }
      )
    ] });
  }
  return /* @__PURE__ */ jsx3(
    MessagePhoto,
    {
      charId,
      photo,
      onOpen: openShot,
      onMissing: () => setMissing(true),
      onRedraw
    }
  );
}
function PostPhoto({
  charId,
  postId,
  photo
}) {
  const visible = usePhotosVisible();
  useEffect2(() => {
    if (visible) tellAboutFeedPhotos(charId);
  }, [charId, visible]);
  if (!visible) return null;
  return /* @__PURE__ */ jsx3(
    RerollablePhoto,
    {
      charId,
      photo,
      onReroll: () => rerollPostPhoto(charId, postId),
      onRedraw: (options) => {
        void redrawPostPhoto(charId, postId, options);
      }
    }
  );
}
function MessagePhotoBubble({
  photo,
  sender,
  messageId
}) {
  const charId = useViewingThread();
  const visible = usePhotosVisible();
  if (!charId || !visible) return null;
  const side = sender === "player" ? "mine" : "theirs";
  return /* @__PURE__ */ jsx3("div", { className: `vu-bb-bubble vu-bb-bubble--${side} vu-bb-bubble--photo`, children: /* @__PURE__ */ jsx3(
    RerollablePhoto,
    {
      charId,
      photo,
      onReroll: () => rerollMessagePhoto(charId, messageId),
      onRedraw: (options) => {
        void redrawMessagePhoto(charId, messageId, options);
      }
    }
  ) });
}
var openedShot = null;
var shotListeners = /* @__PURE__ */ new Set();
function openShot(src) {
  openedShot = src;
  for (const listener of shotListeners) listener(src);
}
function PhotoLightboxHost() {
  const [shot, setShot] = useState2(openedShot);
  useEffect2(() => {
    shotListeners.add(setShot);
    return () => {
      shotListeners.delete(setShot);
    };
  }, []);
  if (!shot) return null;
  return /* @__PURE__ */ jsx3(Lightbox, { src: shot, onClose: () => openShot(null) });
}
function MessagePhotoAttachment({ message }) {
  const photo = messagePhoto.read(message);
  if (!photo || message.sender === "system") return null;
  return /* @__PURE__ */ jsx3(MessagePhotoBubble, { photo, sender: message.sender, messageId: message.id });
}

// src/renderer/components/PhotoPostSpots.tsx
import { Fragment as Fragment3, jsx as jsx4, jsxs as jsxs4 } from "react/jsx-runtime";
function PhotoPostPicture({ charId, postId }) {
  const post = useFeed(charId).find((post2) => post2.id === postId);
  const photo = post ? postPhoto.read(post) : null;
  const playthroughId = useGameFacts2().playthroughId;
  const redraw = usePhotoRedraw(photoRedrawKey(playthroughId, charId, photo?.file));
  const relationships = useNpcRelationships();
  const friend = useCharacterInfo(photo?.with ?? "");
  const handle = photoFriendHandle(
    relationships ?? {},
    charId,
    photo?.with,
    photo?.with && friend ? { [photo.with]: friend } : {}
  );
  const visible = usePhotosVisible();
  const [tagShown, setTagShown] = useState3(false);
  const tagId = useId2();
  useEffect3(() => {
    setTagShown(false);
  }, [charId, postId, photo?.with, photo?.file, photo?.pending, photo?.failed, handle, visible]);
  if (!photo || !visible) return null;
  const taggable = Boolean(handle && photo.file && !photo.pending && !photo.failed && redraw !== "drawing");
  const showing = taggable && tagShown;
  return /* @__PURE__ */ jsxs4(
    "div",
    {
      className: "vu-bb-post-shot",
      onClickCapture: (event) => {
        if (event.target.closest(".vu-bb-photo-info, .vu-photo-info-veil")) return;
        if (!showing) return;
        event.preventDefault();
        event.stopPropagation();
        setTagShown(false);
      },
      children: [
        /* @__PURE__ */ jsx4(PostPhoto, { charId, postId, photo }),
        taggable && /* @__PURE__ */ jsxs4(Fragment3, { children: [
          /* @__PURE__ */ jsx4(
            "button",
            {
              type: "button",
              className: "vu-bb-photo-tags-toggle",
              "aria-label": showing ? "Hide who is in this photo" : "Show who is in this photo",
              "aria-expanded": showing,
              "aria-controls": tagId,
              onClick: (event) => {
                event.stopPropagation();
                setTagShown((shown) => !shown);
              },
              children: /* @__PURE__ */ jsxs4(
                "svg",
                {
                  width: "14",
                  height: "14",
                  viewBox: "0 0 24 24",
                  fill: "none",
                  stroke: "currentColor",
                  strokeWidth: "2.85",
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  "aria-hidden": "true",
                  focusable: "false",
                  children: [
                    /* @__PURE__ */ jsx4("circle", { cx: "12", cy: "7.5", r: "4" }),
                    /* @__PURE__ */ jsx4("path", { d: "M4.5 20.5a7.5 7.5 0 0 1 15 0" })
                  ]
                }
              )
            }
          ),
          /* @__PURE__ */ jsx4("span", { className: "vu-bb-photo-tag-seat", children: /* @__PURE__ */ jsx4(AnimatePresence2, { children: showing && /* @__PURE__ */ jsxs4(
            motion4.span,
            {
              id: tagId,
              className: "vu-bb-photo-tag",
              role: "status",
              variants: noteIn,
              initial: "hidden",
              animate: "shown",
              exit: "gone",
              children: [
                "@",
                handle
              ]
            }
          ) }) })
        ] })
      ]
    }
  );
}
function PhotoComments({ comments }) {
  const { date = 0, time = 0 } = useClock() ?? {};
  const visible = usePhotosVisible();
  const said = shownComments(comments, date, time);
  if (!visible || said.length === 0) return null;
  return /* @__PURE__ */ jsx4("ul", { className: "vu-bb-comments", children: said.map((comment) => /* @__PURE__ */ jsxs4("li", { className: "vu-bb-comment", children: [
    /* @__PURE__ */ jsx4(
      "span",
      {
        className: "vu-bb-comment-face",
        style: { "--vu-face-hue": hashString(comment.handle) % 360 },
        "aria-hidden": true,
        children: comment.emoji
      }
    ),
    /* @__PURE__ */ jsxs4("span", { className: "vu-bb-comment-said", children: [
      /* @__PURE__ */ jsxs4("span", { className: "vu-bb-comment-who", children: [
        "@",
        comment.handle
      ] }),
      " ",
      comment.text
    ] })
  ] }, comment.id)) });
}

// src/renderer/views/ContactGallery.tsx
import { motion as motion5 } from "motion/react";
import { Fragment as Fragment4, useEffect as useEffect4, useState as useState4 } from "react";
import {
  newestFirst,
  Card,
  gestures as gestures3,
  Locked,
  modIsOn,
  quietLift as quietLift3,
  quietPress as quietPress3,
  useModOn as useModOn2,
  EyeIcon as EyeIcon2,
  EyeOffIcon as EyeOffIcon2
} from "@vx/modkit/renderer";
import { useCharacter as useCharacter2, useGameFacts as useGameFacts3, useConversation, useFeed as useFeed2 } from "@vx/modkit/renderer";

// stub:stub
function EchoPanel() {
  return null;
}

// src/renderer/views/ContactGallery.tsx
import { Fragment as Fragment5, jsx as jsx5, jsxs as jsxs5 } from "react/jsx-runtime";
var SHOT_FILTERS = [
  { key: "all", label: "All" },
  { key: "dm", label: "DM" },
  { key: "feed", label: "Feed" }
];
function landed(photo) {
  return Boolean(photo?.file) && !photo?.pending && !photo?.failed;
}
function Shot({
  charId,
  playthroughId,
  file,
  photo,
  itemId,
  from
}) {
  const tier = photo.tier;
  const character4 = useCharacter2(charId);
  const friend = useCharacter2(photo.with ?? "");
  const redraw = usePhotoRedraw(photoRedrawKey(playthroughId, charId, file));
  const [opened, setShown] = useState4(tier !== "explicit");
  const explicitBlocked = useExplicitBlocked();
  const locked = tier === "explicit" && explicitBlocked;
  const shown = opened && !locked;
  const [missing, setMissing] = useState4(false);
  useEffect4(() => {
    setMissing(false);
  }, [file]);
  if (!playthroughId) return /* @__PURE__ */ jsx5("li", { className: "vu-gallery-item" });
  if (missing) return null;
  const src = photoUrl(playthroughId, charId, file);
  return /* @__PURE__ */ jsxs5(
    motion5.li,
    {
      className: "vu-gallery-item vu-contact-shot-item",
      ...gestures3(locked, quietLift3, quietPress3),
      children: [
        redraw === "drawing" ? /* @__PURE__ */ jsx5("div", { className: "vu-contact-shot-wait", children: /* @__PURE__ */ jsx5(PhotoWait, {}) }) : /* @__PURE__ */ jsxs5(
          "button",
          {
            className: "vu-gallery-cell vu-contact-shot",
            type: "button",
            disabled: locked,
            title: locked ? "Explicit photos are switched off" : void 0,
            onClick: () => shown ? openShot(src) : setShown(true),
            children: [
              /* @__PURE__ */ jsx5(
                "img",
                {
                  className: `vu-gallery-img${shown ? "" : " vu-contact-shot-img--veiled"}`,
                  src,
                  alt: "",
                  decoding: "async",
                  onError: () => setMissing(true)
                }
              ),
              /* @__PURE__ */ jsx5("span", { className: "vu-contact-shot-from", children: from === "dm" ? "DM" : "Feed" })
            ]
          }
        ),
        redraw !== "drawing" && tier === "explicit" && !locked && /* @__PURE__ */ jsx5(
          "button",
          {
            type: "button",
            className: `vu-bb-photo-eye vu-contact-shot-eye${shown ? "" : " vu-bb-photo-eye--covered"}`,
            "aria-pressed": !shown,
            "aria-label": shown ? "Cover the photo" : "Uncover the photo",
            title: shown ? "Cover the photo" : "Uncover the photo",
            onPointerDownCapture: (event) => event.stopPropagation(),
            onClick: (event) => {
              event.stopPropagation();
              setShown(!shown);
            },
            children: shown ? /* @__PURE__ */ jsx5(EyeOffIcon2, { size: 16 }) : /* @__PURE__ */ jsx5(EyeIcon2, { size: 16 })
          }
        ),
        shown && character4 && (!photo.with || friend) && /* @__PURE__ */ jsx5(
          PhotoInfoButton,
          {
            playthroughId,
            character: character4,
            friend,
            photo: { ...photo, file },
            redrawing: redraw === "drawing",
            onRedraw: (options) => {
              if (from === "dm") void redrawMessagePhoto(charId, itemId, options);
              else void redrawPostPhoto(charId, itemId, options);
            }
          }
        ),
        /* @__PURE__ */ jsx5(PhotoRedrawFailure, { failed: redraw === "failed" })
      ]
    }
  );
}
function GalleryPanel({ charId, isContact, theme }) {
  const [filter, setFilter] = useState4("all");
  const visible = usePhotosVisible();
  const echoOn = useModOn2("echo");
  const playthroughId = useGameFacts3().playthroughId;
  const conversation3 = useConversation(charId);
  const feed2 = useFeed2(charId);
  const sent = [...conversation3?.messages ?? []].reverse().flatMap((message) => {
    const photo = messagePhoto.read(message);
    return landed(photo) ? [
      {
        id: message.id,
        itemId: message.id,
        photo,
        file: photo.file,
        from: "dm",
        date: message.date,
        time: message.time
      }
    ] : [];
  });
  const posted = (feed2 ?? []).filter(postIsOut).flatMap((post) => {
    const photo = postPhoto.read(post);
    return landed(photo) ? [
      {
        id: `post:${post.id}`,
        itemId: post.id,
        photo,
        file: photo.file,
        from: "feed",
        date: post.date,
        time: post.time
      }
    ] : [];
  });
  const seen = /* @__PURE__ */ new Set();
  const photos = [...sent, ...posted].sort(newestFirst).filter((shot) => {
    if (seen.has(shot.file)) return false;
    seen.add(shot.file);
    return true;
  });
  const shown = filter === "all" ? photos : photos.filter((shot) => shot.from === filter);
  return /* @__PURE__ */ jsxs5(
    Card,
    {
      className: "vu-contact-card--gallery",
      label: isContact ? `Gallery \xB7 ${photos.length}` : "Gallery",
      children: [
        !isContact ? /* @__PURE__ */ jsx5(Locked, { children: "??? \u2014 Unlocked after adding" }) : !visible ? null : photos.length === 0 ? /* @__PURE__ */ jsx5("p", { className: "vu-contact-empty", children: "No photos yet." }) : /* @__PURE__ */ jsxs5(Fragment5, { children: [
          /* @__PURE__ */ jsx5("div", { className: "vu-contact-tabs vu-contact-shot-filter", children: SHOT_FILTERS.map(({ key, label }, index) => /* @__PURE__ */ jsxs5(Fragment4, { children: [
            index > 0 && /* @__PURE__ */ jsx5("span", { className: "vu-contact-tabs-slash", children: "/" }),
            /* @__PURE__ */ jsx5(
              motion5.button,
              {
                className: `vu-contact-tab${filter === key ? " vu-contact-tab--on" : ""}`,
                type: "button",
                "aria-pressed": filter === key,
                ...gestures3(false, quietLift3, quietPress3),
                onClick: () => setFilter(key),
                children: label
              }
            )
          ] }, key)) }),
          shown.length === 0 ? /* @__PURE__ */ jsx5("p", { className: "vu-contact-empty", children: filter === "dm" ? "No photos in DMs yet." : "No photos on her feed yet." }) : /* @__PURE__ */ jsx5("ul", { className: "vu-gallery-grid vu-contact-shots", children: shown.map((shot) => /* @__PURE__ */ jsx5(
            Shot,
            {
              charId,
              playthroughId,
              file: shot.file,
              photo: shot.photo,
              itemId: shot.itemId,
              from: shot.from
            },
            shot.id
          )) })
        ] }),
        isContact && echoOn && /* @__PURE__ */ jsx5(EchoPanel, { hidden: false, gallery: true, owner: charId, theme })
      ]
    }
  );
}
function PostPhotoLink({
  charId,
  photo
}) {
  const playthroughId = useGameFacts3().playthroughId;
  const visible = usePhotosVisible();
  if (!visible || !playthroughId || !photo?.file) return null;
  const src = photoUrl(playthroughId, charId, photo.file);
  return /* @__PURE__ */ jsxs5(
    motion5.button,
    {
      className: "vu-contact-like vu-contact-photo",
      type: "button",
      "aria-label": "Open the photo",
      ...gestures3(false, quietLift3, quietPress3),
      onClick: () => openShot(src),
      children: [
        /* @__PURE__ */ jsxs5("svg", { viewBox: "0 0 24 24", "aria-hidden": "true", children: [
          /* @__PURE__ */ jsx5("rect", { x: "3", y: "5", width: "18", height: "14", rx: "3" }),
          /* @__PURE__ */ jsx5("circle", { cx: "9", cy: "10", r: "1.6" }),
          /* @__PURE__ */ jsx5("path", { d: "M21 16l-5-5-8 8" })
        ] }),
        "Photo"
      ]
    }
  );
}
function galleryShown() {
  return photosVisible() || modIsOn("echo");
}
function PostPhotoExtra({ charId, post }) {
  const photo = postPhoto.read(post);
  if (!photo?.file) return null;
  return /* @__PURE__ */ jsxs5(Fragment5, { children: [
    " ",
    /* @__PURE__ */ jsx5(PostPhotoLink, { charId, photo })
  ] });
}

// src/renderer/modEntries/photo-feature.ts
bindPhotoOptionReader((option) => modOptionOn(PHOTO_FEATURE_ID, option));
registerPhotoDraft(registerImagePromptDraft);
registerHooks(PHOTO_FEATURE_ID, {
  // A picture opened at full size, over the phone.
  phoneOverlay: PhotoLightboxHost,
  // Her picture in a bubble of its own after a message's words.
  messageAttachment: MessagePhotoAttachment,
  // The photo pill beside a post's like on her contact page.
  contactPostExtra: PostPhotoExtra,
  // Her gallery, as a tab beside Profile on her contact page.
  contactTab: { id: "gallery", label: "Gallery", Panel: GalleryPanel, shown: galleryShown },
  // Her body, as a field in the character editor.
  editorField: BODY_EDITOR_FIELD,
  prompts: {
    dm: {
      lead: true,
      // What she may photograph is settled from the save before she is asked anything.
      lines: ({ character: character4, info, state }) => photoLines(character4, info, {
        ...state,
        canRenderImages: canSendPhotos(),
        noNsfwImages: noExplicitPhotos()
      }),
      fields: () => PHOTO_SCHEMA_FIELDS,
      required: () => PHOTO_SCHEMA_REQUIRED
    },
    // A girl texting first may send a picture with it, under the same gate as her replies.
    "slot-reach-outs": {
      lines: ({ character: character4, info, date }) => photoLines(
        character4,
        info,
        { date, canRenderImages: canSendPhotos(), noNsfwImages: noExplicitPhotos() },
        "reachOut"
      ),
      fields: () => PHOTO_SCHEMA_FIELDS,
      required: () => PHOTO_SCHEMA_REQUIRED
    },
    "slot-posts": {
      // The replies are asked for only while Photo Feature is the mod drawing them.
      lines: () => [
        ...postPhotoLines(canSendPhotos()),
        ...ownsPostComments2(PHOTO_FEATURE_ID) ? postCommentLines(true) : []
      ],
      fields: () => ownsPostComments2(PHOTO_FEATURE_ID) ? POST_PHOTO_SCHEMA_FIELD : { image: POST_PHOTO_SCHEMA_FIELD.image },
      required: () => ownsPostComments2(PHOTO_FEATURE_ID) ? POST_PHOTO_SCHEMA_REQUIRED : ["image"]
    },
    // What each poster owns, for a post whose picture has her in it.
    "slot-poster": {
      lines: ({ character: character4, date, time }) => [
        ...posterPhotoLines(character4, canSendPhotos()),
        ...feedFriendLines(character4, date, time)
      ]
    },
    character: {
      lines: () => bodyBriefLines(),
      fields: () => bodySchemaFields(),
      required: () => bodySchemaRequired()
    }
  },
  // Two of the scene's girls in a group photo, written by the scene's first call.
  requests: { scene: (request, { cast }) => withGroupPhotoRequest(request, cast) },
  afterSceneReply: (ctx) => fileGroupPhoto(ctx),
  dmHistoryNote: (message) => photoStub(
    message,
    (text) => text,
    (charId) => character3(charId)?.firstName
  ),
  characterFromDraft: (draft, { baseAppearance }) => writeBody(bodyOfDraft(draft.body, baseAppearance)),
  // Her streamed decision starts drawing; the completed reply claims that same render.
  dmReplyLead: ({ charId, character: character4, lead, signal }) => startDmPhoto(charId, character4, lead, signal),
  afterDmReply: ({ charId, character: character4, reply }) => void sendPhoto(charId, character4, reply, true),
  // The same for a girl texting first, read off her entry in the slot's opening: a custom
  // endpoint's JSON is not held to the schema, so each field is taken only as the type it should
  // be.
  afterReachOut: ({ charId, character: character4, reply }) => void sendPhoto(
    charId,
    character4,
    {
      sendPhoto: reply.sendPhoto === true,
      photoPrompt: typeof reply.photoPrompt === "string" ? reply.photoPrompt : "",
      ...typeof reply.photoTier === "string" ? { photoTier: reply.photoTier } : {}
    },
    false
  ),
  // The slot's held feed pictures, now that he is busy with something: they draw under the scene
  // and the posts are waiting on the feed when he is free again.
  playerActs: () => startHeldPostPhoto(),
  // A picture whose render outlived the save that asked for it: found on disk, or given up on.
  gameEntered: () => {
    clearEarlyPhotos();
    void settlePendingPhotos();
  },
  fileFeedPost: async (filing, { nudge }) => {
    const reply = filing.reply;
    const shot = await preparePostPhoto(
      filing.charId,
      reply.image,
      // A group photo's friend, set by the mod itself on the post it added, or the friend rolled
      // for her picture as the opening was written.
      typeof reply.groupWith === "string" ? reply.groupWith : feedFriendFor(filing.charId)
    );
    const comments = ownsPostComments2(PHOTO_FEATURE_ID) ? rollComments(filing.charId, reply.comments, shot?.shot.tier) : filing.post.comments ?? [];
    filing.post = {
      ...filing.post,
      likes: postLikes(filing.charId, shot?.shot.tier),
      // Left off entirely where nobody answered, rather than an empty array in every post.
      ...comments.length > 0 ? { comments } : {}
    };
    if (!shot) return;
    filing.post = holdPostPhoto(filing.charId, filing.post, shot, nudge);
    filing.featured = true;
  },
  postLikes: (ask) => {
    if (ask.kind === "ending") return postLikes(ask.author);
    if (ask.kind === "stranger") return strangerLikes(ask.author);
    const playthroughId = ask.playthroughId ?? gameFacts2().playthroughId;
    return rollAudienceLikes({
      reach: reachOf(playthroughId, ask.author, ask.character),
      friends: ask.friends,
      photoTier: "none"
    });
  },
  postVisible: postIsOut,
  postOutAt: (post) => postPhoto.read(post)?.outAt,
  // Strangers' replies under a post, while no mod ahead of it in the list draws them instead.
  postComments: { View: PhotoComments },
  // Her picture under the post's text.
  postPicture: PhotoPostPicture
});
registerTermFiles(PHOTO_FEATURE_ID, async ({ from, to }) => {
  const result = await photoInvoke("carry", [from, to]);
  if (!result.ok) throw Error(result.error.message);
});
