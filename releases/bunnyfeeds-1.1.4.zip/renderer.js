var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/shared/bunnyfeeds.ts
var BUNNYFEEDS, BUNNY_MEMORY_TYPES, MAX_POSTER_REPLIES, WRAP_UP_AFTER;
var init_bunnyfeeds = __esm({
  "src/shared/bunnyfeeds.ts"() {
    BUNNYFEEDS = "bunnyfeeds";
    BUNNY_MEMORY_TYPES = ["loved", "liked", "disliked", "hated"];
    MAX_POSTER_REPLIES = 3;
    WRAP_UP_AFTER = 6;
  }
});

// src/renderer/prompts/bunnyfeedsPrompt.ts
import {
  affectionFor,
  dedupedMemoriesFor,
  emptyFlags,
  relationshipTagOf,
  readerize,
  DEFAULT_PLAYER_STATS,
  fullNameOf
} from "@vx/modkit/shared";
import {
  formatShortGameDate,
  objectSchema,
  relationshipLines,
  memoryLines,
  profileLines,
  spaced
} from "@vx/modkit/renderer";
function slotCommentLines() {
  return [
    'Each post also carries "comments": what other students replied underneath it, in their own voices: exactly as many of her followers as CROWD says for that post, and the friend REPLIERS names under it on top of those.',
    `A reply is either the friend of hers REPLIERS names under that post, if it names one, or one of her followers. For that friend, "from" is her key exactly as written there, and she types the way she would actually type to a friend \u2014 her own words, slang and emoji, not a generic commenter's. She replies besides the followers CROWD counts, unless she would leave it.`,
    'A follower is one of the four thousand students on campus who follows her account: a fan, a classmate, somebody from her club or her dorm. "from" is an empty string; she is friendly with the poster at most, never close, so no inside jokes and nothing about her private life, and she is not the reader. Followers reply the way a public feed does: mostly friendly, sometimes flirty, sometimes roasting, now and then a hater, never more than one mean reply under a post. No reply is the reader. No handles and no @s in "text" \u2014 just what each one said. Each typed it on her phone and has only read the post: nobody hears, sees or laughs out loud at anybody here.',
    "They answer the post they are under. A reply to a picture is a reply to that picture; one under a picture with skin in it reads like a public feed at its least charming, which is strangers being obvious at somebody who did not ask."
  ];
}
function slotCommentsField() {
  return {
    type: "array",
    items: {
      type: "object",
      additionalProperties: false,
      required: ["from", "text"],
      properties: { from: { type: "string" }, text: { type: "string" } }
    }
  };
}
function standingWords(standing, poster) {
  if (standing === "friend") return `${poster}'s friend`;
  if (standing === "enemy") return `${poster}'s enemy: they can't stand each other`;
  return `barely knows ${poster}`;
}
function crowdBlock(posters) {
  if (posters.length === 0) return [];
  const many = (n) => n === 0 ? "no followers" : n === 1 ? "1 follower" : `${n} followers`;
  return [
    "CROWD",
    ...posters.map(
      ({ name, charKey, words, picture }) => words === picture ? `- ${name}'s post ("${charKey}"): ${many(words)}.` : `- ${name}'s post ("${charKey}"): ${many(words)}, or ${many(picture)} if it carries a picture.`
    )
  ];
}
function replierBlock(posters) {
  const posting = new Set(posters.map(({ charKey }) => charKey));
  const described = /* @__PURE__ */ new Set();
  const voices = [];
  const under = [];
  for (const { character: character3, charKey, repliers } of posters) {
    if (repliers.length === 0) continue;
    const names = repliers.map(
      ({ character: other, charKey: key, standing }) => `${other.firstName} ("${key}", ${standingWords(standing, character3.firstName)})`
    );
    under.push(`- Under ${character3.firstName}'s post ("${charKey}"): ${names.join(", ")}`);
    for (const { character: other, charKey: key } of repliers) {
      if (described.has(key)) continue;
      described.add(key);
      const { withFriends } = other.behavior;
      voices.push(
        posting.has(key) ? `${fullNameOf(other)} \u2014 "from": "${key}": described under LOREBOOK.` : `${fullNameOf(other)} \u2014 "from": "${key}": ${other.personality}`,
        ...withFriends ? [`  With friends: ${withFriends}`] : []
      );
    }
  }
  if (under.length === 0) return [];
  return [
    "REPLIERS",
    "Besides her followers, only the girl named under a post may reply to it, in her own voice, as her friend.",
    ...under,
    "",
    ...voices
  ];
}
function feedPersona(lessNsfwText2) {
  return [
    ...PERSONA_LINES,
    ...lessNsfwText2 ? ["Keep every comment clean: flirting at most, nothing sexual."] : []
  ].join("\n");
}
function characterBlock(input) {
  const entries = [];
  const named = /* @__PURE__ */ new Set();
  for (const thread of input.threads) {
    const { character: character3, info, charKey, texted } = thread;
    if (named.has(charKey)) continue;
    named.add(charKey);
    entries.push([
      `${fullNameOf(character3)} \u2014 "char": "${charKey}"`,
      ...profileLines(character3, info.flags ?? emptyFlags()),
      ...relationshipLines(
        character3,
        info.flags ?? emptyFlags(),
        info.nameKnown,
        affectionFor(info, input.date, character3),
        info,
        input.stats ?? DEFAULT_PLAYER_STATS,
        { texting: true, texted },
        { date: input.date, offset: info.moodCycleOffset ?? 0 }
      ),
      ...memoryLines(
        character3,
        dedupedMemoriesFor(info).slice(-3),
        info.textMemory,
        input.season
      )
    ]);
  }
  for (const thread of input.threads) {
    const quiet = (thread.silent ?? []).map(({ replier }) => replier);
    for (const { character: character3, charKey, info } of [...thread.repliers, ...quiet]) {
      if (named.has(charKey)) continue;
      named.add(charKey);
      const { withFriends, withStrangers } = character3.behavior;
      entries.push([
        `${fullNameOf(character3)} \u2014 "from": "${charKey}"`,
        character3.personality,
        ...withFriends ? [`With friends: ${withFriends}`] : [],
        ...withStrangers ? [`With people she barely knows: ${withStrangers}`] : [],
        ...readerTieLines(character3, info, input.date)
      ]);
    }
  }
  if (entries.length === 0) return [];
  return [
    "LOREBOOK",
    "",
    ...entries.flatMap((entry, index) => index === 0 ? entry : ["", ...entry])
  ];
}
function readerTieLines(character3, info, date) {
  const flags = info?.flags ?? emptyFlags();
  const memories = info ? dedupedMemoriesFor(info) : [];
  const latest = memories[memories.length - 1];
  const remembered = latest ? `What she last remembers of him: ${character3.firstName} ${latest.type} that ${readerize(latest.desc)}.` : null;
  if (!info || !flags.hasMet) {
    return remembered ? ["She has never met the reader in person and knows him only from the feed.", remembered] : ["She has never met the reader: she knows him only as the name on his comment."];
  }
  return [
    `Her and the reader: ${relationshipTagOf(flags, affectionFor(info, date, character3))}.`,
    ...remembered ? [remembered] : []
  ];
}
function threadLines(thread, season) {
  const { character: character3, charKey, post } = thread;
  const name = character3.firstName;
  const when = `${formatShortGameDate(post.date, season)}, ${post.time === 0 ? "morning" : "evening"}`;
  const repliers = thread.repliers.map(
    ({ character: other, charKey: key, standing }) => `${other.firstName} ("${key}", ${standingWords(standing, name)})`
  );
  return [
    `POST ${thread.postRef} by ${fullNameOf(character3)} ("${charKey}"), ${when}: ${post.text}`,
    ...post.picture ? [`Her picture${post.pictureWith ? `, with ${post.pictureWith}` : ""}: ${post.picture}`] : [],
    ...thread.lines.map(
      (line) => `- ${line.ref}${line.replyTo ? ` (answering ${line.replyTo})` : ""} \u2014 ${line.who}: ${line.text}`
    ),
    ...thread.mustAnswer.length > 0 ? [`${name} answers every one of: ${thread.mustAnswer.join(", ")}.`] : [],
    ...thread.mayAnswer.length > 0 && thread.mayAnswerCount > 0 ? [
      `${name} may answer up to ${thread.mayAnswerCount} of: ${thread.mayAnswer.join(", ")}. Answering none is fine.`
    ] : [],
    ...(thread.tagged ?? []).map(({ ref, name: tagged }) => {
      const standing = thread.repliers.find(({ character: girl }) => girl.firstName === tagged)?.standing;
      return `The reader tagged ${tagged}${standing ? ` (${standingWords(standing, name)})` : ""} in ${ref}, so she answers it too.`;
    }),
    ...(thread.answersBack ?? []).map(
      ({ ref, who }) => `The reader answered ${who} directly in ${ref}, so ${who} answers him back.`
    ),
    ...(thread.silent ?? []).map(
      ({ ref, replier }) => `The reader answered ${replier.character.firstName} ("${replier.charKey}") directly in ${ref}. She sees it but does not answer it, and writes nothing here.`
    ),
    ...thread.windingDown ? [
      `This thread has run long. ${name} keeps her answers short and starts wrapping it up in her own way, the way people drift out of a thread that has gone on too long. Nobody else reacts here besides anyone the reader tagged.`
    ] : thread.mustAnswer.length > 0 ? [joinersLine(repliers, thread.follower, thread.postRef)] : []
  ];
}
function joinersLine(repliers, follower, postRef) {
  const joining = [...repliers, ...follower ? ["one of her followers"] : []];
  const named = joining.length > 1 ? `${joining.slice(0, -1).join(", ")} and ${joining[joining.length - 1]}` : joining[0];
  return joining.length > 0 ? `Besides her, ${named} may react here: to the reader, to each other, to her, or to the post itself as ${postRef}.` : "Nobody else reacts under this post this round besides whoever is named above.";
}
function buildFeedThreadsPrompt(input, setting, reader) {
  const user = [
    ...spaced(characterBlock(input)),
    "THREADS",
    "",
    ...input.threads.flatMap(
      (thread, index) => index === 0 ? threadLines(thread, input.season) : ["", ...threadLines(thread, input.season)]
    ),
    "",
    "YOUR TURN",
    `Fill "replies" with the new comments under these posts. "to" is the ref of the comment it answers, or the post's own ref for a new comment on the post, exactly as written. "from" is who writes it: the poster's or another girl's key exactly as written in LOREBOOK, or an empty string for one of her followers. A follower is one of the four thousand students on campus who follows her account: a fan, a classmate, somebody from her club or her dorm. Followers are friendly with her at most, never close: no inside jokes, nothing about her private life. A follower named above as answering the reader back writes "from" as that handle exactly, @ included.`,
    "The poster answers exactly what her post says she answers, as herself: how she talks, how she feels about whoever she is answering, and what she remembers of the reader. A girl answering the reader can flirt back, tease, brush him off or ignore the question, whatever she actually would.",
    `Under each post only who THREADS names there reacts: the poster, the girls it names, and a follower where it says one may. Whoever may react can still leave it; none is fine. They react to the reader's comment, to another comment in the thread, or to the post itself. The thread is a conversation, not a line of people answering him: they can talk to each other and to the poster too. Nobody else speaks for the reader, nobody answers herself, and nobody @s anybody or writes a handle in "text".`,
    "Everybody replies however they actually would. A girl goes by her personality, how she stands with the poster and what she knows of the reader: she can flirt, tease, hype, roast or brush him off. The poster and a girl who is her enemy are never warm to each other, however sweet either is with everyone else: cool, catty or passive-aggressive, each in her own manner, and never a compliment that is not backhanded. Followers have the whole range a public feed has: mostly friendly, sometimes flirty, sometimes roasting her or the reader, now and then a hater. Never more than one mean comment under a post.",
    "All of this happens in front of the whole campus, and everybody types like it. Nobody settles anything here: no meeting up, no date, no time or place agreed, whoever suggests it. A girl who likes the idea can say so in a way that keeps it open, or tell him to message her; one who does not can laugh it off. Nothing she would only say to him alone goes in a comment: feelings she has not shown in public, what passed between them in private, anything explicit. Followers know nothing about the reader beyond the comment in front of them.",
    'Fill "memories" with one entry per poster the reader commented under, one per other girl who answers him in "replies", and one per girl who sees his answer without answering it, whether or not she has met him, saying what she made of what he said: "char" is her key, "type" how she felt about it, and "desc" what happened, in a few words, starting with "the reader". Say only what he said or did: never the post, whose post it was, or where it happened, since the game adds that.'
  ].join("\n");
  return {
    system: [feedPersona(input.lessNsfwText), "", "SETTING", setting, "", "READER", reader].join(
      "\n"
    ),
    user,
    schema: SCHEMA,
    cacheKey: input.playthroughId,
    kind: "texting"
  };
}
var SCHEMA, PERSONA_LINES, TEXT_LEDGER_FEED_LINES;
var init_bunnyfeedsPrompt = __esm({
  "src/renderer/prompts/bunnyfeedsPrompt.ts"() {
    SCHEMA = objectSchema("feed_threads", ["replies", "memories"], {
      replies: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          required: ["to", "from", "text"],
          properties: {
            to: { type: "string" },
            from: { type: "string" },
            text: { type: "string" }
          }
        }
      },
      memories: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          required: ["char", "type", "desc"],
          properties: {
            char: { type: "string" },
            type: { type: "string", enum: ["loved", "liked", "disliked", "hated"] },
            desc: { type: "string" }
          }
        }
      }
    });
    PERSONA_LINES = [
      "You write the comment sections of a college social feed: what people type under each other's posts on their phones.",
      "Every comment is somebody real typing with their thumbs, in their own voice. Short, casual, lowercase if that is how they type, slang, typos and emoji where they fit. One line, two at most.",
      "Nobody is in the same room: they only read what the others typed. Nobody sees a face or hears a laugh, so nobody mentions giggling, looks or tone of voice; a laugh is typed or an emoji, and a reaction is to the words on the screen.",
      "You know these people well and keep each of them sounding like herself, so a reader could tell who wrote a comment with the name covered.",
      'You hate generic, robotic comments. Nobody writes "Great post!" or explains a joke. People tease, flirt, hype, deflect and get petty, and leave things unsaid.',
      "The reader is the exception: he types however he types, in plain words, short or in broken English. The girls read him for what he means: none of them corrects, mocks or judges his grammar, his spelling or how little he wrote (a one-word comment is a fine comment), and how a girl feels about his comment goes by what he said, never how he said it. A follower may now and then poke fun at a badly mangled comment, the way strangers online do, and that counts as the post's one mean comment.",
      "You never use semicolons or em dashes.",
      "You always return a single, fully-formed JSON object matching the provided schema exactly."
    ];
    TEXT_LEDGER_FEED_LINES = [
      "THE FEED",
      `The reader also comments under these girls' feed posts, in public, and those comments are noted elsewhere. A message that brings up one of her posts or a comment on it is texting about the feed: note only what was said in these messages, never the comments themselves, and never call something "over text" that happened on the feed.`
    ];
  }
});

// src/shared/bunnyfeedsCrowd.ts
import { hasTrait } from "@vx/modkit/shared";
function hashUnit(seed) {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return (hash >>> 0) % 1e5 / 1e5;
}
function followingOf(playthroughId, charId, character3) {
  const roll = hashUnit(`${playthroughId ?? "unsaved"}:${charId}`);
  const reach = REACH_FLOOR + Math.round(REACH_SPAN * roll * roll);
  return hasTrait(character3, "Terminally Online") ? reach * 2 : reach;
}
function rollCrowd(input, rand = Math.random) {
  const rate = input.picture ? TALKERS_PER_HUNDRED.picture : TALKERS_PER_HUNDRED.words;
  const talkers = input.following / 100 * rate;
  const drawn = Math.floor(rand() * (talkers + 1) + rand() * talkers * 0.6);
  return Math.min(drawn, MAX_CROWD);
}
function planCrowd(following, rand = Math.random) {
  const words = rollCrowd({ picture: false, following }, rand);
  return { words, picture: Math.max(words, rollCrowd({ picture: true, following }, rand)) };
}
function followerChance(following) {
  const reach = Math.min(1, Math.max(0, (following - REACH_FLOOR) / REACH_SPAN));
  return 0.3 + 0.3 * reach;
}
function oneOf(ids, rand) {
  return ids.length > 0 ? ids[Math.floor(rand() * ids.length)] : null;
}
function pickOpeningFriend(friends, rand = Math.random) {
  return friends.length > 0 && rand() < OPENING_FRIEND_CHANCE ? oneOf(friends, rand) : null;
}
function pickJoiningFriend(mutuals, others, rand = Math.random) {
  if (mutuals.length > 0 && rand() < MUTUAL_FRIEND_CHANCE) return oneOf(mutuals, rand);
  if (others.length > 0 && rand() < FRIEND_CHANCE) return oneOf(others, rand);
  return null;
}
var REACH_FLOOR, REACH_SPAN, MAX_CROWD, TALKERS_PER_HUNDRED, OPENING_FRIEND_CHANCE, MUTUAL_FRIEND_CHANCE, FRIEND_CHANCE, ADDRESSED_GIRL_CHANCE, ADDRESSED_FOLLOWER_CHANCE;
var init_bunnyfeedsCrowd = __esm({
  "src/shared/bunnyfeedsCrowd.ts"() {
    REACH_FLOOR = 40;
    REACH_SPAN = 460;
    MAX_CROWD = 8;
    TALKERS_PER_HUNDRED = { words: 1, picture: 1.6 };
    OPENING_FRIEND_CHANCE = 0.35;
    MUTUAL_FRIEND_CHANCE = 0.6;
    FRIEND_CHANCE = 0.2;
    ADDRESSED_GIRL_CHANCE = 0.7;
    ADDRESSED_FOLLOWER_CHANCE = 0.5;
  }
});

// src/renderer/stores/bunnyfeedsReadContext.ts
import { useSyncExternalStore } from "react";
import {
  charKeyOf,
  DEFAULT_PLAYER_STATS as DEFAULT_PLAYER_STATS2
} from "@vx/modkit/shared";
import {
  character,
  characterInfo,
  conversation,
  rosterIds,
  clock,
  gameFacts,
  npcRelationships,
  playerStats,
  playerProfilePicture,
  currentRun,
  subscribeCharacter,
  subscribeCharacterInfo,
  subscribeConversation,
  subscribeRosterIds,
  subscribeClock,
  subscribeNpcRelationships,
  subscribePlayerStats,
  subscribePlayerProfilePicture,
  useGameFacts
} from "@vx/modkit/renderer";
function readBunnyfeedsContext() {
  const ids = rosterIds({ alumni: true });
  const chars = rosterIds();
  const definitions = ids.map(character);
  const infos = ids.map(characterInfo);
  const chats = ids.map(conversation);
  const at = clock();
  const facts = gameFacts();
  const pairs = npcRelationships();
  const stats = playerStats();
  const picture = playerProfilePicture();
  const next = [
    ids,
    chars,
    ...definitions,
    ...infos,
    ...chats,
    at,
    facts.playthroughId,
    facts.readerName,
    pairs,
    stats,
    picture,
    currentRun()
  ];
  if (value && next.length === keys.length && next.every((one, i) => one === keys[i])) return value;
  const characters = /* @__PURE__ */ Object.create(null);
  const charInfo = /* @__PURE__ */ Object.create(null);
  const conversations = /* @__PURE__ */ Object.create(null);
  const charKeyToId = /* @__PURE__ */ Object.create(null);
  ids.forEach((id, i) => {
    const definition = definitions[i];
    if (definition) {
      characters[id] = definition;
      charKeyToId[charKeyOf(definition.firstName, definition.lastName)] = id;
    }
    if (infos[i]) charInfo[id] = infos[i];
    if (chats[i]) conversations[id] = chats[i];
  });
  keys = next;
  value = {
    playthroughId: facts.playthroughId,
    playerFirstName: facts.readerName,
    date: at?.date ?? 0,
    time: at?.time ?? 0,
    calendar: { season: at?.season ?? "spring" },
    chars,
    characters: Object.freeze(characters),
    charInfo: Object.freeze(charInfo),
    charKeyToId: Object.freeze(charKeyToId),
    npcRelationships: pairs,
    stats: stats ?? DEFAULT_PLAYER_STATS2,
    profilePicture: picture,
    bunnyboard: { conversations: Object.freeze(conversations) }
  };
  return value;
}
function followBunnyfeedsContext(onChange) {
  let records = [];
  const bind = () => {
    records.forEach((stop) => stop());
    records = rosterIds({ alumni: true }).flatMap((id) => [
      subscribeCharacter(id, onChange),
      subscribeCharacterInfo(id, onChange),
      subscribeConversation(id, onChange)
    ]);
  };
  bind();
  const stops = [
    subscribeRosterIds(() => {
      bind();
      onChange();
    }, { alumni: true }),
    subscribeRosterIds(onChange),
    subscribeClock(onChange),
    subscribeNpcRelationships(onChange),
    subscribePlayerStats(onChange),
    subscribePlayerProfilePicture(onChange)
  ];
  return () => {
    records.forEach((stop) => stop());
    stops.forEach((stop) => stop());
  };
}
function useBunnyfeedsContext(select) {
  useGameFacts();
  return select(useSyncExternalStore(
    followBunnyfeedsContext,
    readBunnyfeedsContext,
    readBunnyfeedsContext
  ));
}
var keys, value;
var init_bunnyfeedsReadContext = __esm({
  "src/renderer/stores/bunnyfeedsReadContext.ts"() {
    keys = [];
  }
});

// src/renderer/stores/bunnyfeedsData.ts
import { recordField, saveField } from "@vx/modkit/renderer";
import { globalSlotOf } from "@vx/modkit/shared";
function objectOf(value2) {
  return value2 !== null && typeof value2 === "object" && !Array.isArray(value2) ? value2 : {};
}
function idOf(value2) {
  return typeof value2 === "string" && value2.trim() ? value2 : void 0;
}
function normalizeComment(stored, legacy) {
  const value2 = objectOf(stored !== void 0 ? stored : legacy);
  const charId = idOf(value2.charId);
  const replyTo = idOf(value2.replyTo);
  const tags = Array.isArray(value2.tags) ? value2.tags.filter((tag) => typeof tag === "string" && Boolean(tag.trim())) : [];
  return {
    ...charId ? { charId } : {},
    ...value2.player === true ? { player: true } : {},
    ...value2.read === true ? { read: true } : {},
    ...replyTo ? { replyTo } : {},
    ...tags.length ? { tags } : {}
  };
}
function heldMemory(value2) {
  const one = objectOf(value2);
  const charId = idOf(one.charId);
  const type = BUNNY_MEMORY_TYPES.find((type2) => type2 === one.type);
  if (!charId || !type || !Number.isSafeInteger(one.at) || typeof one.desc !== "string" || !one.desc.trim()) return [];
  const posterId = idOf(one.posterId);
  return [{
    charId,
    at: one.at,
    type,
    desc: one.desc,
    ...posterId ? { posterId } : {}
  }];
}
function normalizePost(stored, legacy) {
  const value2 = objectOf(stored !== void 0 ? stored : legacy);
  return {
    ...Number.isSafeInteger(value2.threadedThrough) ? { threadedThrough: value2.threadedThrough } : {},
    ...Array.isArray(value2.heldMemories) ? { heldMemories: value2.heldMemories.flatMap(heldMemory) } : {}
  };
}
function threadWork(comments, posterId, threadedThrough, now) {
  if (!comments || comments.length === 0) return null;
  const player = comments.filter(
    (one) => commentData.read(one).player && one.at <= now && !comments.some((reply) => commentData.read(reply).replyTo === one.id && commentData.read(reply).charId === posterId)
  );
  if (player.length === 0) return null;
  const since = threadedThrough ?? Number.NEGATIVE_INFINITY;
  const answeredOthers = comments.filter((one) => {
    const data = commentData.read(one);
    if (data.charId !== posterId || !data.replyTo) return false;
    const target = comments.find((target2) => target2.id === data.replyTo);
    return !target || !commentData.read(target).player;
  }).length;
  const othersLeft = Math.max(0, MAX_POSTER_REPLIES - answeredOthers);
  const others = othersLeft > 0 ? comments.filter(
    (one) => one.at > since && one.at <= now && !commentData.read(one).player && commentData.read(one).charId !== posterId
  ) : [];
  const windingDown = comments.filter(
    (one) => commentData.read(one).player && one.at <= now
  ).length >= WRAP_UP_AFTER;
  return { player, others, othersLeft, windingDown };
}
function carriedThread(post, days) {
  const data = postData.read(post);
  if (data.threadedThrough === void 0 && !data.heldMemories) return post;
  const back = globalSlotOf(days, 0);
  return postData.with(post, {
    ...data.threadedThrough !== void 0 ? { threadedThrough: data.threadedThrough - back } : {},
    ...data.heldMemories ? {
      heldMemories: data.heldMemories.map((memory) => ({ ...memory, at: memory.at - back }))
    } : {}
  });
}
function feedNotes(posts, now) {
  const notes = posts.flatMap(({ posterId, post }) => {
    const said = (post.comments ?? []).filter((one) => one.at <= now);
    const his = new Map(said.filter((one) => commentData.read(one).player).map((one) => [one.id, one]));
    return said.flatMap((one) => {
      const data = commentData.read(one);
      const target = data.replyTo && !data.player ? his.get(data.replyTo) : void 0;
      if (!target) return [];
      const kind = data.charId === posterId ? "poster" : "reply";
      return [{ posterId, postId: post.id, comment: one, kind }];
    });
  });
  return notes.sort((a, b) => b.comment.at - a.comment.at);
}
function feedNoteUnread(note, readThrough) {
  return !commentData.read(note.comment).read && note.comment.at > (readThrough ?? Number.NEGATIVE_INFINITY);
}
function unreadFeedNotes(notes, readThrough) {
  return notes.filter((note) => feedNoteUnread(note, readThrough)).length;
}
var commentData, postData, feedData;
var init_bunnyfeedsData = __esm({
  "src/renderer/stores/bunnyfeedsData.ts"() {
    init_bunnyfeeds();
    commentData = recordField(BUNNYFEEDS, {
      empty: {},
      legacy: ["charId", "player", "read", "replyTo", "tags"],
      normalize: normalizeComment
    });
    postData = recordField(BUNNYFEEDS, {
      empty: {},
      legacy: ["threadedThrough", "heldMemories"],
      normalize: normalizePost
    });
    feedData = saveField(BUNNYFEEDS, {
      empty: {},
      normalize: (stored) => {
        const value2 = objectOf(stored);
        return Number.isSafeInteger(value2.readThrough) ? { readThrough: value2.readThrough } : {};
      },
      carry: (value2) => value2
    });
  }
});

// src/renderer/stores/bunnyfeedsReplies.ts
import {
  fallbackHandleOf,
  globalSlotOf as globalSlotOf2,
  areNpcFriends,
  npcFriendsOf,
  npcPairOf,
  zoneOf,
  charKeyOf as charKeyOf2
} from "@vx/modkit/shared";
import {
  drawFeedHandles,
  drawFeedEmoji,
  FEED_EMOJI,
  FEED_HANDLE_POOL,
  isFeedContact
} from "@vx/modkit/renderer";
function planSlotCrowds(charIds) {
  const game = readBunnyfeedsContext();
  plannedCrowds.clear();
  for (const charId of charIds) {
    plannedCrowds.set(
      charId,
      planCrowd(followingOf(game.playthroughId, charId, game.characters[charId]))
    );
  }
  return plannedCrowds;
}
function standingOf(relationships, posterId, charId) {
  const pair = npcPairOf(relationships, posterId, charId);
  if (!pair) return "barely";
  const zone = zoneOf(pair.affinity);
  return zone === "friends" ? "friend" : zone === "enemies" ? "enemy" : "barely";
}
function replierOf(charId, posterId, relationships) {
  const game = readBunnyfeedsContext();
  const character3 = game.characters[charId];
  if (!character3) return null;
  return {
    character: character3,
    charKey: charKeyOf2(character3.firstName, character3.lastName),
    standing: standingOf(relationships, posterId, charId),
    info: game.charInfo[charId]
  };
}
function repliersFor(posterId, relationships) {
  const friends = npcFriendsOf(relationships, posterId, readBunnyfeedsContext().chars);
  const picked = pickOpeningFriend(friends);
  const replier = picked ? replierOf(picked, posterId, relationships) : null;
  return replier ? [replier] : [];
}
function joiningFriendOf(posterId, relationships) {
  const game = readBunnyfeedsContext();
  const friends = npcFriendsOf(relationships, posterId, game.chars);
  const mutuals = friends.filter((id) => isFeedContact(game.charInfo[id]));
  const others = friends.filter((id) => !mutuals.includes(id));
  const picked = pickJoiningFriend(mutuals, others);
  return picked ? replierOf(picked, posterId, relationships) : null;
}
function writtenComments(raw, posterId) {
  if (!Array.isArray(raw)) return [];
  const game = readBunnyfeedsContext();
  return raw.flatMap((one) => {
    if (typeof one === "string") return [{ text: one }];
    if (!one || typeof one !== "object") return [];
    const { from, text } = one;
    if (typeof text !== "string") return [];
    const charId = typeof from === "string" && from ? game.charKeyToId[from.trim()] : void 0;
    if (from && !charId) console.warn(`[bunnyfeeds] reply from unknown key "${String(from)}"`);
    if (charId && charId !== posterId) {
      return areNpcFriends(game.npcRelationships, posterId, charId) ? [{ charId, text }] : [];
    }
    return [{ text }];
  });
}
function rollFeedComments(charId, written, picture = false) {
  const lines = (written ?? []).map((one) => ({ ...one, text: one.text.trim() })).filter((one) => one.text);
  if (lines.length === 0) return [];
  const game = readBunnyfeedsContext();
  const planned = plannedCrowds.get(charId);
  plannedCrowds.delete(charId);
  const allowed = planned ? planned[picture ? "picture" : "words"] : rollCrowd({
    picture,
    following: followingOf(game.playthroughId, charId, game.characters[charId])
  });
  const isFriend = (one) => Boolean(one.charId && game.characters[one.charId]);
  let followers = 0;
  let friends = 0;
  const kept = lines.filter(
    (one) => isFriend(one) ? friends++ < 1 : followers++ < allowed
  );
  if (kept.length === 0) return [];
  const strangers = kept.filter((one) => !isFriend(one)).length;
  const handles = drawFeedHandles(strangers);
  const emoji = drawFeedEmoji(strangers);
  const posted = globalSlotOf2(game.date, game.time);
  let drawn = 0;
  return kept.map((one, i) => {
    const at = posted + Math.min(2, Math.floor(i / 3));
    const replier = one.charId ? game.characters[one.charId] : void 0;
    if (one.charId && replier) {
      return commentData.with({
        id: crypto.randomUUID(),
        handle: game.charInfo[one.charId]?.handle ?? fallbackHandleOf(replier.firstName, replier.lastName),
        emoji: "",
        text: one.text,
        at
      }, { charId: one.charId });
    }
    const n = drawn++;
    return {
      id: crypto.randomUUID(),
      handle: handles[n] ?? FEED_HANDLE_POOL[0].handle,
      emoji: emoji[n] ?? FEED_EMOJI[0],
      text: one.text,
      at
    };
  });
}
var plannedCrowds;
var init_bunnyfeedsReplies = __esm({
  "src/renderer/stores/bunnyfeedsReplies.ts"() {
    init_bunnyfeedsCrowd();
    init_bunnyfeedsReadContext();
    init_bunnyfeedsData();
    plannedCrowds = /* @__PURE__ */ new Map();
  }
});

// src/renderer/stores/bunnyfeedsMemory.ts
import { memoryStatusLine } from "@vx/modkit/shared";
import { addMemory, currentRun as currentRun2, modIsOn, modOptionOn } from "@vx/modkit/renderer";
function whereTag(charId, posterId) {
  if (!posterId) return FEED_MEMORY_TAG;
  if (posterId === charId) return ", on her post";
  const poster = readBunnyfeedsContext().characters[posterId];
  return poster ? `, under ${poster.firstName}'s post` : FEED_MEMORY_TAG;
}
function fileFeedMemory(charId, entry, where, run) {
  const onFeed = (memory) => FEED_MEMORY_END.test(memory.desc);
  return addMemory(BUNNYFEEDS, charId, { ...entry, desc: `${entry.desc}${where}` }, {
    run,
    replacing: onFeed,
    replacingUnmarked: onFeed
  });
}
function holdFeedMemories(posterId, postId, memories, run = currentRun2()) {
  if (memories.length === 0) return { ok: true, data: null };
  return postData.update({ kind: "post", charId: posterId, postId }, (data) => ({
    ...data,
    heldMemories: [...data.heldMemories ?? [], ...memories]
  }), { run });
}
function sameHeld(a, b) {
  return a.charId === b.charId && a.at === b.at && a.type === b.type && a.desc === b.desc && a.posterId === b.posterId;
}
function fileDueFeedMemories(through, run = currentRun2()) {
  const game = readBunnyfeedsContext();
  for (const posterId of game.chars) {
    for (const post of game.charInfo[posterId]?.feed ?? []) {
      const due = (postData.read(post).heldMemories ?? []).filter((one) => one.at <= through);
      for (const one of due) {
        const result = fileFeedMemory(one.charId, {
          date: game.date,
          type: one.type,
          desc: one.desc
        }, whereTag(one.charId, one.posterId), run);
        if (!result.ok) continue;
        postData.update({ kind: "post", charId: posterId, postId: post.id }, (data) => {
          const held = data.heldMemories ?? [];
          const at = held.findIndex((entry) => sameHeld(entry, one));
          if (at < 0) return void 0;
          const left = held.filter((_, index) => index !== at);
          const { heldMemories: _done, ...rest } = data;
          return left.length ? { ...rest, heldMemories: left } : rest;
        }, { run });
      }
    }
  }
}
function dueFeedMemories(through) {
  const game = readBunnyfeedsContext();
  return game.chars.flatMap((charId) => (game.charInfo[charId]?.feed ?? []).flatMap(
    (post) => (postData.read(post).heldMemories ?? []).filter((one) => one.at <= through)
  ));
}
function feedStatusLines(through) {
  if (!modIsOn(BUNNYFEEDS) || !modOptionOn(BUNNYFEEDS, "announce")) return [];
  const game = readBunnyfeedsContext();
  return dueFeedMemories(through).map(({ charId, type, desc, posterId }) => {
    const character3 = game.characters[charId];
    const name = character3 && game.charInfo[charId]?.nameKnown ? character3.firstName : "???";
    return memoryStatusLine(name, { type, desc: `${desc}${whereTag(charId, posterId)}` });
  });
}
function textLedgerFeedLines(charKeys) {
  if (!modIsOn(BUNNYFEEDS)) return [];
  const { charKeyToId, charInfo } = readBunnyfeedsContext();
  const commented2 = charKeys.some(
    (key) => (charInfo[charKeyToId[key] ?? ""]?.feed ?? []).some(
      (post) => (post.comments ?? []).some((one) => commentData.read(one).player)
    )
  );
  return commented2 ? [...TEXT_LEDGER_FEED_LINES, ""] : [];
}
var FEED_MEMORY_TAG, FEED_MEMORY_END;
var init_bunnyfeedsMemory = __esm({
  "src/renderer/stores/bunnyfeedsMemory.ts"() {
    init_bunnyfeeds();
    init_bunnyfeedsPrompt();
    init_bunnyfeedsData();
    init_bunnyfeedsReadContext();
    FEED_MEMORY_TAG = ", on the feed";
    FEED_MEMORY_END = /, (on the feed|on Bunnyboard|on her post|under [^,]+'s post)$/;
  }
});

// src/renderer/stores/bunnyfeedsVisit.ts
function markCommented() {
  commented = true;
}
function takeCommented() {
  const was = commented;
  commented = false;
  return was;
}
var commented;
var init_bunnyfeedsVisit = __esm({
  "src/renderer/stores/bunnyfeedsVisit.ts"() {
    commented = false;
  }
});

// src/renderer/stores/bunnyfeedsNotes.ts
import { useSyncExternalStore as useSyncExternalStore2 } from "react";
import { globalSlotOf as globalSlotOf3 } from "@vx/modkit/shared";
import { feedReadThrough, subscribeFeedReadThrough, postVisible } from "@vx/modkit/renderer";
function feedReadMark() {
  const own = feedData.read().readThrough;
  if (own !== void 0) return own;
  const legacy = feedReadThrough();
  return Number.isSafeInteger(legacy) ? legacy : void 0;
}
function useFeedReadMark() {
  feedData.use();
  return useSyncExternalStore2(subscribeFeedReadThrough, feedReadMark, feedReadMark);
}
function feedNotesOf(state = readBunnyfeedsContext()) {
  const posts = Object.entries(state.charInfo).flatMap(
    ([posterId, info]) => (info.feed ?? []).filter(postVisible).map((post) => ({ posterId, post }))
  );
  return feedNotes(posts, globalSlotOf3(state.date, state.time));
}
function unreadFeedNotesOf() {
  return unreadFeedNotes(feedNotesOf(), feedReadMark());
}
function markFeedNoteRead(note) {
  commentData.update({
    kind: "comment",
    charId: note.posterId,
    postId: note.postId,
    commentId: note.comment.id
  }, (data) => data.read ? void 0 : { ...data, read: true });
}
function markAllFeedNotesRead() {
  const game = readBunnyfeedsContext();
  if (!game.playthroughId) return;
  feedData.set({ readThrough: globalSlotOf3(game.date, game.time) });
}
function settleFeedReadMark() {
  const game = readBunnyfeedsContext();
  if (!game.playthroughId) return;
  const own = feedData.read().readThrough;
  const mark = feedReadMark();
  const now = globalSlotOf3(game.date, game.time);
  if (own !== void 0 && own <= now) return;
  feedData.set({ readThrough: mark !== void 0 && mark <= now ? mark : now });
}
var init_bunnyfeedsNotes = __esm({
  "src/renderer/stores/bunnyfeedsNotes.ts"() {
    init_bunnyfeedsData();
    init_bunnyfeedsReadContext();
  }
});

// node_modules/zustand/esm/vanilla.mjs
var createStoreImpl, createStore;
var init_vanilla = __esm({
  "node_modules/zustand/esm/vanilla.mjs"() {
    createStoreImpl = (createState) => {
      let state;
      const listeners = /* @__PURE__ */ new Set();
      const setState = (partial, replace) => {
        const nextState = typeof partial === "function" ? partial(state) : partial;
        if (!Object.is(nextState, state)) {
          const previousState = state;
          state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
          listeners.forEach((listener) => listener(state, previousState));
        }
      };
      const getState = () => state;
      const getInitialState = () => initialState;
      const subscribe = (listener) => {
        listeners.add(listener);
        return () => listeners.delete(listener);
      };
      const api = { setState, getState, getInitialState, subscribe };
      const initialState = state = createState(setState, getState, api);
      return api;
    };
    createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
  }
});

// node_modules/zustand/esm/react.mjs
import React from "react";
function useStore(api, selector = identity) {
  const slice = React.useSyncExternalStore(
    api.subscribe,
    React.useCallback(() => selector(api.getState()), [api, selector]),
    React.useCallback(() => selector(api.getInitialState()), [api, selector])
  );
  React.useDebugValue(slice);
  return slice;
}
var identity, createImpl, create;
var init_react = __esm({
  "node_modules/zustand/esm/react.mjs"() {
    init_vanilla();
    identity = (arg) => arg;
    createImpl = (createState) => {
      const api = createStore(createState);
      const useBoundStore = (selector) => useStore(api, selector);
      Object.assign(useBoundStore, api);
      return useBoundStore;
    };
    create = ((createState) => createState ? createImpl(createState) : createImpl);
  }
});

// node_modules/zustand/esm/index.mjs
var init_esm = __esm({
  "node_modules/zustand/esm/index.mjs"() {
    init_vanilla();
    init_react();
  }
});

// src/renderer/stores/bunnyfeedsThreads.ts
var bunnyfeedsThreads_exports = {};
__export(bunnyfeedsThreads_exports, {
  armFeedThreads: () => armFeedThreads,
  leavePlayerComment: () => leavePlayerComment,
  resetFeedThreads: () => resetFeedThreads
});
import {
  messageOf,
  globalSlotOf as globalSlotOf4,
  charKeyOf as charKeyOf3
} from "@vx/modkit/shared";
import {
  character as character2,
  drawFeedHandles as drawFeedHandles2,
  drawFeedEmoji as drawFeedEmoji2,
  FEED_EMOJI as FEED_EMOJI2,
  FEED_HANDLE_POOL as FEED_HANDLE_POOL2,
  SETTING,
  hasTexted,
  retrySilently,
  completeStructured,
  cancelCalls,
  modState,
  currentRun as currentRun3,
  runStale,
  saveChanges,
  addPostComments,
  ownsPostComments,
  lessNsfwText,
  readerPromptText
} from "@vx/modkit/renderer";
function owedThreads(now) {
  const game = readBunnyfeedsContext();
  const owed = [];
  for (const charId of game.chars) {
    for (const post of game.charInfo[charId]?.feed ?? []) {
      const work = threadWork(post.comments, charId, postData.read(post).threadedThrough, now);
      if (work) owed.push({ charId, post, work });
    }
  }
  return owed.sort((a, b) => b.work.player.length - a.work.player.length).slice(0, MAX_THREADS);
}
function withGirls(repliers, charIds, posterId) {
  const { npcRelationships: npcRelationships2 } = readBunnyfeedsContext();
  const listed = new Set(repliers.map(({ character: character3 }) => character3.charId));
  const added = [];
  for (const charId of charIds) {
    if (charId === posterId || listed.has(charId)) continue;
    const replier = replierOf(charId, posterId, npcRelationships2);
    if (!replier) continue;
    listed.add(charId);
    added.push(replier);
  }
  return [...repliers, ...added];
}
function addressedBy(mine, shown, posterId) {
  const others = shown.filter((one) => !commentData.read(one).player && commentData.read(one).charId !== posterId);
  const under = others.find((one) => one.id === commentData.read(mine).replyTo);
  const named = others.filter(
    (one) => new RegExp(`(^|\\s)@${one.handle.replace(/\./g, "\\.")}(?![\\w.])`).test(mine.text)
  );
  const seen = /* @__PURE__ */ new Set();
  return [...under ? [under] : [], ...named].flatMap((one) => {
    const key = commentData.read(one).charId ?? `@${one.handle}`;
    if (seen.has(key)) return [];
    seen.add(key);
    const { charId } = commentData.read(one);
    return [{ ...charId ? { charId } : {}, handle: one.handle }];
  });
}
function whoSaid(comment, posterId) {
  const game = readBunnyfeedsContext();
  const data = commentData.read(comment);
  if (data.player) return "the reader";
  const character3 = data.charId ? game.characters[data.charId] : void 0;
  if (!character3) return `@${comment.handle} (a follower)`;
  const key = charKeyOf3(character3.firstName, character3.lastName);
  return data.charId === posterId ? `${character3.firstName} (the poster)` : `${character3.firstName} ("${key}")`;
}
function callStale(run, pending) {
  return runStale(run) || pendingCall.get() !== pending;
}
async function send(request, run, pending) {
  for (let spent = 0; ; spent++) {
    const result = await completeStructured(BUNNYFEEDS, request, { group: THREAD_GROUP });
    if (callStale(run, pending)) return null;
    if (result.ok) return result.data;
    const again = await retrySilently("feed threads", result.error, spent, {
      onSleep: (cancel) => {
        pending.sleepers.add(cancel);
        if (callStale(run, pending)) cancel();
      }
    });
    if (callStale(run, pending)) return null;
    if (!again) {
      console.warn("[feed] no thread replies:", result.error.message);
      return null;
    }
  }
}
function resetFeedThreads() {
  askAgain = false;
}
async function armFeedThreads(showAt = "now") {
  if (out) {
    askAgain = true;
    return;
  }
  const game = readBunnyfeedsContext();
  if (!game.playthroughId) return;
  const now = globalSlotOf4(game.date, game.time);
  const owed = owedThreads(now);
  if (owed.length === 0) return;
  const byRef = /* @__PURE__ */ new Map();
  const refOf = /* @__PURE__ */ new Map();
  const postByRef = /* @__PURE__ */ new Map();
  const joiners = /* @__PURE__ */ new Map();
  const threads2 = [];
  for (const entry of owed) {
    const { charId, post, work } = entry;
    const character3 = game.characters[charId];
    const info = game.charInfo[charId];
    if (!character3 || !info) continue;
    const shown = (post.comments ?? []).filter((one) => one.at <= now);
    const postRef = `p${postByRef.size + 1}`;
    postByRef.set(postRef, entry);
    for (const comment of shown) {
      const ref = `c${byRef.size + 1}`;
      byRef.set(ref, { owed: entry, comment });
      refOf.set(comment.id, ref);
    }
    const open = work.player.length > 0 && !work.windingDown;
    const tagged = work.player.flatMap((one) => (commentData.read(one).tags ?? []).filter((id) => id !== charId));
    const friend = open ? joiningFriendOf(charId, game.npcRelationships) : null;
    const answersBack = [];
    const girlsBack = [];
    const silent = [];
    const followersBack = /* @__PURE__ */ new Set();
    for (const mine of open ? work.player : []) {
      for (const target of addressedBy(mine, shown, charId)) {
        if (target.charId) {
          const girl = game.characters[target.charId];
          if (!girl || tagged.includes(target.charId) || girlsBack.includes(target.charId)) continue;
          if (silent.some((one) => one.charId === target.charId)) continue;
          if (Math.random() >= ADDRESSED_GIRL_CHANCE) {
            silent.push({ ref: refOf.get(mine.id) ?? "", charId: target.charId });
            continue;
          }
          girlsBack.push(target.charId);
          answersBack.push({
            ref: refOf.get(mine.id) ?? "",
            who: `${girl.firstName} ("${charKeyOf3(girl.firstName, girl.lastName)}")`
          });
        } else {
          if (followersBack.has(target.handle) || Math.random() >= ADDRESSED_FOLLOWER_CHANCE) continue;
          followersBack.add(target.handle);
          answersBack.push({ ref: refOf.get(mine.id) ?? "", who: `@${target.handle}` });
        }
      }
    }
    const follower = open && Math.random() < followerChance(followingOf(game.playthroughId, charId, character3));
    const repliers = withGirls(friend ? [friend] : [], [...tagged, ...girlsBack], charId);
    joiners.set(post.id, {
      girls: new Set(repliers.map(({ character: girl }) => girl.charId)),
      follower,
      followersBack,
      silent: new Set(silent.map((one) => one.charId))
    });
    const lines = shown.map((comment) => ({
      ref: refOf.get(comment.id) ?? "",
      who: whoSaid(comment, charId),
      text: comment.text,
      ...commentData.read(comment).replyTo && refOf.has(commentData.read(comment).replyTo ?? "") ? { replyTo: refOf.get(commentData.read(comment).replyTo ?? "") } : {}
    }));
    threads2.push({
      postRef,
      character: character3,
      info,
      charKey: charKeyOf3(character3.firstName, character3.lastName),
      texted: hasTexted(game.bunnyboard.conversations[charId]),
      post: {
        text: post.text,
        date: post.date,
        time: post.time,
        ...pictureOf(post)
      },
      lines,
      mustAnswer: work.player.map((one) => refOf.get(one.id) ?? ""),
      mayAnswer: work.others.map((one) => refOf.get(one.id) ?? ""),
      mayAnswerCount: work.othersLeft,
      ...work.windingDown ? { windingDown: true } : {},
      repliers,
      follower,
      answersBack,
      silent: silent.flatMap(({ ref, charId: girlId }) => {
        const replier = replierOf(girlId, charId, game.npcRelationships);
        return replier ? [{ ref, replier }] : [];
      }),
      tagged: work.player.flatMap(
        (one) => (commentData.read(one).tags ?? []).flatMap((tagged2) => {
          const girl = game.characters[tagged2];
          return girl && tagged2 !== charId ? [{ ref: refOf.get(one.id) ?? "", name: girl.firstName }] : [];
        })
      )
    });
  }
  if (threads2.length === 0) return;
  const request = buildFeedThreadsPrompt(
    {
      playthroughId: game.playthroughId ?? "unsaved",
      stats: game.stats,
      lessNsfwText: lessNsfwText(),
      date: game.date,
      season: game.calendar.season,
      threads: threads2
    },
    SETTING,
    readerPromptText() ?? ""
  );
  const run = currentRun3();
  out = true;
  const pending = { done: false, sleepers: /* @__PURE__ */ new Set() };
  pendingCall.set(pending);
  try {
    const reply = await send(request, run, pending);
    if (callStale(run, pending) || !reply) return;
    if (fileReplies(
      reply,
      owed,
      byRef,
      postByRef,
      joiners,
      now,
      showAt === "next" ? now + 1 : now,
      run
    )) saveThreads(run);
  } catch (err) {
    console.warn("[feed] no thread replies:", messageOf(err));
  } finally {
    const sameGame = !callStale(run, pending);
    pending.done = true;
    if (pendingCall.get() === pending) pendingCall.set(null);
    out = false;
    if (sameGame) {
      if (askAgain) {
        askAgain = false;
        void armFeedThreads("next");
      }
    }
  }
}
function saveThreads(run) {
  void saveChanges(BUNNYFEEDS, { run }).then((result) => {
    if (!result.ok && !["MOD_WRITE_STALE", "MOD_WRITE_OFF", "MOD_WRITE_NO_GAME"].includes(result.error.code)) {
      console.warn("[bunnyfeeds] replies could not be saved:", result.error.message);
    }
  });
}
function fileReplies(reply, owed, byRef, postByRef, joiners, now, shownAt, run) {
  const game = readBunnyfeedsContext();
  if (!ownsPostComments(BUNNYFEEDS) || runStale(run)) return false;
  owed = owed.filter(
    ({ charId, post }) => game.charInfo[charId]?.feed?.some((current) => current.id === post.id)
  );
  if (owed.length === 0) return false;
  const filed = /* @__PURE__ */ new Map();
  const answeredHim = /* @__PURE__ */ new Set();
  const answeredAt = [];
  const posterOf = /* @__PURE__ */ new Map();
  const capLeft = new Map(owed.map(({ post, work }) => [post.id, work.othersLeft]));
  const spoke = /* @__PURE__ */ new Set();
  const followerLeft = new Map(
    owed.map(({ post }) => [post.id, joiners.get(post.id)?.follower ?? false])
  );
  const owedIds = new Set(
    owed.flatMap(({ work }) => [...work.player, ...work.others].map((one) => one.id))
  );
  for (const one of reply.replies ?? []) {
    const to = one.to?.trim() ?? "";
    const target = byRef.get(to);
    const onPost = target ? void 0 : postByRef.get(to);
    const text = one.text?.trim();
    if (!target && !onPost || !text) continue;
    const entry = target?.owed ?? onPost;
    const comment = target?.comment;
    const posterId = entry.charId;
    const from = one.from?.trim() ?? "";
    const fromId = from && !from.startsWith("@") ? game.charKeyToId[from] : void 0;
    if (from && !from.startsWith("@") && !fromId) {
      console.warn(`[feed] thread reply from unknown key "${one.from}"`);
    }
    const back = from.startsWith("@") ? (entry.post.comments ?? []).find(
      (said) => {
        const data = commentData.read(said);
        return !data.charId && !data.player && said.handle === from.slice(1);
      }
    ) : void 0;
    const letIn = joiners.get(entry.post.id);
    if (fromId === posterId) {
      if (!comment || !owedIds.has(comment.id)) continue;
      if (!commentData.read(comment).player) {
        const left = capLeft.get(entry.post.id) ?? 0;
        if (left <= 0) continue;
        capLeft.set(entry.post.id, left - 1);
      }
    } else {
      if (comment && fromId && commentData.read(comment).charId === fromId) continue;
      const speaker = `${entry.post.id}:${fromId ?? back?.handle ?? ""}`;
      if (fromId) {
        if (!letIn?.girls.has(fromId) || spoke.has(speaker)) continue;
      } else if (from.startsWith("@")) {
        if (!back || !letIn?.followersBack.has(back.handle) || comment?.handle === back.handle) continue;
        if (spoke.has(speaker)) continue;
      } else {
        if (!followerLeft.get(entry.post.id)) continue;
        followerLeft.set(entry.post.id, false);
      }
      if (fromId || back) spoke.add(speaker);
    }
    const list = filed.get(entry.post.id) ?? [];
    list.push(commentData.with({
      id: crypto.randomUUID(),
      handle: fromId ? game.charInfo[fromId]?.handle ?? strangerHandle() : back?.handle ?? strangerHandle(),
      emoji: fromId ? "" : back?.emoji ?? drawFeedEmoji2(1)[0] ?? FEED_EMOJI2[0],
      text,
      at: shownAt
    }, {
      ...fromId ? { charId: fromId } : {},
      ...comment ? { replyTo: comment.id } : {}
    }));
    filed.set(entry.post.id, list);
    const known = fromId ? game.charInfo[fromId] : void 0;
    if ((comment ? commentData.read(comment).player : void 0) && fromId && fromId !== posterId && known) {
      answeredAt.push({ postId: entry.post.id, charId: fromId, posterId });
    }
  }
  const accepted = /* @__PURE__ */ new Set();
  for (const { charId, post } of owed) {
    const comments = filed.get(post.id);
    if (comments && !addComments(charId, post.id, comments, run).ok) continue;
    for (const old of post.comments ?? []) {
      commentData.update(
        { kind: "comment", charId, postId: post.id, commentId: old.id },
        (data) => data,
        { run }
      );
    }
    const progress = postData.update(
      { kind: "post", charId, postId: post.id },
      (data) => ({ ...data, threadedThrough: now }),
      { run }
    );
    if (progress.ok) accepted.add(post.id);
  }
  owed = owed.filter(({ post }) => accepted.has(post.id));
  if (owed.length === 0) return false;
  for (const answer of answeredAt) {
    if (!accepted.has(answer.postId)) continue;
    answeredHim.add(answer.charId);
    if (!posterOf.has(answer.charId)) posterOf.set(answer.charId, answer.posterId);
  }
  for (const { charId, work } of owed) {
    if (work.player.length > 0) posterOf.set(charId, charId);
  }
  const sawHim = owed.flatMap(
    ({ charId: posterId, post }) => [...joiners.get(post.id)?.silent ?? []].filter((girl) => {
      if (answeredHim.has(girl)) return false;
      if (!posterOf.has(girl)) posterOf.set(girl, posterId);
      return true;
    })
  );
  const commentedOn = /* @__PURE__ */ new Set([
    ...owed.filter(({ work }) => work.player.length > 0).map((o) => o.charId),
    ...answeredHim,
    ...sawHim
  ]);
  const remembered = [];
  const held = [];
  for (const memory of reply.memories ?? []) {
    const charId = game.charKeyToId[memory.char?.trim() ?? ""];
    const type = BUNNY_MEMORY_TYPES.find((one) => one === memory.type);
    const desc = memory.desc?.trim().replace(SAID_WHERE, "");
    if (!charId || !commentedOn.has(charId) || !type || !desc) continue;
    commentedOn.delete(charId);
    const posterId = posterOf.get(charId);
    held.push({ charId, at: shownAt, type, desc, ...posterId ? { posterId } : {} });
    remembered.push(game.characters[charId]?.firstName ?? charId);
  }
  if (owed[0]) holdFeedMemories(owed[0].charId, owed[0].post.id, held, run);
  if (shownAt <= now) fileDueFeedMemories(now, run);
  const replies = [...filed.values()].reduce((total, list) => total + list.length, 0);
  console.log(
    `[bunnyfeeds] answered ${owed.length} post(s): ${replies} repl${replies === 1 ? "y" : "ies"}, ` + (remembered.length > 0 ? `memory for ${remembered.join(", ")}` : "no memory")
  );
  return true;
}
function strangerHandle() {
  const [one] = drawFeedHandles2(1);
  return one ?? FEED_HANDLE_POOL2[0].handle;
}
function leavePlayerComment(charId, postId, text, replyTo, tags = []) {
  const trimmed = text.trim();
  if (!trimmed) return;
  const game = readBunnyfeedsContext();
  if (!game.playthroughId) return;
  const comment = commentData.with({
    id: crypto.randomUUID(),
    handle: PLAYER_HANDLE,
    emoji: "",
    text: trimmed,
    at: globalSlotOf4(game.date, game.time)
  }, {
    player: true,
    ...replyTo ? { replyTo } : {},
    ...tags.length > 0 ? { tags: [...tags] } : {}
  });
  if (addComments(charId, postId, [comment], currentRun3()).ok) markCommented();
}
function addComments(charId, postId, comments, run) {
  return addPostComments(BUNNYFEEDS, { charId, postId }, comments, { run });
}
function pictureOf(post) {
  const record = post;
  const slice = record.ex?.["photo-feature"];
  const photo = slice && slice.data !== void 0 ? slice.data : record.photo;
  if (typeof photo?.scene !== "string" || !photo.scene.trim()) return {};
  const other = typeof photo.with === "string" ? character2(photo.with) : void 0;
  return {
    picture: photo.scene,
    ...other ? { pictureWith: other.firstName } : {}
  };
}
var MAX_THREADS, PLAYER_HANDLE, THREAD_GROUP, pendingCall, previousCall, out, askAgain, SAID_WHERE;
var init_bunnyfeedsThreads = __esm({
  "src/renderer/stores/bunnyfeedsThreads.ts"() {
    init_bunnyfeeds();
    init_bunnyfeedsCrowd();
    init_bunnyfeedsPrompt();
    init_bunnyfeedsVisit();
    init_bunnyfeedsReplies();
    init_bunnyfeedsMemory();
    init_bunnyfeedsReadContext();
    init_bunnyfeedsData();
    MAX_THREADS = 8;
    PLAYER_HANDLE = "you";
    THREAD_GROUP = "threads";
    pendingCall = modState(BUNNYFEEDS, { initial: null, lifetime: "game" });
    previousCall = null;
    pendingCall.subscribe((call) => {
      const previous = previousCall;
      previousCall = call;
      if (call !== null || !previous || previous.done) return;
      previous.sleepers.forEach((cancel) => cancel());
      void cancelCalls(BUNNYFEEDS, THREAD_GROUP).catch(() => {
      });
    });
    out = false;
    askAgain = false;
    SAID_WHERE = /,?\s+(?:under|on|in|beneath)\s+(?:her|his|their|my|a|the|[\p{L}'’.-]+(?:'s|’s))\s+(?:own\s+)?(?:post|feed|comments?|comment section|thread)\s*\.?$/iu;
  }
});

// src/renderer/vu_styles/Bunnyfeeds.css
var init_Bunnyfeeds = __esm({
  "src/renderer/vu_styles/Bunnyfeeds.css"() {
  }
});

// src/renderer/components/BunnyfeedsFaces.tsx
var BunnyfeedsFaces_exports = {};
__export(BunnyfeedsFaces_exports, {
  FacesPreview: () => FacesPreview,
  FollowerFace: () => FollowerFace
});
import { useId, useMemo } from "react";
import { hashString, seededRand } from "@vx/modkit/shared";
import { useModOption } from "@vx/modkit/renderer";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
function rollsOf(handle) {
  let state = hashString(handle) || 1;
  return () => {
    state ^= state << 13;
    state ^= state >>> 17;
    state ^= state << 5;
    return (state >>> 0) / 4294967296;
  };
}
function inksOf(roll) {
  const inks = [...FOLLOWER_INKS];
  for (let i = inks.length - 1; i > 0; i--) {
    const j = Math.floor(roll() * (i + 1));
    [inks[i], inks[j]] = [inks[j], inks[i]];
  }
  return inks.slice(0, 3);
}
function identicon(roll) {
  const cells = Array.from({ length: 15 }, () => roll() < 0.5);
  if (cells.filter(Boolean).length < 5) for (const at of [2, 7, 12]) cells[at] = true;
  return cells.flatMap((on, i) => {
    if (!on) return [];
    const col = i % 3;
    const row = Math.floor(i / 3);
    return (col === 2 ? [2] : [col, 4 - col]).map((at) => /* @__PURE__ */ jsx(
      "rect",
      {
        className: "vu-bf-ink1",
        x: 7.5 + at * 7,
        y: 19 + row * 7,
        width: 7,
        height: 7
      },
      `${row}:${at}`
    ));
  });
}
function gradient(roll, filter) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("filter", { id: filter, x: "-50%", y: "-50%", width: "200%", height: "200%", children: /* @__PURE__ */ jsx("feGaussianBlur", { stdDeviation: "6" }) }) }),
    /* @__PURE__ */ jsxs("g", { filter: `url(#${filter})`, children: [
      /* @__PURE__ */ jsx("circle", { className: "vu-bf-ink1", cx: 10 + roll() * 30, cy: 18 + roll() * 28, r: 15 + roll() * 7 }),
      /* @__PURE__ */ jsx("circle", { className: "vu-bf-ink2", cx: 10 + roll() * 30, cy: 24 + roll() * 26, r: 12 + roll() * 7 })
    ] })
  ] });
}
function shapes(roll) {
  const count = 2 + Math.floor(roll() * 2);
  return Array.from({ length: count }, (_, i) => {
    const ink = `vu-bf-ink${i + 1}`;
    const x = 10 + roll() * 30;
    const y = 18 + roll() * 30;
    const size = 12 + roll() * 14;
    const turn = `rotate(${Math.floor(roll() * 90)} ${x} ${y})`;
    const kind = Math.floor(roll() * 4);
    const half = size / 2;
    if (kind === 0) return /* @__PURE__ */ jsx("circle", { className: ink, cx: x, cy: y, r: size / 1.6 }, i);
    if (kind === 1) {
      return /* @__PURE__ */ jsx(
        "rect",
        {
          className: ink,
          x: x - half,
          y: y - half,
          width: size,
          height: size,
          rx: size / 4,
          transform: turn
        },
        i
      );
    }
    if (kind === 2) {
      const points = `${x},${y - size / 1.4} ${x + size / 1.4},${y + size / 1.6} ${x - size / 1.4},${y + size / 1.6}`;
      return /* @__PURE__ */ jsx("polygon", { className: ink, points, transform: turn }, i);
    }
    const r = size / 1.4;
    return /* @__PURE__ */ jsx("path", { className: ink, d: `M${x - r} ${y} a${r} ${r} 0 0 1 ${r * 2} 0z`, transform: turn }, i);
  });
}
function monogram(handle) {
  const letter = handle.match(/[\p{L}\p{N}]/u)?.[0]?.toUpperCase() ?? "?";
  return /* @__PURE__ */ jsx("text", { className: "vu-bf-ink1", x: 25, y: 36, textAnchor: "middle", dominantBaseline: "central", children: letter });
}
function drawnStyleOf(handle, style) {
  if (style !== "mixed") return style;
  return DRAWN_STYLES[Math.floor(seededRand(`${handle}#faces`)() * DRAWN_STYLES.length)];
}
function styleOf(optionId) {
  if (optionId === "faces-identicon") return "identicon";
  if (optionId === "faces-shapes") return "shapes";
  if (optionId === "faces-monogram") return "monogram";
  if (optionId === "faces-mixed") return "mixed";
  return "gradient";
}
function useFaceStyle() {
  const identiconOn = useModOption(BUNNYFEEDS, "faces-identicon");
  const shapesOn = useModOption(BUNNYFEEDS, "faces-shapes");
  const monogramOn = useModOption(BUNNYFEEDS, "faces-monogram");
  const mixedOn = useModOption(BUNNYFEEDS, "faces-mixed");
  return styleOf(
    identiconOn ? "faces-identicon" : shapesOn ? "faces-shapes" : monogramOn ? "faces-monogram" : mixedOn ? "faces-mixed" : null
  );
}
function DrawnFace({
  handle,
  style: picked,
  className
}) {
  const style = drawnStyleOf(handle, picked);
  const filter = `vu-bf-blur${useId().replace(/[^\w-]/g, "")}`;
  const { inks, art } = useMemo(() => {
    const roll = rollsOf(handle);
    const picked2 = inksOf(roll);
    const drawn = style === "identicon" ? identicon(roll) : style === "shapes" ? shapes(roll) : style === "monogram" ? monogram(handle) : gradient(roll, filter);
    return { inks: picked2, art: drawn };
  }, [handle, style, filter]);
  const colours = Object.fromEntries(inks.map((ink, i) => [`--bf-ink-${i + 1}`, `var(${ink})`]));
  return /* @__PURE__ */ jsx("span", { className: `${className} vu-bf-face--${style}`, style: colours, "aria-hidden": true, children: /* @__PURE__ */ jsx(
    "svg",
    {
      viewBox: "0 0 50 60",
      preserveAspectRatio: "xMidYMid slice",
      shapeRendering: style === "identicon" ? "crispEdges" : void 0,
      children: art
    }
  ) });
}
function FollowerFace({ handle, className }) {
  return /* @__PURE__ */ jsx(DrawnFace, { handle, style: useFaceStyle(), className });
}
function FacesPreview({ optionId }) {
  const style = styleOf(optionId);
  return /* @__PURE__ */ jsx("div", { className: "vu-bf-faces-preview", children: SAMPLES.map((handle) => /* @__PURE__ */ jsxs("span", { className: "vu-bf-faces-sample", children: [
    /* @__PURE__ */ jsx(
      DrawnFace,
      {
        handle,
        style,
        className: "vu-arch vu-bb-face vu-bb-face--ring vu-bf-face vu-bf-face--md vu-bf-face--follower"
      }
    ),
    /* @__PURE__ */ jsx(
      DrawnFace,
      {
        handle,
        style,
        className: "vu-arch vu-bb-face vu-bf-face vu-bf-face--sm vu-bf-face--follower"
      }
    )
  ] }, handle)) });
}
var DRAWN_STYLES, FOLLOWER_INKS, SAMPLES;
var init_BunnyfeedsFaces = __esm({
  "src/renderer/components/BunnyfeedsFaces.tsx"() {
    init_bunnyfeeds();
    init_Bunnyfeeds();
    DRAWN_STYLES = ["gradient", "identicon", "shapes", "monogram"];
    FOLLOWER_INKS = [
      "--vu-accent",
      "--vu-good",
      "--vu-warn",
      "--vu-danger",
      "--vu-stat-brain"
    ];
    SAMPLES = ["quadwalker", "anouk_amok", "jill.stingray", "Stridley", "ophelia.exe"];
  }
});

// src/renderer/components/BunnyfeedsThread.tsx
var BunnyfeedsThread_exports = {};
__export(BunnyfeedsThread_exports, {
  CommentFace: () => CommentFace,
  CommentPill: () => CommentPill,
  FeedPreview: () => FeedPreview,
  PostViewHost: () => PostViewHost,
  RosterFace: () => RosterFace,
  closePostView: () => closePostView,
  usePostView: () => usePostView
});
import { useEffect, useMemo as useMemo2, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { motion } from "motion/react";
import { shownComments, fullNameOf as fullNameOf2 } from "@vx/modkit/shared";
import {
  isFeedContact as isFeedContact2,
  EmojiTool,
  PostPicture,
  SentText,
  fadeIn,
  gestures,
  lift,
  press,
  quietLift,
  quietPress,
  CloseIcon,
  HeartIcon,
  formatShortGameDate as formatShortGameDate2,
  slotHalf,
  phoneOpen,
  subscribePhoneView,
  useBareMessage
} from "@vx/modkit/renderer";
import { useProfileImageUrl, useSceneActive, toggleFeedLike, isGraduationSlot } from "@vx/modkit/renderer";
import { Fragment as Fragment2, jsx as jsx2, jsxs as jsxs2 } from "react/jsx-runtime";
function closePostView() {
  usePostView.getState().show(null);
  if (takeCommented()) void armFeedThreads("next");
}
function grouped(said) {
  const byId = new Map(said.map((one) => [one.id, one]));
  const rootOf = (one) => {
    let at = one;
    for (let hops = 0; hops < said.length; hops++) {
      const replyTo = commentData.read(at).replyTo;
      const parent = replyTo ? byId.get(replyTo) : void 0;
      if (!parent) break;
      at = parent;
    }
    return at.id;
  };
  const roots = said.filter((one) => {
    const replyTo = commentData.read(one).replyTo;
    return !replyTo || !byId.has(replyTo);
  });
  const repliesTo = /* @__PURE__ */ new Map();
  for (const one of said) {
    if (!commentData.read(one).replyTo || !byId.has(commentData.read(one).replyTo ?? "")) continue;
    const root = rootOf(one);
    repliesTo.set(root, [...repliesTo.get(root) ?? [], one]);
  }
  return { roots, repliesTo };
}
function useShown(comments) {
  const date = useBunnyfeedsContext((s) => s.date);
  const time = useBunnyfeedsContext((s) => s.time);
  return shownComments(comments, date, time);
}
function useCanComment({ charId, postId, stranger }) {
  const epilogue = useBunnyfeedsContext((s) => isGraduationSlot(s.date, s.time));
  const sceneActive = useSceneActive();
  return Boolean(charId && postId && !stranger && !epilogue && !sceneActive);
}
function FeedPreview(props) {
  const said = useShown(props.comments);
  const show = usePostView((s) => s.show);
  if (said.length === 0 || !props.charId || !props.postId) return null;
  const { roots, repliesTo } = grouped(said);
  const preview = [...roots].reverse().find((one) => commentData.read(one).player) ?? roots[roots.length - 1];
  const replies = repliesTo.get(preview.id)?.length ?? 0;
  const open = () => show({ charId: props.charId ?? "", postId: props.postId ?? "" });
  return /* @__PURE__ */ jsxs2("div", { className: "vu-bb-thread", children: [
    said.length > 1 && /* @__PURE__ */ jsxs2(
      motion.button,
      {
        type: "button",
        className: "vu-bf-comment-reply vu-bf-comment-open",
        ...gestures(false, quietLift, quietPress),
        onClick: open,
        children: [
          "View all ",
          said.length,
          " comments"
        ]
      }
    ),
    /* @__PURE__ */ jsx2(CommentRow, { comment: preview }),
    replies > 0 && /* @__PURE__ */ jsxs2(
      motion.button,
      {
        type: "button",
        className: "vu-bf-comment-reply vu-bf-comment-more",
        ...gestures(false, quietLift, quietPress),
        onClick: open,
        children: [
          "\u21B3 ",
          replies === 1 ? "1 reply" : `${replies} replies`
        ]
      }
    )
  ] });
}
function CommentPill(props) {
  const said = useShown(props.comments);
  const canComment = useCanComment(props);
  const open = usePostView((s) => s.open);
  const show = usePostView((s) => s.show);
  const { charId, postId } = props;
  if (!charId || !postId || said.length === 0 && !canComment) return null;
  const isOpen = open?.charId === charId && open.postId === postId;
  return /* @__PURE__ */ jsxs2(Fragment2, { children: [
    /* @__PURE__ */ jsxs2(
      motion.button,
      {
        type: "button",
        className: "vu-bb-like",
        "aria-label": "Comments",
        ...gestures(false, quietLift, quietPress),
        onClick: () => show({ charId, postId }),
        children: [
          /* @__PURE__ */ jsx2(BubbleIcon, {}),
          said.length
        ]
      }
    ),
    isOpen && /* @__PURE__ */ jsx2(PostView, { ...props, charId, postId })
  ] });
}
function PostViewHost() {
  const open = usePostView((s) => s.open);
  const info = useBunnyfeedsContext((s) => open ? s.charInfo[open.charId] : void 0);
  const post = info?.feed?.find((one) => one.id === open?.postId);
  if (!open || !post) return null;
  return /* @__PURE__ */ jsx2(
    PostView,
    {
      comments: post.comments ?? [],
      charId: open.charId,
      postId: open.postId,
      stranger: !isFeedContact2(info)
    }
  );
}
function BubbleIcon() {
  return /* @__PURE__ */ jsx2("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.2", "aria-hidden": true, children: /* @__PURE__ */ jsx2("path", { d: "M4 5h16v11H9l-5 4z", strokeLinejoin: "round" }) });
}
function PostView(props) {
  const { charId, postId } = props;
  const focusId = usePostView((s) => s.open?.commentId);
  const character3 = useBunnyfeedsContext((s) => s.characters[charId]);
  const handle = useBunnyfeedsContext((s) => s.charInfo[charId]?.handle);
  const post = useBunnyfeedsContext((s) => s.charInfo[charId]?.feed?.find((one) => one.id === postId));
  const season = useBunnyfeedsContext((s) => s.calendar.season);
  const canComment = useCanComment(props);
  const sceneActive = useSceneActive();
  const [replying, setReplying] = useState(null);
  const veil = document.querySelector(".vu-bb")?.parentElement;
  if (!veil || !character3 || !post) return null;
  const commented2 = (post.comments ?? []).some((one) => {
    const data = commentData.read(one);
    return data.player && !data.replyTo;
  });
  const close = closePostView;
  return createPortal(
    /* @__PURE__ */ jsx2(
      motion.div,
      {
        className: "vu-bb-postveil",
        variants: fadeIn(0, 0.18),
        initial: "hidden",
        animate: "shown",
        onClick: close,
        children: /* @__PURE__ */ jsxs2(
          "div",
          {
            className: "vu-bb-postview",
            role: "dialog",
            "aria-label": `${character3.firstName}'s post`,
            onClick: (e) => e.stopPropagation(),
            onKeyDown: (e) => {
              if (e.key !== "Escape") return;
              e.stopPropagation();
              close();
            },
            children: [
              /* @__PURE__ */ jsxs2("div", { className: "vu-bb-postview-head", children: [
                /* @__PURE__ */ jsxs2("span", { className: "vu-bb-postview-title", children: [
                  character3.firstName,
                  "'s post"
                ] }),
                /* @__PURE__ */ jsx2(
                  motion.button,
                  {
                    type: "button",
                    className: "vu-circle vu-bb-postview-close",
                    "aria-label": "Close post",
                    ...gestures(false, quietLift, quietPress),
                    onClick: close,
                    children: /* @__PURE__ */ jsx2(CloseIcon, {})
                  }
                )
              ] }),
              /* @__PURE__ */ jsxs2("div", { className: "vu-bb-postview-body", children: [
                /* @__PURE__ */ jsxs2("div", { className: "vu-bb-postview-who", children: [
                  /* @__PURE__ */ jsx2(RosterFace, { charId, size: "md" }),
                  /* @__PURE__ */ jsxs2("div", { children: [
                    /* @__PURE__ */ jsx2("div", { className: "vu-bb-postview-name", children: fullNameOf2(character3) }),
                    /* @__PURE__ */ jsxs2("div", { className: "vu-bb-postview-meta", children: [
                      handle && /* @__PURE__ */ jsxs2("span", { children: [
                        "@",
                        handle,
                        " \xB7 "
                      ] }),
                      formatShortGameDate2(post.date, season),
                      " \xB7 ",
                      slotHalf(post.time)
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsx2("p", { className: "vu-bb-post-text", children: /* @__PURE__ */ jsx2(SentText, { text: post.text }) }),
                /* @__PURE__ */ jsx2(PostPicture, { charId, postId }),
                /* @__PURE__ */ jsx2("div", { className: "vu-bb-post-actions", children: /* @__PURE__ */ jsxs2(
                  motion.button,
                  {
                    className: `vu-bb-like${post.liked ? " vu-bb-like--on" : ""}`,
                    type: "button",
                    "aria-pressed": Boolean(post.liked),
                    ...gestures(false, quietLift, quietPress),
                    onClick: () => toggleFeedLike(charId, postId),
                    children: [
                      /* @__PURE__ */ jsx2(HeartIcon, {}),
                      post.likes + (post.liked ? 1 : 0)
                    ]
                  }
                ) }),
                /* @__PURE__ */ jsx2(
                  Thread,
                  {
                    comments: post.comments ?? [],
                    posterId: charId,
                    postId,
                    canComment,
                    focusId,
                    replying,
                    setReplying
                  }
                )
              ] }),
              !canComment && sceneActive && !props.stranger && /* @__PURE__ */ jsx2("div", { className: "vu-bb-postview-foot", children: /* @__PURE__ */ jsx2(
                "input",
                {
                  className: "vu-input vu-bf-comment-input",
                  disabled: true,
                  "aria-label": "Comment",
                  placeholder: "You should probably focus on what's in front of you."
                }
              ) }),
              canComment && !replying && /* @__PURE__ */ jsx2("div", { className: "vu-bb-postview-foot", children: commented2 ? /* @__PURE__ */ jsx2(
                "input",
                {
                  className: "vu-input vu-bf-comment-input",
                  disabled: true,
                  "aria-label": "Comment",
                  placeholder: "You've commented on this post. Reply in its thread to keep going."
                }
              ) : /* @__PURE__ */ jsx2(
                CommentField,
                {
                  posterId: charId,
                  replyTo: null,
                  onSend: (text, tags) => leavePlayerComment(charId, postId, text, void 0, tags)
                }
              ) })
            ]
          }
        )
      }
    ),
    veil
  );
}
function Thread({
  comments,
  posterId,
  postId,
  canComment,
  focusId,
  replying,
  setReplying
}) {
  const said = useShown(comments);
  const { roots, repliesTo } = grouped(said);
  const [unfolded, setUnfolded] = useState(() => {
    const root = roots.find(
      (one) => one.id === focusId || repliesTo.get(one.id)?.some((reply) => reply.id === focusId)
    );
    return new Set(root ? [root.id] : []);
  });
  const reader = useReaderHandle();
  if (said.length === 0) return null;
  const byId = new Map(said.map((one) => [one.id, one]));
  const toOf = (one) => {
    const data = commentData.read(one);
    const target = data.player || !data.replyTo ? void 0 : byId.get(data.replyTo);
    return target ? commentData.read(target).player ? reader : `@${target.handle}` : void 0;
  };
  return /* @__PURE__ */ jsx2("ul", { className: "vu-bf-comments", children: roots.map((root) => {
    const replies = repliesTo.get(root.id) ?? [];
    const answering = replying?.root === root;
    const open = commentData.read(root).player || unfolded.has(root.id) || answering;
    return /* @__PURE__ */ jsxs2("li", { className: "vu-bf-comment-group", children: [
      /* @__PURE__ */ jsx2(
        CommentRow,
        {
          comment: root,
          focused: root.id === focusId,
          onReply: canComment ? () => setReplying({ root, to: root }) : void 0
        }
      ),
      replies.length > 0 && !open && /* @__PURE__ */ jsxs2(
        motion.button,
        {
          type: "button",
          className: "vu-bf-comment-reply vu-bf-comment-more",
          ...gestures(false, quietLift, quietPress),
          onClick: () => setUnfolded(/* @__PURE__ */ new Set([...unfolded, root.id])),
          children: [
            "\u2304 View ",
            replies.length === 1 ? "1 reply" : `${replies.length} replies`
          ]
        }
      ),
      open && (replies.length > 0 || answering) && /* @__PURE__ */ jsxs2("ul", { className: "vu-bf-comments vu-bf-comments--replies", children: [
        replies.map((one) => /* @__PURE__ */ jsx2("li", { children: /* @__PURE__ */ jsx2(
          CommentRow,
          {
            comment: one,
            to: toOf(one),
            focused: one.id === focusId,
            onReply: canComment && !commentData.read(one).player ? () => setReplying({ root, to: one }) : void 0
          }
        ) }, one.id)),
        replying && answering && /* @__PURE__ */ jsx2("li", { children: /* @__PURE__ */ jsx2(
          CommentField,
          {
            posterId,
            replyTo: replying.to,
            onCancel: () => setReplying(null),
            onSend: (text, tags) => {
              leavePlayerComment(posterId, postId, text, root.id, tags);
              setReplying(null);
            }
          },
          replying.to.id
        ) })
      ] })
    ] }, root.id);
  }) });
}
function CommentRow({
  comment,
  to,
  focused,
  onReply
}) {
  const reader = useReaderHandle();
  const bare = useBareMessage(comment.text);
  const row = useRef(null);
  useEffect(() => {
    if (focused) row.current?.scrollIntoView({ block: "center" });
  }, [focused]);
  return /* @__PURE__ */ jsxs2("div", { ref: row, className: `vu-bf-comment${focused ? " vu-bf-comment--focus" : ""}`, children: [
    /* @__PURE__ */ jsx2(CommentFace, { comment }),
    /* @__PURE__ */ jsxs2("span", { className: "vu-bf-comment-said", children: [
      /* @__PURE__ */ jsx2("span", { className: "vu-bf-comment-who vu-bf-comment-who--over", children: commentData.read(comment).player ? reader : `@${comment.handle}` }),
      to && /* @__PURE__ */ jsxs2("span", { className: "vu-bf-comment-mention", children: [
        to,
        " "
      ] }),
      bare ? /* @__PURE__ */ jsx2(SentText, { text: comment.text }) : comment.text.split(/(@[\w.]+)/).map(
        (part, i) => i % 2 === 1 ? /* @__PURE__ */ jsx2("span", { className: "vu-bf-comment-mention", children: part }, i) : /* @__PURE__ */ jsx2(SentText, { text: part, big: false }, i)
      ),
      onReply && /* @__PURE__ */ jsx2(
        motion.button,
        {
          type: "button",
          className: "vu-bf-comment-reply",
          ...gestures(false, quietLift, quietPress),
          onClick: onReply,
          children: "Reply"
        }
      )
    ] })
  ] });
}
function useReaderHandle() {
  const first = useBunnyfeedsContext((s) => s.playerFirstName);
  const handle = first.toLowerCase().replace(/[^\w.]/g, "");
  return handle ? `@${handle}` : "you";
}
function archOf(size, kind) {
  const ring = size === "md" ? " vu-bb-face--ring" : "";
  return `vu-arch vu-bb-face${ring} vu-bf-face vu-bf-face--${size}${kind ? ` vu-bf-face--${kind}` : ""}`;
}
function PlayerFace({ size = "sm" }) {
  const picture = useBunnyfeedsContext((s) => s.profilePicture);
  return picture ? /* @__PURE__ */ jsx2("span", { className: archOf(size), "aria-hidden": true, children: /* @__PURE__ */ jsx2("span", { className: "vu-crop", children: /* @__PURE__ */ jsx2("img", { className: "vu-crop-img", src: picture, alt: "" }) }) }) : /* @__PURE__ */ jsx2("span", { className: archOf(size, "player"), "aria-hidden": true, children: "you" });
}
function RosterFace({ charId, size = "sm" }) {
  const url = useProfileImageUrl(charId);
  return /* @__PURE__ */ jsx2("span", { className: archOf(size), "aria-hidden": true, children: /* @__PURE__ */ jsx2("span", { className: "vu-crop", children: /* @__PURE__ */ jsx2("img", { className: "vu-crop-img", src: url, alt: "" }) }) });
}
function CommentFace({
  comment,
  size = "sm"
}) {
  const data = commentData.read(comment);
  if (data.charId) return /* @__PURE__ */ jsx2(RosterFace, { charId: data.charId, size });
  if (data.player) return /* @__PURE__ */ jsx2(PlayerFace, { size });
  return /* @__PURE__ */ jsx2(FollowerFace, { handle: comment.handle, className: archOf(size, "follower") });
}
function mentionAt(text, caret) {
  const match = /(^|\s)@([\w.]*)$/.exec(text.slice(0, caret));
  return match ? { start: caret - match[2].length - 1, query: match[2].toLowerCase() } : null;
}
function CommentField({
  posterId,
  replyTo,
  onCancel,
  onSend
}) {
  const opening = replyTo && !commentData.read(replyTo).player ? `@${replyTo.handle} ` : "";
  const [draft, setDraft] = useState(opening);
  const [caret, setCaret] = useState(opening.length);
  const [active, setActive] = useState(0);
  const [picked, setPicked] = useState([]);
  const [dismissed, setDismissed] = useState(false);
  const input = useRef(null);
  useEffect(() => {
    input.current?.setSelectionRange(opening.length, opening.length);
  }, [opening]);
  const chars = useBunnyfeedsContext((s) => s.chars);
  const characters = useBunnyfeedsContext((s) => s.characters);
  const charInfo = useBunnyfeedsContext((s) => s.charInfo);
  const taggable = useMemo2(
    () => chars.flatMap((charId) => {
      const character3 = characters[charId];
      const info = charInfo[charId];
      if (charId === posterId || !character3 || !isFeedContact2(info)) return [];
      return [
        {
          charId,
          name: fullNameOf2(character3),
          handle: info?.handle ?? character3.firstName.toLowerCase()
        }
      ];
    }),
    [chars, characters, charInfo, posterId]
  );
  const mention = mentionAt(draft, caret);
  const rows = mention ? taggable.filter(
    (one) => one.handle.toLowerCase().startsWith(mention.query) || one.name.toLowerCase().split(" ").some((word) => word.startsWith(mention.query))
  ) : [];
  const listing = !dismissed && rows.length > 0;
  const pick = (one) => {
    if (!mention) return;
    const before = `${draft.slice(0, mention.start)}@${one.handle} `;
    setDraft(before + draft.slice(caret));
    setPicked((list) => list.some((p) => p.charId === one.charId) ? list : [...list, one]);
    setActive(0);
    setCaret(before.length);
    requestAnimationFrame(() => input.current?.setSelectionRange(before.length, before.length));
  };
  const addEmoji = (emoji) => {
    const box = input.current;
    const start = Math.min(box?.selectionStart ?? draft.length, draft.length);
    const end = Math.min(box?.selectionEnd ?? start, draft.length);
    const next = draft.slice(0, start) + emoji + draft.slice(end);
    setDraft(next);
    setCaret(start + emoji.length);
    setDismissed(true);
    requestAnimationFrame(() => box?.setSelectionRange(start + emoji.length, start + emoji.length));
  };
  const send2 = () => {
    if (!draft.trim()) return;
    const replyCharId = replyTo ? commentData.read(replyTo).charId : void 0;
    const opened = taggable.find((one) => one.charId === replyCharId);
    const chosen = opened && !picked.includes(opened) ? [...picked, opened] : picked;
    const tags = chosen.filter((one) => new RegExp(`(^|\\s)@${one.handle.replace(/\./g, "\\.")}(?![\\w.])`).test(draft)).map((one) => one.charId);
    onSend(draft, tags);
    setDraft("");
    setPicked([]);
  };
  return /* @__PURE__ */ jsxs2("div", { className: "vu-bf-comment-compose", children: [
    replyTo && /* @__PURE__ */ jsxs2("div", { className: "vu-bf-comment-replying", children: [
      /* @__PURE__ */ jsx2("span", { children: commentData.read(replyTo).player ? "Adding to your thread" : `Replying to @${replyTo.handle}` }),
      onCancel && /* @__PURE__ */ jsx2(
        motion.button,
        {
          type: "button",
          className: "vu-bf-comment-reply",
          ...gestures(false, quietLift, quietPress),
          onClick: onCancel,
          children: "Cancel"
        }
      )
    ] }),
    /* @__PURE__ */ jsxs2("div", { className: "vu-bf-comment-row", children: [
      /* @__PURE__ */ jsx2(
        "input",
        {
          ref: input,
          autoFocus: Boolean(replyTo),
          className: "vu-input vu-bf-comment-input",
          value: draft,
          autoComplete: "off",
          role: "combobox",
          "aria-expanded": listing,
          "aria-autocomplete": "list",
          "aria-label": replyTo ? "Reply" : "Comment",
          placeholder: replyTo ? "Write a reply\u2026" : "Write a comment\u2026 @ to tag a friend",
          onChange: (e) => {
            setDraft(e.target.value);
            setCaret(e.target.selectionStart ?? e.target.value.length);
            setActive(0);
            setDismissed(false);
          },
          onSelect: (e) => setCaret(e.currentTarget.selectionStart ?? 0),
          onKeyDown: (e) => {
            if (listing && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
              e.preventDefault();
              const step = e.key === "ArrowDown" ? 1 : rows.length - 1;
              setActive((at) => (at + step) % rows.length);
              return;
            }
            if (e.key === "Escape") {
              if (listing) setDismissed(true);
              else if (onCancel) onCancel();
              else return;
              e.stopPropagation();
              return;
            }
            if (e.key !== "Enter" && !(listing && e.key === "Tab")) return;
            e.stopPropagation();
            e.preventDefault();
            if (listing) pick(rows[Math.min(active, rows.length - 1)]);
            else send2();
          }
        }
      ),
      /* @__PURE__ */ jsx2(EmojiTool, { onPick: addEmoji }),
      /* @__PURE__ */ jsx2(
        motion.button,
        {
          type: "button",
          className: "vu-btn vu-btn--primary vu-btn--panel vu-paper vu-bf-comment-send",
          disabled: !draft.trim(),
          ...gestures(!draft.trim(), lift, press),
          onClick: send2,
          children: "Send"
        }
      )
    ] }),
    listing && /* @__PURE__ */ jsx2("div", { className: "vu-pop vu-bb-mention-pop", onMouseDown: (e) => e.preventDefault(), children: /* @__PURE__ */ jsx2("div", { className: "vu-pop-list", role: "listbox", children: rows.map((one, index) => /* @__PURE__ */ jsxs2(
      "button",
      {
        type: "button",
        role: "option",
        "aria-selected": index === active,
        className: `vu-pop-option vu-bb-mention${index === active ? " vu-pop-option--on" : ""}`,
        onMouseEnter: () => setActive(index),
        onClick: () => pick(one),
        children: [
          /* @__PURE__ */ jsx2(RosterFace, { charId: one.charId }),
          /* @__PURE__ */ jsx2("span", { children: one.name }),
          /* @__PURE__ */ jsxs2("span", { className: "vu-bf-comment-who", children: [
            "@",
            one.handle
          ] })
        ]
      },
      one.charId
    )) }) })
  ] });
}
var usePostView, wasPhoneOpen;
var init_BunnyfeedsThread = __esm({
  "src/renderer/components/BunnyfeedsThread.tsx"() {
    init_esm();
    init_bunnyfeedsData();
    init_bunnyfeedsReadContext();
    init_bunnyfeedsThreads();
    init_BunnyfeedsFaces();
    init_bunnyfeedsThreads();
    init_bunnyfeedsVisit();
    init_Bunnyfeeds();
    usePostView = create((set) => ({ open: null, show: (open) => set({ open }) }));
    wasPhoneOpen = phoneOpen();
    subscribePhoneView(() => {
      const beforeOpen = wasPhoneOpen;
      wasPhoneOpen = phoneOpen();
      if (beforeOpen && !wasPhoneOpen) usePostView.getState().show(null);
    });
  }
});

// src/renderer/components/BunnyfeedsNotifications.tsx
var BunnyfeedsNotifications_exports = {};
__export(BunnyfeedsNotifications_exports, {
  FeedNotificationsPage: () => FeedNotificationsPage,
  MarkAllFeedNotes: () => MarkAllFeedNotes
});
import { useMemo as useMemo3, useState as useState2 } from "react";
import { motion as motion2 } from "motion/react";
import { slotFromId, fullNameOf as fullNameOf3 } from "@vx/modkit/shared";
import {
  FEED_PAGE,
  formatNumericGameDate,
  slotHalf as slotHalf2,
  dealt,
  gestures as gestures2,
  quietLift as quietLift2,
  quietPress as quietPress2,
  rowLift,
  rowPress,
  slideInQuick,
  SentText as SentText2
} from "@vx/modkit/renderer";
import { Fragment as Fragment3, jsx as jsx3, jsxs as jsxs3 } from "react/jsx-runtime";
function dayHeading(day, today, season) {
  if (day === today) return "Today";
  if (day === today - 1) return "Yesterday";
  return formatNumericGameDate(day, season);
}
function FeedNotificationsPage() {
  const charInfo = useBunnyfeedsContext((s) => s.charInfo);
  const date = useBunnyfeedsContext((s) => s.date);
  const time = useBunnyfeedsContext((s) => s.time);
  const notes = useMemo3(() => feedNotesOf({ charInfo, date, time }), [charInfo, date, time]);
  const [pages, setPages] = useState2(1);
  const more = pages * FEED_PAGE < notes.length;
  const readThrough = useFeedReadMark();
  const season = useBunnyfeedsContext((s) => s.calendar.season);
  const days = useMemo3(() => {
    const cut = [];
    for (const note of notes.slice(0, pages * FEED_PAGE)) {
      const day = slotFromId(note.comment.at).date;
      const last = cut[cut.length - 1];
      if (last?.day === day) last.notes.push(note);
      else cut.push({ day, notes: [note] });
    }
    return cut;
  }, [notes, pages]);
  return /* @__PURE__ */ jsxs3(Fragment3, { children: [
    /* @__PURE__ */ jsxs3("div", { className: "vu-bb-scroll", children: [
      notes.length === 0 ? /* @__PURE__ */ jsx3("p", { className: "vu-empty vu-empty--flush", children: "No replies yet. Comment on a friend's post and her answers turn up here." }) : days.map(({ day, notes: those }) => /* @__PURE__ */ jsxs3("section", { className: "vu-bf-notes-day", children: [
        /* @__PURE__ */ jsx3("h3", { className: "vu-bb-section", children: dayHeading(day, date, season) }),
        /* @__PURE__ */ jsx3(motion2.ul, { className: "vu-rows", variants: LIST_DEAL, children: those.map((note) => /* @__PURE__ */ jsx3(motion2.li, { variants: slideInQuick, children: /* @__PURE__ */ jsx3(NoteRow, { note, unread: feedNoteUnread(note, readThrough) }) }, note.comment.id)) })
      ] }, day)),
      more && /* @__PURE__ */ jsx3(
        motion2.button,
        {
          id: "bf-notes-more",
          className: "vu-bb-more",
          type: "button",
          variants: slideInQuick,
          ...gestures2(false, rowLift, rowPress),
          onClick: () => setPages((loaded) => loaded + 1),
          children: "Load more"
        }
      )
    ] }),
    /* @__PURE__ */ jsx3(PostViewHost, {})
  ] });
}
function MarkAllFeedNotes() {
  const readThrough = useFeedReadMark();
  const notes = useBunnyfeedsContext(feedNotesOf);
  const unread = unreadFeedNotes(notes, readThrough);
  if (unread === 0) return null;
  return /* @__PURE__ */ jsx3(
    motion2.button,
    {
      type: "button",
      className: "vu-bf-comment-reply",
      ...gestures2(false, quietLift2, quietPress2),
      onClick: markAllFeedNotesRead,
      children: "Mark all as read"
    }
  );
}
function NoteRow({ note, unread }) {
  const { comment, kind } = note;
  const character3 = useBunnyfeedsContext(
    (s) => commentData.read(comment).charId && s.charInfo[commentData.read(comment).charId ?? ""]?.nameKnown ? s.characters[commentData.read(comment).charId ?? ""] : void 0
  );
  const poster = useBunnyfeedsContext(
    (s) => s.charInfo[note.posterId]?.nameKnown ? s.characters[note.posterId]?.firstName : `@${s.charInfo[note.posterId]?.handle ?? ""}`
  );
  const show = usePostView((s) => s.show);
  const who = character3?.firstName ?? `@${comment.handle}`;
  const what = kind === "poster" ? `${who} replied to your comment` : `${who} replied to your comment under ${poster}'s post`;
  return /* @__PURE__ */ jsxs3(
    motion2.div,
    {
      className: `vu-row vu-bf-note${unread ? " vu-bf-note--new" : ""}`,
      ...gestures2(false, rowLift, rowPress),
      children: [
        /* @__PURE__ */ jsxs3(
          "button",
          {
            type: "button",
            className: "vu-bf-note-hit",
            onClick: () => {
              markFeedNoteRead(note);
              show({ charId: note.posterId, postId: note.postId, commentId: comment.id });
            },
            children: [
              /* @__PURE__ */ jsx3(CommentFace, { comment, size: "md" }),
              /* @__PURE__ */ jsxs3("span", { className: "vu-bb-chat-main", children: [
                /* @__PURE__ */ jsxs3("span", { className: "vu-bb-chat-top", children: [
                  /* @__PURE__ */ jsx3("span", { className: "vu-bb-name", children: character3 ? fullNameOf3(character3) : comment.handle }),
                  /* @__PURE__ */ jsxs3("span", { className: "vu-bf-comment-who", children: [
                    "@",
                    comment.handle
                  ] })
                ] }),
                /* @__PURE__ */ jsx3("span", { className: "vu-bf-note-what", children: what }),
                /* @__PURE__ */ jsx3("span", { className: "vu-bb-preview", children: /* @__PURE__ */ jsx3(SentText2, { text: comment.text, big: false }) })
              ] }),
              /* @__PURE__ */ jsx3("span", { className: "vu-bb-stamp", children: slotHalf2(slotFromId(comment.at).time) })
            ]
          }
        ),
        unread && /* @__PURE__ */ jsx3(
          motion2.button,
          {
            type: "button",
            className: "vu-bf-comment-reply vu-bf-note-read",
            ...gestures2(false, quietLift2, quietPress2),
            onClick: () => markFeedNoteRead(note),
            children: "Mark as read"
          }
        )
      ]
    }
  );
}
var LIST_DEAL;
var init_BunnyfeedsNotifications = __esm({
  "src/renderer/components/BunnyfeedsNotifications.tsx"() {
    init_bunnyfeedsData();
    init_bunnyfeedsReadContext();
    init_bunnyfeedsNotes();
    init_BunnyfeedsThread();
    init_Bunnyfeeds();
    LIST_DEAL = dealt(0, 0.03);
  }
});

// src/renderer/modEntries/bunnyfeeds.ts
init_bunnyfeeds();
init_bunnyfeedsPrompt();
init_bunnyfeedsReplies();
init_bunnyfeedsMemory();
init_bunnyfeedsVisit();
init_bunnyfeedsNotes();
init_bunnyfeedsReadContext();
init_bunnyfeedsData();
import {
  globalSlotOf as globalSlotOf5,
  registerPostCarry,
  shownComments as shownComments2,
  charKeyOf as charKeyOf4
} from "@vx/modkit/shared";
import {
  formatShortGameDate as formatShortGameDate3,
  ownsPostComments as ownsPostComments2,
  postVisible as postVisible2,
  phoneOpen as phoneOpen2,
  subscribePhoneView as subscribePhoneView2,
  registerHooks
} from "@vx/modkit/renderer";
import { createElement, lazy, Suspense } from "react";
var screens = () => Promise.resolve().then(() => (init_BunnyfeedsThread(), BunnyfeedsThread_exports));
var LazyPreview = lazy(() => screens().then((module) => ({ default: module.FeedPreview })));
var LazyPill = lazy(() => screens().then((module) => ({ default: module.CommentPill })));
var notifications = () => Promise.resolve().then(() => (init_BunnyfeedsNotifications(), BunnyfeedsNotifications_exports));
var LazyNotes = lazy(
  () => notifications().then((module) => ({ default: module.FeedNotificationsPage }))
);
var LazyMarkAll = lazy(
  () => notifications().then((module) => ({ default: module.MarkAllFeedNotes }))
);
function FeedNotificationsView() {
  return createElement(Suspense, { fallback: null }, createElement(LazyNotes));
}
var LazyFaces = lazy(
  () => Promise.resolve().then(() => (init_BunnyfeedsFaces(), BunnyfeedsFaces_exports)).then((module) => ({ default: module.FacesPreview }))
);
function FacesPreviewView(props) {
  return createElement(Suspense, { fallback: null }, createElement(LazyFaces, props));
}
function MarkAllView() {
  return createElement(Suspense, { fallback: null }, createElement(LazyMarkAll));
}
function FeedPreviewView(props) {
  return createElement(Suspense, { fallback: null }, createElement(LazyPreview, props));
}
function CommentPillView(props) {
  return createElement(Suspense, { fallback: null }, createElement(LazyPill, props));
}
var RECENT_POSTS = 2;
function recentPostLines(characters) {
  const { charInfo, date, time, calendar } = readBunnyfeedsContext();
  return characters.flatMap((character3) => {
    const posts = (charInfo[character3.charId]?.feed ?? []).filter(postVisible2).slice(-RECENT_POSTS);
    if (posts.length === 0) return [];
    const name = character3.firstName;
    return [
      `${name}'s latest feed posts, which everyone can see:`,
      ...posts.flatMap((post) => {
        const said = shownComments2(post.comments, date, time);
        const hers = said.filter(
          (one) => commentData.read(one).charId === character3.charId && said.some((his2) => commentData.read(his2).player && his2.id === commentData.read(one).replyTo)
        );
        const answered = new Set(hers.map((one) => commentData.read(one).replyTo));
        const his = said.filter((one) => commentData.read(one).player && answered.has(one.id));
        return [
          `- ${formatShortGameDate3(post.date, calendar.season)}: "${post.text}"`,
          ...his.map((one) => `  The reader commented: "${one.text}"`),
          ...hers.map((one) => `  ${name} answered him: "${one.text}"`)
        ];
      })
    ];
  });
}
function threads() {
  return Promise.resolve().then(() => (init_bunnyfeedsThreads(), bunnyfeedsThreads_exports));
}
var wasPhoneOpen2 = phoneOpen2();
subscribePhoneView2(() => {
  const beforeOpen = wasPhoneOpen2;
  wasPhoneOpen2 = phoneOpen2();
  if (!beforeOpen || wasPhoneOpen2 || !takeCommented()) return;
  void threads().then((module) => module.armFeedThreads("next"));
});
function writesComments() {
  return ownsPostComments2(BUNNYFEEDS);
}
registerHooks(BUNNYFEEDS, {
  prompts: {
    scene: { lines: ({ cast }) => recentPostLines(cast) },
    dm: { lines: ({ character: character3 }) => recentPostLines([character3]) },
    // The replies each post arrives with, asked for while Bunnyfeeds draws the comments.
    "slot-posts": {
      lines: () => writesComments() ? slotCommentLines() : [],
      fields: () => writesComments() ? { comments: slotCommentsField() } : {},
      required: () => writesComments() ? ["comments"] : []
    },
    // Comments under her posts are the feed's, not her texts'.
    "text-ledger": { lines: ({ charKeys }) => textLedgerFeedLines(charKeys) }
  },
  // The feed memories the next slot files, with its answers, in the slot's closing report.
  slotStatusLines: ({ nextSlot }) => feedStatusLines(nextSlot),
  // The roster girls who may reply under each of the slot's posts, described in their own voices.
  requests: {
    "slot-intro": (request, { input }) => {
      const { npcRelationships: npcRelationships2 } = readBunnyfeedsContext();
      const repliers = replierBlock(
        input.posters.map(({ character: character3 }) => ({
          character: character3,
          charKey: charKeyOf4(character3.firstName, character3.lastName),
          repliers: repliersFor(character3.charId, npcRelationships2)
        }))
      );
      const planned = writesComments() ? planSlotCrowds(input.posters.map(({ character: character3 }) => character3.charId)) : /* @__PURE__ */ new Map();
      const crowd = crowdBlock(
        input.posters.flatMap(({ character: character3 }) => {
          const plan = planned.get(character3.charId);
          return plan ? [
            {
              name: character3.firstName,
              charKey: charKeyOf4(character3.firstName, character3.lastName),
              ...plan
            }
          ] : [];
        })
      );
      const block = [...repliers, ...repliers.length > 0 && crowd.length > 0 ? [""] : [], ...crowd];
      if (block.length === 0) return request;
      const at = request.user.lastIndexOf("YOUR TURN");
      const text = [...block, ""].join("\n");
      const user = at >= 0 ? `${request.user.slice(0, at)}${text}
${request.user.slice(at)}` : `${request.user}

${text}`;
      return { ...request, user };
    }
  },
  // Held memories whose answers show next slot are filed now, so the boundary save carries them;
  // then whatever the phone-close call never answered is asked for.
  slotSettled: () => {
    const { date, time } = readBunnyfeedsContext();
    fileDueFeedMemories(globalSlotOf5(date, time) + 1);
    void threads().then((module) => module.armFeedThreads("next"));
  },
  // Files the replies too. A post another mod is putting a picture on (its "image") draws more.
  fileFeedPost: (filing) => {
    if (!writesComments()) return;
    const reply = filing.reply;
    const picture = typeof reply.image === "string" && reply.image.trim() !== "";
    const comments = rollFeedComments(
      filing.charId,
      writtenComments(reply.comments, filing.charId),
      picture
    );
    if (comments.length > 0) filing.post = { ...filing.post, comments };
  },
  // The threads under each post, and the comment count beside its like.
  postComments: {
    View: FeedPreviewView,
    Action: CommentPillView,
    // His own, a roster girl's, and every reply: comments only Bunnyfeeds writes.
    claims: (comment) => Boolean(commentData.read(comment).player || commentData.read(comment).charId || commentData.read(comment).replyTo)
  },
  // What each choice of followers' faces looks like, under the choice on the Mods screen.
  optionPreviews: { faces: FacesPreviewView },
  // Every reply to his comments, beside the feed in Updates, counting what he has not seen.
  updatesTab: {
    id: "notifications",
    word: "Notifications",
    Page: FeedNotificationsView,
    Action: MarkAllView,
    unread: unreadFeedNotesOf
  },
  gameEntered: () => {
    takeCommented();
    settleFeedReadMark();
    void threads().then((module) => module.resetFeedThreads());
  }
});
registerPostCarry(BUNNYFEEDS, carriedThread);
